/*
 * Public API Surface of codx-hr
 */

export * from './lib/codx-hr.service';
// export * from './lib/codx-hr.component';
export * from './lib/codx-hr.module';
