/*
 * Public API Surface of codx-hr
 */

export * from './lib/codx-hr-common/services/codx-hr.service';
// export * from './lib/codx-hr.component';
export * from './lib/codx-hr.module';
