import { ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { ApiHttpService, ButtonModel, CacheService, CallFuncService, CodxGridviewV2Component, CodxService, FormModel, ImageViewerComponent } from 'codx-core';
// import { CodxShareService } from 'projects/codx-share/src/public-api';

@Component({
  selector: 'employee-assign-shift-list',
  templateUrl: './employee-assign-shift-list.component.html',
  styleUrls: ['./employee-assign-shift-list.component.scss']
})
export class EmployeeAssignShiftListComponent {
  @Input() orgUnitID: string = 'C01';
  @Input() formModel!: FormModel;
  @Input() showManager: boolean = true;
  @Input() view: any;
  @Input() grvSetup: any;
  @Input() editable: boolean = false;
  @Input() modeView: string = 'employee';
  @Input() rowHeight: string = '50';
  @Input() showRowNumber: boolean = true;
  @Input() funcID: string = 'HRT03a1';
  @Output() dataChange: EventEmitter<any> = new EventEmitter();
  @Output() gridViewDataService: EventEmitter<any> = new EventEmitter();

  totalEmployee: number = 0;
  sysMoreFunc: any[] = [];
  
  manager: any = null;

  columnsGrid!: any[];
  columnsGridContact: any;
  @ViewChild('grid') grid: CodxGridviewV2Component | undefined;
  @ViewChild('headerGridView1',{ static: true }) headerGridView1: TemplateRef<any> | undefined;
  @ViewChild('headerGridView2',{ static: true }) headerGridView2: TemplateRef<any> | undefined;;
  @ViewChild('headerGridView3',{ static: true }) headerGridView3: TemplateRef<any> | undefined;;
  @ViewChild('headerGridView4',{ static: true }) headerGridView4: TemplateRef<any> | undefined;;
  @ViewChild('headerGridView5',{ static: true }) headerGridView5: TemplateRef<any> | undefined;;
  @ViewChild('headerGridView6',{ static: true }) headerGridView6: TemplateRef<any> | undefined;;
  @ViewChild('headerGridView7',{ static: true }) headerGridView7: TemplateRef<any> | undefined;;

  @ViewChild('colGridView1', { static: true }) colGridView1: TemplateRef<any> | undefined;;
  @ViewChild('colGridView2', { static: true }) colGridView2: TemplateRef<any> | undefined;;
  @ViewChild('colGridView3', { static: true }) colGridView3: TemplateRef<any> | undefined;;
  @ViewChild('colGridView4', { static: true }) colGridView4: TemplateRef<any> | undefined;;
  @ViewChild('colGridView5', { static: true }) colGridView5: TemplateRef<any> | undefined;;
  @ViewChild('colGridView6', { static: true }) colGridView6: TemplateRef<any> | undefined;;
  @ViewChild('colGridView7', { static: true }) colGridView7: TemplateRef<any> | undefined;;
  @ViewChild('colGridView8', { static: true }) colGridView8: TemplateRef<any> | undefined;;

  service = 'HR';
  entityName = 'HR_Employees';
  assemblyName = 'ERM.Business.HR';
  className = 'EmployeesBusiness_Old';
  method = 'GetEmployeeListByOrgUnitIDGridView';
  idField = 'employeeID';
  predicates = '@0.Contains(OrgUnitID)';
  funcIDEmpInfor: string = 'HRT03b';
  // itemSelected;
  
  hadEmitDataService = false;
  inputTimes = 0;

  constructor(
    private cache: CacheService,
    private api: ApiHttpService,
    private dt: ChangeDetectorRef,
    private callfc: CallFuncService,
    // private shareService: CodxShareService,
    private codxService: CodxService) { }

  ngOnInit(): void {

    console.log(this.formModel);
    // get more funtion hệ thống
    this.cache.moreFunction('CoDXSystem', '').subscribe((mFuc: any) => {
      if (mFuc) this.sysMoreFunc = mFuc;
    });

    this.initColumnGrid();

  }
  
  ngAfterViewInit(): void {
    this.initColumnGrid();
    // this.onScroll(); // Kiểm tra ngay khi tải trang

  }

  initColumnGrid() {
    if(!this.columnsGrid){
      this.columnsGrid = [
        {
          headerTemplate:  this.headerGridView1,
          template: this.colGridView1,
          width: '300',
        },
        {
          headerTemplate: this.headerGridView2,
          template: this.colGridView2,
          width: '200',
        },
        {
          headerTemplate: this.headerGridView3,
          template: this.colGridView3,
          width: '200',
        },
        {
          headerTemplate: this.headerGridView4,
          template: this.colGridView4,
          width: '150',
        },
        {
          headerTemplate: this.headerGridView5,
          template: this.colGridView5,
          width: '150',
        },
        {
          headerTemplate: this.headerGridView6,
          template: this.colGridView6,
          width: '150',
        }
      ];
    }
  }

  // getRefreshFlag(event){
  //   if(event?.field == 'rowCount'){
  //     this.grid.dataService.rowCount = event.value;
  //   }
  // }

}
