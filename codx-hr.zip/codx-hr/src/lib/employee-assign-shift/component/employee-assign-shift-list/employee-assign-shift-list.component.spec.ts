import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeAssignShiftListComponent } from './employee-assign-shift-list.component';

describe('EmployeeAssignShiftListComponent', () => {
  let component: EmployeeAssignShiftListComponent;
  let fixture: ComponentFixture<EmployeeAssignShiftListComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeAssignShiftListComponent]
    });
    fixture = TestBed.createComponent(EmployeeAssignShiftListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
