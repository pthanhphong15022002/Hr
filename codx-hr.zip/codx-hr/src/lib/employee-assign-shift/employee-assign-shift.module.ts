import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from '../_layout/layout.component';
import { RouterModule, Routes } from '@angular/router';
import { CoreModule } from '@core/core.module';
import { CodxCoreModule } from 'codx-core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '@shared/shared.module';
import { FormsModule } from '@angular/forms';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClientModule } from '@angular/common/http';
import { DirectivesModule } from '../codx-hr-common/directives/directives.module';
import { CodxHRCommonModule } from '../codx-hr-common/codx-hr-common.module';
import { TabModule } from '@syncfusion/ej2-angular-navigations';
import { TranformValueNumberPipe } from 'projects/codx-ac/src/lib/pipes/tranform-value-number.pipe';
import { EmployeeAssignShiftListComponent } from './component/employee-assign-shift-list/employee-assign-shift-list.component';
import { EmployeeAssignShiftComponent } from './employee-assign-shift-list.component';
export const routes: Routes = [
  {
    // hr/socialins/HRT104
    path:'',
    component: LayoutComponent,
    children:[
      {
        path:'assignshift/:funcID',
        component: EmployeeAssignShiftComponent,
      },
      {
        path: '**',
        redirectTo: 'error/404',
      },
    ]
  }
];

const T_Component = [
  EmployeeAssignShiftListComponent,
  EmployeeAssignShiftComponent
 
];


@NgModule({
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    CoreModule,
    NgbModule,
    FormsModule,
    SharedModule,
    OverlayModule,
    HttpClientModule,
    DirectivesModule,
    CodxHRCommonModule,
    TabModule,
    TranformValueNumberPipe

  ],
  declarations: [T_Component],

})
export class EmployeeAssignShiftModule { }
