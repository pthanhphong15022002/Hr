import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeLstByOrgComponent } from './employee-lst-by-org.component';

describe('EmployeeLstByOrgComponent', () => {
  let component: EmployeeLstByOrgComponent;
  let fixture: ComponentFixture<EmployeeLstByOrgComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeLstByOrgComponent]
    });
    fixture = TestBed.createComponent(EmployeeLstByOrgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
