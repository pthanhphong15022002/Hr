import {
  ChangeDetectorRef,
  Component,
  Injector,
  Input,
  OnInit,
  Optional,
  TemplateRef,
  ViewChild,
} from '@angular/core';
import {
  CodxFormComponent,
  CodxGridviewV2Component,
  DataRequest,
  DialogData,
  DialogRef,
  FormModel,
  NotificationsService,
  UIComponent,
} from 'codx-core';
import { CodxHrService } from '../../../codx-hr.service';
import { AttachmentComponent } from 'projects/codx-common/src/lib/component/attachment/attachment.component';
import {
  Observable,
  Subject,
  debounceTime,
  distinctUntilChanged,
  filter,
  map,
  of,
  switchMap,
} from 'rxjs';
import { query } from '@angular/animations';
import { SelectionSettingsModel } from '@syncfusion/ej2-angular-grids';

@Component({
  selector: 'lib-employee-lst-by-org',
  templateUrl: './employee-lst-by-org.component.html',
  styleUrls: ['./employee-lst-by-org.component.css'],
})
export class EmployeeLstByOrgComponent extends UIComponent implements OnInit {
  @Input() orgUnitID = '';
  searchText: string = '';
  // heightStyle: string = 'calc(100% - 20%)';

  dialogRef: any;

  @ViewChild('gridView') gridView: CodxGridviewV2Component;

  columnsGrid: any[];
  @ViewChild('colEmployeeLstByORG1', { static: true })
  colEmployeeLstByORG1: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG2', { static: true })
  colEmployeeLstByORG2: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG3', { static: true })
  colEmployeeLstByORG3: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG4', { static: true })
  colEmployeeLstByORG4: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG5', { static: true })
  colEmployeeLstByORG5: TemplateRef<any> | undefined;

  // @ViewChild('gridView') gridView: CodxGridviewV2Component;

  formModel: FormModel;
  dialog: DialogRef;
  EBasicSalaryObj: any;
  idField = 'RecID';
  actionType: string;
  disabledInput = false;
  isMultiCopy: boolean = false;
  employeeId: string | null;
  headerText: 'Đăng ký nghĩ phép';
  autoNumField: string;
  @ViewChild('form') form: CodxFormComponent;
  @ViewChild('attachment') attachment: AttachmentComponent;

  //check where to open the form
  employeeObj: any | null;
  actionArray = ['add', 'edit', 'copy'];
  fromListView: boolean = false; //check where to open the form
  showEmpInfo: boolean = true;
  loaded: boolean = false;
  isFocusOut: boolean = false;
  employeeSign;
  loadedAutoNum = false;
  originEmpID = '';
  originEmpBeforeSelectMulti: any;

  //formModel
  empFormModel: FormModel;
  empGrvSetUp;

  selectionOptions: SelectionSettingsModel = {
    mode: 'Both',
    cellSelectionMode: 'Box',
    type: 'Multiple',
    checkboxOnly: false,
    persistSelection: true,
    checkboxMode: 'Default',
    enableSimpleMultiRowSelection: true,
    enableToggle: true,
    allowColumnSelection: true
  };
  
  //end
  constructor(
    injector: Injector,
    private cr: ChangeDetectorRef,
    private notify: NotificationsService,
    private hrService: CodxHrService,
    @Optional() dialog?: DialogRef,
    @Optional() data?: DialogData
  ) {
    super(injector);
    this.actionType = data?.data?.actionType;
    this.headerText = data?.data?.headerText;
    this.dialog = dialog;
  }

  onInit(): void {
    this.initEmployeeListByORG();
    this.getGrvEmpList();
  }

  closeMyTeamPopUp() {
    this.dialog.close();
  }

  selecttree($event) {
    this.orgUnitID = $event;
    console.log(this.orgUnitID);

    let ins = setInterval(() => {
      if (this.gridView) {
        clearInterval(ins);
        this.gridView.refresh();
      }
    }, 0);
  }

  //Hàm tạm thời lấy cứng grvEmpList

  getGrvEmpList() {
    this.hrService.getFormModel('WSHREM02').then((res) => {
      this.empFormModel = res;
      console.log('this.empFormModel', this.empFormModel);

      this.cache
        .gridViewSetup(
          this.empFormModel.formName,
          this.empFormModel.gridViewName
        )
        .subscribe((res) => {
          this.empGrvSetUp = res;
          console.log('this.empGrvSetUp', this.empGrvSetUp);
        });
    });
  }

  onSearch(event: any) {
    console.log(event);
    this.searchText = event;
    let ins2 = setInterval(() => {
      if (this.gridView) {
        clearInterval(ins2);
        this.gridView.refresh();
      }
    }, 2);
  }

  onSearchByOrgName(event: any) {
    console.log(event);
    this.searchText = event;
    let ins2 = setInterval(() => {
      if (this.gridView) {
        clearInterval(ins2);
        this.gridView.refresh();
      }
    }, 2);
  }

  initEmployeeListByORG() {
    if (!this.columnsGrid) {
      // this.hrService.getHeaderText(this.eInfoFuncID).then((res) => {
      // this.eSkillHeaderText = res;
      this.columnsGrid = [
        {
          headerText: 'Tên nhân viên',
          // headerText: this.eFamilyHeaderTexts['LastName'] + this.eFamilyHeaderTexts['FirstName'],
          // headerTemplate: this.headeEFamilyCol1,
          template: this.colEmployeeLstByORG1,
          width: '300',
        },
        {
          headerText: 'Tình trạng',
          // headerText: this.eFamilyHeaderTexts['Gender'],
          // headerTemplate: this.headeEFamilyCol2,
          template: this.colEmployeeLstByORG2,
          width: '250',
        },
        {
          headerText: 'Thông tin chấm công',
          // headerText: this.eFamilyHeaderTexts['Birthday'],
          template: this.colEmployeeLstByORG3,
          // headerTemplate: this.headeEFamilyCol3,
          width: '300',
        },
        {
          headerText: 'Thông tin cá nhân',
          // headerText: this.eFamilyHeaderTexts['HouseHolderRelCode'],
          template: this.colEmployeeLstByORG4,
          // headerTemplate: this.headeEFamilyCol4,
          width: '200',
        },
        {
          headerText: 'Liên hệ',
          // headerText: this.eFamilyHeaderTexts['IsReduceTax'],
          template: this.colEmployeeLstByORG5,
          // headerTemplate: this.headeEFamilyCol5,
          width: '200',
        },
      ];

      // });
      // this.df.detectChanges();
    }
  }

  // searchService(term): any {
  //   let empRequest = new DataRequest();
  //   empRequest.entityName = 'HR_OrganizationUnits';
  //   empRequest.dataValues = term;
  //   empRequest.predicates = 'OrgUnitName.Contains(@0)';
  //   empRequest.pageLoading = false;
  //   this.hrService.loadData('HR', empRequest).subscribe((res: any) => {
  //     // return res[0][0];

  //     if (!term.trim()) {
  //       return of([]);
  //     }
  //     const results = res.filter(item => item.orgUnitName.toLowerCase().includes(term.toLowerCase()));
  //     return of(results);

  //   });
  // }

  search(term: string): Observable<any[]> {
    if (!term.trim()) {
      return of([]);
    }

    let empRequest = new DataRequest();
    empRequest.entityName = 'HR_OrganizationUnits';
    empRequest.dataValues = term;
    empRequest.predicates = 'OrgUnitName.Contains(@0)';
    empRequest.pageLoading = false;

    return this.hrService.loadData('HR', empRequest).pipe(
      map((res: any) => {
        console.log(res);
        return res[0].map((item) => ({
          orgUnitID: item.orgUnitID,
          orgUnitName: item.orgUnitName,
        }));
      })
    );
  }

  private searchTerms = new Subject<string>();
  searchTerm: string = '';
  results: any[] = [{}];

  override ngOnInit() {
    this.initEmployeeListByORG();
    this.getGrvEmpList();
    this.searchTerms
      .pipe(
        debounceTime(300), // Đợi 300ms sau mỗi lần nhập để tránh gửi quá nhiều yêu cầu
        distinctUntilChanged(),
        filter((term) => term.trim().length > 0), // Lọc ra các chuỗi rỗng
        switchMap((term) => this.search(term))
      )
      .subscribe((results) => {
        this.results = results;
        console.log(this.results);
      });
  }

  onKeyUp(event: Event): void {
    console.log(event);
    const input = (event.target as HTMLInputElement).value;
    console.log(input);
    this.searchTerm = input;

    // const input = (event.target as HTMLInputElement).value;
    this.searchTerms.next(input);
  }

  onFocusOut(event: Event): void {
    console.log('onkeydown');
    let ins = setInterval(() => {
      // if (this.gridView) {
      clearInterval(ins);
      this.isFocusOut = true;
      // this.gridView.refresh();
      // }
    }, 200);
  }

  onFocus(event: Event): void {
    console.log('onkeyIn');
    this.isFocusOut = false;
  }

  onChooseSearchResult(id: string) {
    this.orgUnitID = id;
    console.log(this.orgUnitID);

    let ins = setInterval(() => {
      if (this.gridView) {
        clearInterval(ins);
        console.log('in');
        this.find(id);
        this.gridView.refresh();
      }
    }, 0);
  }

  find(id: string) {
    let element = document.querySelector(`[data-id='${id}']`);
    console.log(element);

    if (element) {
      // Cuộn đến phần tử

      let closestParentSubMenu = element.closest('.menu-sub');

      console.log(closestParentSubMenu);
      if (closestParentSubMenu) {
        closestParentSubMenu.classList.remove('hide');
        closestParentSubMenu.classList.add('show');
      }

      element.classList.add('item-selected');

      // Xóa class 'item-selected' từ các phần tử khác nếu cần
      document.querySelectorAll('.item-selected').forEach((el) => {
        if (el !== element) {
          el.classList.remove('item-selected');
        }
      });

      element.scrollIntoView({ behavior: 'smooth', block: 'center' });

      //   setTimeout(() => {
      //     if (this.gridView) {
      //         console.log('in');
      //         this.gridView.refresh();
      //     }
      // }, 100);

      // Refresh gridView nếu tồn tại
      //   let ins = setInterval(() => {
      //     if (this.gridView) {
      //       clearInterval(ins);
      //       console.log('in');
      //       this.gridView.refresh();
      //     }
      //   }, 0);
      // } else {
      //   console.log('Element not found');
    }
  }

  findParentWithClass(element, className): any {
    let parent = element.parentElement;
    while (parent) {
      if (parent.classList.contains(className)) {
        return parent;
      }
      parent = parent.parentElement;
    }
    return null;
  }
}
