import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MinusAdditionalAmountsComponent } from './minus-additional-amounts.component';

describe('MinusAdditionalAmountsComponent', () => {
  let component: MinusAdditionalAmountsComponent;
  let fixture: ComponentFixture<MinusAdditionalAmountsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MinusAdditionalAmountsComponent]
    });
    fixture = TestBed.createComponent(MinusAdditionalAmountsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
