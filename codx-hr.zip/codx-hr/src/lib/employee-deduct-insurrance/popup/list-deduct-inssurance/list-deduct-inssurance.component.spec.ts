import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListDeductInssuranceComponent } from './list-deduct-inssurance.component';

describe('ListDeductInssuranceComponent', () => {
  let component: ListDeductInssuranceComponent;
  let fixture: ComponentFixture<ListDeductInssuranceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListDeductInssuranceComponent]
    });
    fixture = TestBed.createComponent(ListDeductInssuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
