import { ChangeDetectorRef, Component, Injector, OnInit, Optional, TemplateRef, ViewChild } from '@angular/core';
import { CodxFormComponent, CodxGridviewV2Component, DialogData, DialogRef, FormModel, NotificationsService, UIComponent } from 'codx-core';

@Component({
  selector: 'app-list-deduct-inssurance',
  templateUrl: './list-deduct-inssurance.component.html',
  styleUrls: ['./list-deduct-inssurance.component.scss']
})
export class ListDeductInssuranceComponent extends UIComponent implements OnInit {

  formModel!: FormModel;
  dialog: DialogRef | undefined;
  EBasicSalaryObj: any;
  idField = 'RecID';
  actionType: string;
  disabledInput = false;
  isMultiCopy: boolean = false;
  employeeId!: string;
  headerText: '';
  autoNumField!: string;
  @ViewChild('form') form!: CodxFormComponent;
  // @ViewChild('attachment') attachment: AttachmentComponent;

  //check where to open the form
  employeeObj: any | null;
  actionArray = ['add', 'edit', 'copy'];
  fromListView: boolean = false; //check where to open the form
  showEmpInfo: boolean = true;
  loaded: boolean = false;
  // employeeSign;
  loadedAutoNum = false;
  originEmpID = '';
  originEmpBeforeSelectMulti: any;
  // genderGrvSetup: any;
  //end
  constructor(
    injector: Injector,
    private cr: ChangeDetectorRef,
    private notify: NotificationsService,
    @Optional() dialog?: DialogRef,
    @Optional() data?: DialogData
  ) {
    super(injector);
    this.actionType = data?.data?.actionType;
    this.headerText = data?.data?.headerText;
    this.dialog = dialog;


  }

  onInit(): void {
    this.initEmployeeListByORG()
  }

  closeMyTeamPopUp() {
    if (this.dialog == undefined) return;
    this.dialog.close();
  }


  // setTimeout(() => {

  // }, 2);}


  columnsGrid!: any[];

  @ViewChild('headerEmployeeLstByORG0', { static: true })
  headerEmployeeLstByORG0: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG0', { static: true })
  colEmployeeLstByORG0: TemplateRef<any> | undefined;

  @ViewChild('colEmployeeLstByORG1', { static: true })
  colEmployeeLstByORG1: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG2', { static: true })
  colEmployeeLstByORG2: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG3', { static: true })
  colEmployeeLstByORG3: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG4', { static: true })
  colEmployeeLstByORG4: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG5', { static: true })
  colEmployeeLstByORG5: TemplateRef<any> | undefined;
  @ViewChild('colEmployeeLstByORG6', { static: true })
  colEmployeeLstByORG6: TemplateRef<any> | undefined;

  @ViewChild('gridView') gridView: CodxGridviewV2Component | undefined;
  
  initEmployeeListByORG() {
    if (!this.columnsGrid) {

      this.columnsGrid = [
        {
          headerText: 'Mã nhân viên',
          template: this.colEmployeeLstByORG1,
          width: '10%',
        },
        {
          headerText: 'Họ tên',
          template: this.colEmployeeLstByORG2,
          width: '30%',
        },
        {
          headerText: '%Cty đóng',
          template: this.colEmployeeLstByORG3,
          width: '10%',
        },
        {
          headerText: '%NV đóng',
          template: this.colEmployeeLstByORG4,
          width: '10%',
        },
        {
          headerText: 'Số tiền Cty đóng',
          template: this.colEmployeeLstByORG5,
          width: '20%',
        },
        {
          headerText: 'Số tiền NV đóng',
          template: this.colEmployeeLstByORG6,
          width: '20%',
        },

      ];

    }
  }

  lstTab: any[] = [


    {
      functionID: 1,
      customName: "Dashboard",
      largeIcon: "icon-columns_gap" // Fake icon class
    },
    {
      functionID: 2,
      customName: "Thông tin cá nhân",
      largeIcon: "icon-assignment_ind" // Fake icon class
    },
    {
      functionID: 3,
      customName: "Quá trình làm việc",
      largeIcon: "icon-timeline" // Fake icon class
    },
    {
      functionID: 4,
      customName: "Khen thưởng kỷ luật",
      largeIcon: "icon-elevator" // Fake icon class
    },
    {
      functionID: 5,
      customName: "Thông tin phúc lợi",
      largeIcon: "icon-redeem" // Fake icon class
    },

    {
      functionID: 6,
      customName: "Thông tin pháp lý",
      largeIcon: "icon-gavel" // Fake icon class
    },
    {
      functionID: 7,
      customName: "Thông tin kiến thức",
      largeIcon: "icon-school" // Fake icon class
    },
    {
      functionID: 8,
      customName: "Nghiệp vụ test",
      largeIcon: "icon-school" // Fake icon class
    },
    {
      functionID: 1,
      customName: "Dashboard",
      largeIcon: "icon-columns_gap" // Fake icon class
    },
    {
      functionID: 2,
      customName: "Thông tin cá nhân",
      largeIcon: "icon-assignment_ind" // Fake icon class
    },
    {
      functionID: 3,
      customName: "Quá trình làm việc",
      largeIcon: "icon-timeline" // Fake icon class
    },
    {
      functionID: 4,
      customName: "Khen thưởng kỷ luật",
      largeIcon: "icon-elevator" // Fake icon class
    },
    {
      functionID: 5,
      customName: "Thông tin phúc lợi",
      largeIcon: "icon-redeem" // Fake icon class
    },

    {
      functionID: 6,
      customName: "Thông tin pháp lý",
      largeIcon: "icon-gavel" // Fake icon class
    },
    {
      functionID: 7,
      customName: "Thông tin kiến thức",
      largeIcon: "icon-school" // Fake icon class
    },
    {
      functionID: 8,
      customName: "Nghiệp vụ test",
      largeIcon: "icon-school" // Fake icon class
    }

  ];

  closePopUp(){
    this.dialog.close();
  }


}