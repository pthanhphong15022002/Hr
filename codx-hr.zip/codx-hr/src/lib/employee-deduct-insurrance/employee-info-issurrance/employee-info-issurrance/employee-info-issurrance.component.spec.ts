import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeInfoIssurranceComponent } from './employee-info-issurrance.component';

describe('EmployeeInfoIssurranceComponent', () => {
  let component: EmployeeInfoIssurranceComponent;
  let fixture: ComponentFixture<EmployeeInfoIssurranceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeInfoIssurranceComponent]
    });
    fixture = TestBed.createComponent(EmployeeInfoIssurranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
