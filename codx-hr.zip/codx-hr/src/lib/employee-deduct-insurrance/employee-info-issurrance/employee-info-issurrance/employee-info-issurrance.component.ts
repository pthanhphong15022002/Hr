import { ChangeDetectorRef, Component, EventEmitter, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { ApiHttpService, ButtonModel, CacheService, CallFuncService, CodxGridviewV2Component, CodxService, FormModel, ImageViewerComponent } from 'codx-core';
import { CodxShareService } from 'projects/codx-share/src/public-api';

@Component({
  selector: 'lib-employee-info-issurrance',
  templateUrl: './employee-info-issurrance.component.html',
  styleUrls: ['./employee-info-issurrance.component.css']
})
export class EmployeeInfoIssurranceComponent {
  @Input() orgUnitID: string = 'C01';
  @Input() formModel: FormModel = null;
  @Input() showManager: boolean = true;
  @Input() view: any;
  @Input() grvSetup: any;
  @Input() editable: boolean = false;
  @Input() modeView: string = 'employee';
  @Input() rowHeight: string = '50';
  @Input() showRowNumber: boolean = true;
  @Input() funcID: string = 'HRT03a1';
  @Output() dataChange: EventEmitter<any> = new EventEmitter();
  @Output() gridViewDataService: EventEmitter<any> = new EventEmitter();
  totalEmployee: number = 0;
  sysMoreFunc: any[] = [];
  columnsGrid: any[];
  columnsGridContact;
  manager: any = null;
  @ViewChild('grid') grid: CodxGridviewV2Component;
  @ViewChild('headerDeductInsurrance1') headerDeductInsurrance1: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance2') headerDeductInsurrance2: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance3') headerDeductInsurrance3: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance4') headerDeductInsurrance4: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance5') headerDeductInsurrance5: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance6') headerDeductInsurrance6: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance7') headerDeductInsurrance7: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance8') headerDeductInsurrance8: TemplateRef<any>;



  @ViewChild('colDeductInsurrance1') colDeductInsurrance1: TemplateRef<any>;
  @ViewChild('colDeductInsurrance2') colDeductInsurrance2: TemplateRef<any>;
  @ViewChild('colDeductInsurrance3') colDeductInsurrance3: TemplateRef<any>;
  @ViewChild('colDeductInsurrance4') colDeductInsurrance4: TemplateRef<any>;
  @ViewChild('colDeductInsurrance5') colDeductInsurrance5: TemplateRef<any>;
  @ViewChild('colDeductInsurrance6') colDeductInsurrance6: TemplateRef<any>;
  @ViewChild('colDeductInsurrance7') colDeductInsurrance7: TemplateRef<any>;
  @ViewChild('colDeductInsurrance8') colDeductInsurrance8: TemplateRef<any>;

  service = 'HR';
  entityName = 'HR_Employees';
  assemblyName = 'ERM.Business.HR';
  className = 'EmployeesBusiness_Old';
  method = 'GetEmployeeListByOrgUnitIDGridView';
  idField = 'employeeID';
  predicates = '@0.Contains(OrgUnitID)';
  funcIDEmpInfor: string = 'HRT03b';
  itemSelected;
  
  hadEmitDataService = false;
  inputTimes = 0;
  constructor(
    private cache: CacheService,
    private api: ApiHttpService,
    private dt: ChangeDetectorRef,
    private callfc: CallFuncService,
    private shareService: CodxShareService,
    private codxService: CodxService) { }

  ngOnInit(): void {
    // get more funtion hệ thống
    this.cache.moreFunction('CoDXSystem', '').subscribe((mFuc: any) => {
      if (mFuc) this.sysMoreFunc = mFuc;
    });

    this.initColumnGrid();

  }
  
  ngAfterViewInit(): void {
    this.initColumnGrid();
  }

  initColumnGrid() {
    console.log('checked here')


    this.columnsGrid = [
      {
        // headerTemplate:  this.headerDeductInsurrance1,
        headerText: 'Nhân viên',
        // field: 'EmployeeName',
        template: this.colDeductInsurrance1,
        width: '200',
      },
      {
        // headerTemplate: this.grvSetup['Birthday']['headerText'],
        // headerTemplate: this.headerDeductInsurrance2,
        headerText: 'Mức lương',

        // field: 'Birthday',
        template: this.colDeductInsurrance2,
        width: '120',
      },
      {
        // headerTemplate: this.grvSetup['Phone']['headerText'],
        // headerTemplate: this.headerDeductInsurrance3,
        headerText: 'Tổng phụ cấp',

        // field: 'Phone',
        template: this.colDeductInsurrance3,
        width: '120',
      },
      {
        // headerTemplate: this.grvSetup['Email']['headerText'],
        // headerTemplate: this.headerDeductInsurrance4,
        headerText: '%Cty đóng',
        // field: 'Email',
        template: this.colDeductInsurrance4,
        width: '120',
      },
      {
        // headerTemplate: this.grvSetup['JoinedOn']['headerText'],
        // headerTemplate: this.headerDeductInsurrance5,
        headerText: '%NV đóng',

        // field: 'JoinedOn',
        template: this.colDeductInsurrance5,
        width: '120',
      },
      {
        // headerTemplate: this.grvSetup['Status']['headerText'],
        // headerTemplate: this.headerDeductInsurrance6,
        headerText: 'Số tiền Cty đóng',

        // field: 'Status',
        template: this.colDeductInsurrance6,
        width: '120',
      },
      {
        // headerTemplate: this.grvSetup['Status']['headerText'],
        // headerTemplate: this.headerDeductInsurrance7,
        headerText: 'Số tiền NV đóng',
        // field: 'Status',
        template: this.colDeductInsurrance7,
        width: '120',
      },
      {
        // headerTemplate: this.grvSetup['Status']['headerText'],
        // headerTemplate: this.headerDeductInsurrance8,
        headerText: 'Tổng lương',

        // field: 'Status',
        template: this.colDeductInsurrance8,
        width: '120',
      },
    ];
  }

  getRefreshFlag(event){
    if(event?.field == 'rowCount'){
      this.grid.dataService.rowCount = event.value;
    }
  }

  lstTabFake: any[] = [


    {
      functionID: 1,
      customName: "Dashboard",
      largeIcon: "icon-columns_gap" // Fake icon class
    },
    {
      functionID: 2,
      customName: "Thông tin cá nhân",
      largeIcon: "icon-assignment_ind" // Fake icon class
    },
    {
      functionID: 3,
      customName: "Quá trình làm việc",
      largeIcon: "icon-timeline" // Fake icon class
    },
    {
      functionID: 4,
      customName: "Khen thưởng kỷ luật",
      largeIcon: "icon-elevator" // Fake icon class
    }

  ];

}
