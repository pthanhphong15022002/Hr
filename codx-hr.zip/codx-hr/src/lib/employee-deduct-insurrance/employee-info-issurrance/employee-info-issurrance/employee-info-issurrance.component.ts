import { ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { ApiHttpService, ButtonModel, CacheService, CallFuncService, CodxGridviewV2Component, CodxService, FormModel, ImageViewerComponent } from 'codx-core';
import { CodxShareService } from 'projects/codx-share/src/public-api';

@Component({
  selector: 'lib-employee-info-issurrance',
  templateUrl: './employee-info-issurrance.component.html',
  styleUrls: ['./employee-info-issurrance.component.scss']
})
export class EmployeeInfoIssurranceComponent {
  @Input() orgUnitID: string = 'C01';
  @Input() formModel: FormModel = null;
  @Input() lstData: any=[];
  @Input() funcID: string = 'HRT03a1';
  @Input() showManager: boolean = true;
  @Input() view: any;
  @Input() grvSetup: any;
  @Input() editable: boolean = false;
  @Input() modeView: string = 'employee';
  @Input() rowHeight: string = '50';
  @Input() showRowNumber: boolean = true;
  @Output() dataChange: EventEmitter<any> = new EventEmitter();
  @Output() gridViewDataService: EventEmitter<any> = new EventEmitter();
  totalEmployee: number = 0;
  sysMoreFunc: any[] = [];
  columnsGrid: any[];
  columnsGridContact;
  manager: any = null;
  @ViewChild('grid') grid: CodxGridviewV2Component;
  @ViewChild('headerDeductInsurrance1',{ static: true }) headerDeductInsurrance1: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance2',{ static: true }) headerDeductInsurrance2: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance3',{ static: true }) headerDeductInsurrance3: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance4',{ static: true }) headerDeductInsurrance4: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance5',{ static: true }) headerDeductInsurrance5: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance6',{ static: true }) headerDeductInsurrance6: TemplateRef<any>;
  @ViewChild('headerDeductInsurrance7',{ static: true }) headerDeductInsurrance7: TemplateRef<any>;



  @ViewChild('colDeductInsurrance1', { static: true }) colDeductInsurrance1: TemplateRef<any>;
  @ViewChild('colDeductInsurrance2', { static: true }) colDeductInsurrance2: TemplateRef<any>;
  @ViewChild('colDeductInsurrance3', { static: true }) colDeductInsurrance3: TemplateRef<any>;
  @ViewChild('colDeductInsurrance4', { static: true }) colDeductInsurrance4: TemplateRef<any>;
  @ViewChild('colDeductInsurrance5', { static: true }) colDeductInsurrance5: TemplateRef<any>;
  @ViewChild('colDeductInsurrance6', { static: true }) colDeductInsurrance6: TemplateRef<any>;
  @ViewChild('colDeductInsurrance7', { static: true }) colDeductInsurrance7: TemplateRef<any>;
  @ViewChild('colDeductInsurrance8', { static: true }) colDeductInsurrance8: TemplateRef<any>;

  // service = 'HR';
  // entityName = 'HR_Employees';
  // assemblyName = 'ERM.Business.HR';
  // className = 'EmployeesBusiness_Old';
  // method = 'GetEmployeeListByOrgUnitIDGridView';
  // idField = 'employeeID';
  // predicates = '@0.Contains(OrgUnitID)';
  // service = 'HR';
  // assemblyName = 'ERM.Business.Core';
  // method = 'LoadDataAsync';
  // className = 'DataBusiness';
  // entityName = 'HR_SocialIns';
  // idField = 'recID';
  // predicates='';

  // service = 'HR';
  // assemblyName = 'HR';
  // method = 'GetERegisterLateEarlyListAsync';
  // className = 'TSRegisterLateEarlyBusiness';
  // entityName = 'HR_TSRegisterLateEarly';
  // idField = 'recID';
  // predicates='';

  service = 'HR';
  assemblyName = 'HR';
  method = 'GetESocialInsListAsync';
  className = 'SocialInsBusiness';
  entityName = 'HR_SocialIns';
  idField = 'recID';
  predicates='';


  funcIDEmpInfor: string = 'HRT03b';
  itemSelected;
  
  hadEmitDataService = false;
  inputTimes = 0;
  constructor(
    private cache: CacheService,
    private api: ApiHttpService,
    private dt: ChangeDetectorRef,
    private callfc: CallFuncService,
    private shareService: CodxShareService,
    private codxService: CodxService) { }

  ngOnInit(): void {

    console.log(this.lstData);
    // get more funtion hệ thống
    this.cache.moreFunction('CoDXSystem', '').subscribe((mFuc: any) => {
      if (mFuc) this.sysMoreFunc = mFuc;
    });

    this.initColumnGrid();

  }
  
  ngAfterViewInit(): void {
    this.initColumnGrid();
    // this.onScroll(); // Kiểm tra ngay khi tải trang

  }

  initColumnGrid() {


    if(!this.columnsGrid){
      this.columnsGrid = [
        {
          headerTemplate:  this.headerDeductInsurrance1,
          // headerText: 'Nhân viên',
          // field: 'EmployeeName',
          template: this.colDeductInsurrance1,
          width: '300',
        },
        {
          // headerTemplate: this.grvSetup['Birthday']['headerText'],
          headerTemplate: this.headerDeductInsurrance2,
          template: this.colDeductInsurrance2,
          width: '120',
        },
        {
          // headerTemplate: this.grvSetup['Phone']['headerText'],
          headerTemplate: this.headerDeductInsurrance3,
          template: this.colDeductInsurrance3,
          width: '120',
        },
        {
          // headerTemplate: this.grvSetup['Email']['headerText'],
          headerTemplate: this.headerDeductInsurrance4,
          template: this.colDeductInsurrance4,
          width: '120',
        },
        {
          // headerTemplate: this.grvSetup['JoinedOn']['headerText'],
          headerTemplate: this.headerDeductInsurrance5,
          template: this.colDeductInsurrance5,
          width: '120',
        },
        {
          // headerTemplate: this.grvSetup['Status']['headerText'],
          headerTemplate: this.headerDeductInsurrance6,
          template: this.colDeductInsurrance6,
          width: '120',
        },
        {
          // headerTemplate: this.grvSetup['Status']['headerText'],
          headerTemplate: this.headerDeductInsurrance7,
          template: this.colDeductInsurrance7,
          width: '120',
        }
      ];
    }
  }

  getRefreshFlag(event){
    if(event?.field == 'rowCount'){
      this.grid.dataService.rowCount = event.value;
    }
  }

}
