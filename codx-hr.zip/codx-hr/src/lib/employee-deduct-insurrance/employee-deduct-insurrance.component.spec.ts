import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeDeductInsurranceComponent } from './employee-deduct-insurrance.component';

describe('EmployeeDeductInsurranceComponent', () => {
  let component: EmployeeDeductInsurranceComponent;
  let fixture: ComponentFixture<EmployeeDeductInsurranceComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeDeductInsurranceComponent]
    });
    fixture = TestBed.createComponent(EmployeeDeductInsurranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
