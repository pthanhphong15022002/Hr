import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from '../_layout/layout.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeDeductInsurranceComponent } from './employee-deduct-insurrance.component'; 
import { CoreModule } from '@core/core.module';
import { CodxCoreModule } from 'codx-core';
import { EmployeeInfoIssurranceComponent } from './employee-info-issurrance/employee-info-issurrance/employee-info-issurrance.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '@shared/shared.module';
import { FormsModule } from '@angular/forms';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClientModule } from '@angular/common/http';
import { DirectivesModule } from '../codx-hr-common/directives/directives.module';
import { CodxHRCommonModule } from '../codx-hr-common/codx-hr-common.module';
import { TabModule } from '@syncfusion/ej2-angular-navigations';
import { TranformValueNumberPipe } from 'projects/codx-ac/src/lib/pipes/tranform-value-number.pipe';
import { EmployeeLstByOrgComponent } from './popup/employee-lst-by-org/employee-lst-by-org.component';
import { SidebarTreeviewORGComponent } from './component/sidebar-treeview/sidebar-treeview.component';
import { ListDeductInssuranceComponent } from './popup/list-deduct-inssurance/list-deduct-inssurance.component';
import { MinusAdditionalAmountsComponent } from './popup/minus-additional-amounts/minus-additional-amounts.component'; 

export const routes: Routes = [
  {
    // hr/socialins/HRT104
    path:'',
    component: LayoutComponent,
    children:[
      {
        path:'socialins/:funcID',
        component: EmployeeDeductInsurranceComponent,
      },
      {
        path: '**',
        redirectTo: 'error/404',
      },
    ]
  }
];

const T_Component = [
  EmployeeDeductInsurranceComponent,
  EmployeeInfoIssurranceComponent,
  EmployeeLstByOrgComponent,
  EmployeeLstByOrgComponent,
  SidebarTreeviewORGComponent,
  ListDeductInssuranceComponent,
  MinusAdditionalAmountsComponent
];


@NgModule({
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    CoreModule,
    NgbModule,
    FormsModule,
    SharedModule,
    OverlayModule,
    HttpClientModule,
    DirectivesModule,
    CodxHRCommonModule,
    TabModule,
    TranformValueNumberPipe

  ],
  declarations: [T_Component, ListDeductInssuranceComponent, MinusAdditionalAmountsComponent],

})
export class EmployeeDeductInsurranceModule { }
