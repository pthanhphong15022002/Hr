import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from '../_layout/layout.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeDeductInsurranceComponent } from './employee-deduct-insurrance.component'; 
import { CoreModule } from '@core/core.module';
import { CodxCoreModule } from 'codx-core';
import { EmployeeInfoIssurranceComponent } from './employee-info-issurrance/employee-info-issurrance/employee-info-issurrance.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { SharedModule } from '@shared/shared.module';
import { FormsModule } from '@angular/forms';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClientModule } from '@angular/common/http';
import { DirectivesModule } from '../codx-hr-common/directives/directives.module';
import { CodxHRCommonModule } from '../codx-hr-common/codx-hr-common.module';
import { TabModule } from '@syncfusion/ej2-angular-navigations';
import { TranformValueNumberPipe } from 'projects/codx-ac/src/lib/pipes/tranform-value-number.pipe';

export const routes: Routes = [
  {
    path:'',
    component: LayoutComponent,
    children:[
      {
        path:'deductinsurrance/:funcID',
        component: EmployeeDeductInsurranceComponent,
      },
      {
        path: '**',
        redirectTo: 'error/404',
      },
    ]
  }
];

const T_Component = [
  EmployeeDeductInsurranceComponent,
  EmployeeInfoIssurranceComponent
];


@NgModule({
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    CoreModule,
    NgbModule,
    FormsModule,
    SharedModule,
    OverlayModule,
    HttpClientModule,
    DirectivesModule,
    CodxHRCommonModule,
    TabModule,
    TranformValueNumberPipe

  ],
  declarations: [T_Component],

})
export class EmployeeDeductInsurranceModule { }
