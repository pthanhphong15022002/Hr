import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeOvertimeViewDetailComponent } from './employee-overtime-view-detail.component';

describe('EmployeeOvertimeViewDetailComponent', () => {
  let component: EmployeeOvertimeViewDetailComponent;
  let fixture: ComponentFixture<EmployeeOvertimeViewDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmployeeOvertimeViewDetailComponent]
    });
    fixture = TestBed.createComponent(EmployeeOvertimeViewDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
