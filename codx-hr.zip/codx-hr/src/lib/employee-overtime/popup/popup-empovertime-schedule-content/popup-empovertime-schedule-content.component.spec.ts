import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PopupEmpovertimeScheduleContentComponent } from './popup-empovertime-schedule-content.component';

describe('PopupEmpovertimeScheduleContentComponent', () => {
  let component: PopupEmpovertimeScheduleContentComponent;
  let fixture: ComponentFixture<PopupEmpovertimeScheduleContentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PopupEmpovertimeScheduleContentComponent]
    });
    fixture = TestBed.createComponent(PopupEmpovertimeScheduleContentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
