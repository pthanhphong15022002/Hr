














import { OverlayModule } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import {
  CUSTOM_ELEMENTS_SCHEMA,
  ModuleWithProviders,
  NgModule,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { CoreModule } from '@core/core.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ChartAllModule } from '@syncfusion/ej2-angular-charts';
import { DiagramAllModule } from '@syncfusion/ej2-angular-diagrams';
import { SliderModule } from '@syncfusion/ej2-angular-inputs';
import { CodxCoreModule, EnvironmentConfig } from 'codx-core';
import { LayoutNoAsideComponent } from 'projects/codx-common/src/lib/_layout/_noAside/_noAside.component';


import { OrgorganizationComponent } from './organization/organization.component';
import { OrganizeDetailComponent } from './organization/organize-detail/organize-detail.component';
import { PopupAddOrganizationComponent } from './organization/popup-add-organization/popup-add-organization.component';
import { OrgchartDetailComponent } from './reportingline/orgchart-detail/orgchart-detail.component';
import { PopupAddPositionsComponent } from './reportingline/popup-add-positions/popup-add-positions.component';
import { ReportinglineDetailComponent } from './reportingline/reportingline-detail/reportingline-detail.component';
import { ReportinglineOrgChartComponent } from './reportingline/reportingline-orgchart/reportingline-orgchart.component';
import { ReportinglineComponent } from './reportingline/reportingline.component';
//import { NoSubAsideComponent } from './_noSubAside/_noSubAside.component';







import { OrganizationOrgchartComponent } from './organization/organization-orgchart/organization-orgchart.component';
import { OrganizationMasterDetailComponent } from './organization/organization-master-detail/organization-master-detail.component';
import { OrganizationListComponent } from './organization/organization-list/organization-list.component';














import { LayoutComponent } from 'projects/codx-hr/src/lib/_layout/layout.component';
//import { HRLayoutOnlyHeaderComponent } from 'projects/codx-hr/src/lib/_layout_onlyHeader/_layout_onlyHeader.component';





























import { BasicPrimitivesModule } from 'ngx-basic-primitives';
import { OrgEmpContactDetailCardComponent } from './empcontacts/org-emp-contact-detail-card/org-emp-contact-detail-card.component';











import { SpeedDialModule } from '@syncfusion/ej2-angular-buttons';




import { TableGripComponent } from './dashboard/components/table-grip/table-grip.component';
import { DirectivesModule } from './codx-hr-common/directives/directives.module';
import { DashboardModule } from './dashboard/dashboard.module';
import { DialogRegisterApproveComponent } from './dashboard/components/dialog-register-approve/dialog-register-approve.component';


import { HrTableNewemployeeComponent } from './dashboard/widgets/hr-table-newemployee/hr-table-newemployee.component';
import { HrParametersModule } from './hrparameters/hrparameters.module';
import { CodxHRCommonModule } from './codx-hr-common/codx-hr-common.module';

import { EmployeesModule } from './employees/employees.module';
import { EmpContactsComponent } from './empcontacts/emp-contacts.component';
const routes: Routes = [
  {
    path: '',
    component: LayoutNoAsideComponent,
    children: [
      {
        path: 'contactbook/:funcID',
        component: EmpContactsComponent,
      },
    ],
  },{
    path: '',
    component:LayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () => import('./dashboard/dashboard.module').then(m => m.DashboardModule)
      },
      {
        path: '',
        loadChildren: () => import('./employees/employees.module').then(m => m.EmployeesModule)
      },
      {
        path: 'setting',
        loadChildren: () => import('./hrparameters/hrparameters.module').then(m => m.HrParametersModule)
      },
    ],
  },
  {
    path: '**',
    redirectTo: 'error/404',
  },

];

const T_Component = [
  EmpContactsComponent,
  ReportinglineComponent,
  OrgorganizationComponent,
  OrganizeDetailComponent,
  OrgchartDetailComponent,
  PopupAddOrganizationComponent,
  PopupAddPositionsComponent,
  ReportinglineOrgChartComponent,
  ReportinglineDetailComponent,
  OrganizationOrgchartComponent,
  OrganizationMasterDetailComponent,
  OrganizationListComponent,
  OrgEmpContactDetailCardComponent,
  TableGripComponent,

  DialogRegisterApproveComponent,
  HrTableNewemployeeComponent,

];
const T_Module = [
  CommonModule,
  FormsModule,
  OverlayModule,
  HttpClientModule,
  CoreModule,
  SliderModule,
 // CodxShareModule,
  ChartAllModule,
  DiagramAllModule,
  NgbModule,
  BasicPrimitivesModule,
  SpeedDialModule,
  DirectivesModule,
  CodxHRCommonModule,
  //module lazyLoading
  HrParametersModule,
  DashboardModule,
  EmployeesModule
]

@NgModule({
  imports: [
    ...T_Module,
    RouterModule.forChild(routes),
  ],
  exports: [T_Component],
  declarations: [T_Component],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class CodxHROldModule {}
