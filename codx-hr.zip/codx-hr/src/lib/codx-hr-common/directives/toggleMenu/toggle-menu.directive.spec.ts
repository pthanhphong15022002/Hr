import { ToggleMenuDirective } from './toggle-menu.directive';

describe('ToggleMenuDirective', () => {
  it('should create an instance', () => {
    const directive = new ToggleMenuDirective();
    expect(directive).toBeTruthy();
  });
});
