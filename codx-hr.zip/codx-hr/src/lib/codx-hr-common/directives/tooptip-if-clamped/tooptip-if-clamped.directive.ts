import { Directive, ElementRef, Renderer2, Input, OnChanges, SimpleChanges, Injector, OnDestroy } from '@angular/core';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectorRef } from '@angular/core';

@Directive({
  selector: '[tooltipIfClamped]'
})
export class TooltipIfClampedDirective implements OnChanges, OnDestroy {
  @Input('tooltipIfClamped') tooltipText!: string;
  private resizeObserver: ResizeObserver;
  private needsCheck: boolean = false;

  constructor(
    private el: ElementRef,
    private injector: Injector,
    private renderer: Renderer2,
    private cdRef: ChangeDetectorRef
  ) {
    this.resizeObserver = new ResizeObserver(() => this.checkTooltip());
    this.resizeObserver.observe(this.el.nativeElement);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['tooltipText']) {
      this.needsCheck = true;
      this.cdRef.detectChanges();
    }

    if (this.needsCheck) {
      this.checkTooltip();
      this.needsCheck = false;
    }
  }

  ngOnDestroy() {
    this.resizeObserver.unobserve(this.el.nativeElement);
  }

  private checkTooltip() {
    const element = this.el.nativeElement;
    const height = element.getBoundingClientRect().height;
    const offsetWidth = element.offsetWidth;

    if (!this.tooltipText?.trim()) {
      const textContent = element.textContent?.trim();
      if (textContent) {
        this.tooltipText = textContent;
      }
    }

    const span = document.createElement('span');
    span.style.position = 'absolute';
    span.style.visibility = 'hidden';
    span.style.whiteSpace = 'nowrap';
    span.innerText = element.innerText;
    document.body.appendChild(span);
    const contentWidth = span.offsetWidth;
    document.body.removeChild(span);

    if (height > 25 || offsetWidth < contentWidth) {
      const ngbTooltip = this.injector.get(NgbTooltip);
      ngbTooltip.ngbTooltip = this.tooltipText;
      this.renderer.addClass(element, 'line-clamp');
      this.renderer.addClass(element, 'line-clamp-1');
    } else {
      const ngbTooltip = this.injector.get(NgbTooltip);
      ngbTooltip.ngbTooltip = null;
      ngbTooltip.close();
      this.renderer.removeClass(element, 'line-clamp');
      this.renderer.removeClass(element, 'line-clamp-1');
    }
  }
}
