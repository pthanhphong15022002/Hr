import { Directive, ElementRef, Renderer2, Input, OnChanges, SimpleChanges, Injector } from '@angular/core';
import { NgbTooltip } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectorRef } from '@angular/core';

@Directive({
  selector: '[tooltipIfClamped]'
})
export class TooltipIfClampedDirective implements OnChanges {
  @Input('tooltipIfClamped') tooltipText!: string;
  private observer: MutationObserver | undefined;

  constructor(
    private el: ElementRef,
    private injector: Injector,
    private renderer: Renderer2,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnChanges(changes: SimpleChanges) {
    if (changes.tooltipText) {
      // Đảm bảo Angular đã cập nhật xong trước khi thực hiện kiểm tra
      this.cdRef.detectChanges();
      this.checkTooltip();
      this.startObserving();
    }
  }

  ngOnDestroy() {
    this.stopObserving();
  }

  private startObserving() {
    this.observer = new MutationObserver(() => {
      this.checkTooltip();
    });
    this.observer.observe(this.el.nativeElement, { attributes: true, childList: false, subtree: false, characterData: false, attributeFilter: ['style'] });
  }

  private stopObserving() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }

  private checkTooltip() {
    const element = this.el.nativeElement;
    const height = element.getBoundingClientRect().height;

    // Kiểm tra nếu tooltipText không được nhập
    if (!this.tooltipText || this.tooltipText.trim() === '') {
      // Lấy nội dung của phần tử
      const textContent = element.textContent?.trim();
      if (textContent) {
        // Gán nội dung của phần tử làm nội dung cho tooltip
        this.tooltipText = textContent;
      }
    }

    if (element.offsetHeight > 25 || element.scrollWidth > element.clientWidth ) {
      const ngbTooltip = this.injector.get(NgbTooltip);
      ngbTooltip.ngbTooltip = this.tooltipText;

      this.renderer.addClass(element, 'line-clamp');
      this.renderer.addClass(element, 'line-clamp-1');
    } else {
      const ngbTooltip = this.injector.get(NgbTooltip);
      ngbTooltip.ngbTooltip = null;
      ngbTooltip.close();

      this.renderer.removeClass(element, 'line-clamp');
      this.renderer.removeClass(element, 'line-clamp-1');
    }
  }
}
