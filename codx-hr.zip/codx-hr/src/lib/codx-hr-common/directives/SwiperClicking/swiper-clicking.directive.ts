
import { Directive, ElementRef, HostListener, Input, Renderer2 } from '@angular/core';

@Directive({
  selector: '[libSwiperClicking]'
})
export class SwiperClickingDirective {
  private swiperMain!: HTMLDivElement;
  @Input() ContainerID: string = '';
  @Input() type!: string;
  @Input() scrollSpeed:number = 100;


  constructor(private elementRef: ElementRef, private renderer: Renderer2) { }

  @HostListener('document:click', ['$event.target'])
  onClick(target: any): void {
    if (this.elementRef.nativeElement.contains(target)) {
      this.swiperMain = document.getElementById(this.ContainerID) as HTMLDivElement;
      this.swiperMain.style.scrollBehavior = 'smooth';
      if (this.swiperMain) {
        const childElements = Array.from(this.swiperMain.children) as HTMLElement[];

        if (this.type === 'next') {
          const nextElement = this.findNextElement(childElements);
          if (nextElement) {
            const scrollAmount = nextElement.offsetLeft + nextElement.offsetWidth - this.swiperMain.scrollLeft - this.swiperMain.offsetWidth -this.swiperMain.offsetLeft ;
            this.swiperMain.scrollLeft += scrollAmount;          }
        } else if (this.type === 'previous') {
          const prevElement = this.findPreviousElement(childElements);
          if (prevElement) {
            console.log(prevElement.scrollLeft)
            console.log(prevElement.offsetLeft)
            console.log(prevElement.offsetWidth)

            const scrollAmount = this.swiperMain.scrollLeft + this.swiperMain.offsetLeft -  prevElement.offsetLeft;
            this.swiperMain.scrollLeft -= scrollAmount ;
          }
        }
      }
    }
  }

  private findNextElement(elements: HTMLElement[]): HTMLElement | null {
    let currentScroll = this.swiperMain.scrollLeft;
    console.log('    const currentScroll = this.swiperMain.scrollLeft;    ', currentScroll)
    let currentElementIndex = -1;

    for (let i = elements.length - 1; i >= 0; i--) {
      console.log(`Element ${i}: offsetLeft = ${elements[i].offsetLeft}, offsetWidth = ${elements[i].offsetWidth}`);
      console.log(elements[i].offsetLeft + elements[i].offsetWidth)
      console.log(currentScroll + this.swiperMain.offsetWidth + this.swiperMain.offsetLeft)
      var a = elements[i].offsetLeft + elements[i].offsetWidth - this.swiperMain.offsetWidth - this.swiperMain.offsetLeft + 6
      console.log(a)
      if (elements[i].offsetLeft >= currentScroll &&
          elements[i].offsetLeft + elements[i].offsetWidth  <= currentScroll + this.swiperMain.offsetWidth + this.swiperMain.offsetLeft + 6) {
            
        currentElementIndex = i;
        console.log(elements[currentElementIndex]);
        break;
      }
    }
    // If no element is found, return the first element
    if (currentElementIndex > 0) {
      console.log(`Returning previous element index: ${currentElementIndex - 1}`);
      console.log(elements[currentElementIndex + 1]);
      return elements[currentElementIndex + 1];
    } else {
      console.log('No previous element found');
    }

    return null;
  }


  private findPreviousElement(elements: HTMLElement[]): HTMLElement | null {
  const currentScroll = this.swiperMain.scrollLeft;
  let currentElementIndex = -1;

  for (let i = 0; i < elements.length; i++) {
    console.log(`Element ${i}: offsetLeft = ${elements[i].offsetLeft}, offsetWidth = ${elements[i].offsetWidth}`);

    if (elements[i].offsetLeft >= currentScroll && elements[i].offsetLeft < currentScroll + this.swiperMain.offsetWidth) {
      currentElementIndex = i;
      console.log(elements[currentElementIndex])

      break;
    }
  }

  if (currentElementIndex > 0) {
    return elements[currentElementIndex - 1];
  }

  return null;
}
}



