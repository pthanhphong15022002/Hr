export class DataVll {
  color: string;
  default: string;
  icon: string;
  idx: string;
  text: string;
  textColor: string;
  value: string;
}
