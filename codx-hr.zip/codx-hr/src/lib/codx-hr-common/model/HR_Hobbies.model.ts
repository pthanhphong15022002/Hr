export class HR_Hobbies {
    public recID: string;
    public employeeID: string;
    public catagory: string;
    public hobbyName: string;
    public color: string;
}