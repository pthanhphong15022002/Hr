import { ChangeDetectorRef, Component, ElementRef, EventEmitter, HostListener, Input, Output, TemplateRef, ViewChild } from '@angular/core';
import { ApiHttpService, ButtonModel, CacheService, CallFuncService, CodxGridviewV2Component, CodxService, FormModel, ImageViewerComponent } from 'codx-core';
import { CodxShareService } from 'projects/codx-share/src/public-api';

@Component({
  selector: 'employee-leave-list',
  templateUrl: './employee-leave-list.component.html',
  styleUrls: ['./employee-leave-list.component.scss']
})
export class EmployeeLeaveListComponent {
  @Input() orgUnitID: string = 'C01';
  @Input() formModel: FormModel = null;
  @Input() showManager: boolean = true;
  @Input() view: any;
  @Input() grvSetup: any;
  @Input() editable: boolean = false;
  @Input() modeView: string = 'employee';
  @Input() rowHeight: string = '50';
  @Input() showRowNumber: boolean = true;
  @Input() funcID: string = 'HRT03a1';
  @Output() dataChange: EventEmitter<any> = new EventEmitter();
  @Output() gridViewDataService: EventEmitter<any> = new EventEmitter();
  totalEmployee: number = 0;
  sysMoreFunc: any[] = [];
  columnsGrid: any[];
  columnsGridContact;
  manager: any = null;
  @ViewChild('grid') grid: CodxGridviewV2Component;
  @ViewChild('headerGridView1',{ static: true }) headerGridView1: TemplateRef<any>;
  @ViewChild('headerGridView2',{ static: true }) headerGridView2: TemplateRef<any>;
  @ViewChild('headerGridView3',{ static: true }) headerGridView3: TemplateRef<any>;
  @ViewChild('headerGridView4',{ static: true }) headerGridView4: TemplateRef<any>;
  @ViewChild('headerGridView5',{ static: true }) headerGridView5: TemplateRef<any>;
  @ViewChild('headerGridView6',{ static: true }) headerGridView6: TemplateRef<any>;
  @ViewChild('headerGridView7',{ static: true }) headerGridView7: TemplateRef<any>;



  @ViewChild('colGridView1', { static: true }) colGridView1: TemplateRef<any>;
  @ViewChild('colGridView2', { static: true }) colGridView2: TemplateRef<any>;
  @ViewChild('colGridView3', { static: true }) colGridView3: TemplateRef<any>;
  @ViewChild('colGridView4', { static: true }) colGridView4: TemplateRef<any>;
  @ViewChild('colGridView5', { static: true }) colGridView5: TemplateRef<any>;
  @ViewChild('colGridView6', { static: true }) colGridView6: TemplateRef<any>;
  @ViewChild('colGridView7', { static: true }) colGridView7: TemplateRef<any>;
  @ViewChild('colGridView8', { static: true }) colGridView8: TemplateRef<any>;

  // service = 'HR';
  // entityName = 'HR_Employees';
  // assemblyName = 'ERM.Business.HR';
  // className = 'EmployeesBusiness_Old';
  // method = 'GetEmployeeListByOrgUnitIDGridView';
  // idField = 'employeeID';
  // predicates = '@0.Contains(OrgUnitID)';
  // funcIDEmpInfor: string = 'HRT03b';

  //  service = 'HR';
  // entityName = 'HR_Employees';
  // assemblyName = 'ERM.Business.HR';
  // className = 'EmployeesBusiness_Old';
  // method = 'GetEmployeeListByOrgUnitIDGridView';
  // idField = 'employeeID';
  // predicates = '@0.Contains(OrgUnitID)';

  service = 'HR';
  assemblyName = 'ERM.Business.HR';
  method = 'GetListEmployeeAnnualLeaveMonthGrvV2Async';
  className = 'EAnnualLeavesBusiness';
  entityName = 'HR_EAnnualLeave';
  idField = 'recID';
  predicates='';

  itemSelected;
  
  hadEmitDataService = false;
  inputTimes = 0;
  constructor(
    private cache: CacheService,
    private api: ApiHttpService,
    private dt: ChangeDetectorRef,
    private callfc: CallFuncService,
    private shareService: CodxShareService,
    private codxService: CodxService) { }

  ngOnInit(): void {

    console.log(this.formModel);
    // get more funtion hệ thống
    this.cache.moreFunction('CoDXSystem', '').subscribe((mFuc: any) => {
      if (mFuc) this.sysMoreFunc = mFuc;
    });

    this.initColumnGrid();

  }
  
  ngAfterViewInit(): void {
    this.initColumnGrid();
    // this.onScroll(); // Kiểm tra ngay khi tải trang

  }

  // @ViewChild('tableContainer') tableContainer: ElementRef;

 
  // @HostListener('window:scroll', ['$event'])
  // onScroll() {
  //   console.log('bắt');
  //   const tableContainerEl = this.tableContainer.nativeElement;
  //   const stickyCells = tableContainerEl.querySelectorAll('.e-templatecell');
  //   stickyCells.forEach(cell => {
  //     const cellRect = cell.getBoundingClientRect();
  //     const containerRect = tableContainerEl.getBoundingClientRect();
  //     if (cellRect.left < containerRect.left && tableContainerEl.scrollLeft > 0) {
  //       cell.classList.add('sticky-active');
  //     } else {
  //       cell.classList.remove('sticky-active');
  //     }
  //   });
  // }

  initColumnGrid() {


    if(!this.columnsGrid){
      this.columnsGrid = [
        {
          headerTemplate:  this.headerGridView1,
          // headerText: 'Nhân viên',
          // field: 'EmployeeName',
          template: this.colGridView1,
          width: '250',
        },
        {
          // headerTemplate: this.grvSetup['Birthday']['headerText'],
          headerTemplate: this.headerGridView2,
          // headerText: 'Mức lương',
  
          // field: 'Birthday',
          template: this.colGridView2,
          width: '200',
        },
        {
          // headerTemplate: this.grvSetup['Phone']['headerText'],
          headerTemplate: this.headerGridView3,
          // headerText: 'Tổng phụ cấp',
  
          // field: 'Phone',
          template: this.colGridView3,
          width: '200',
        },
        {
          // headerTemplate: this.grvSetup['Email']['headerText'],
          headerTemplate: this.headerGridView4,
          // headerText: '%Cty đóng',
          // field: 'Email',
          template: this.colGridView4,
          width: '200',
        },
        {
          // headerTemplate: this.grvSetup['JoinedOn']['headerText'],
          headerTemplate: this.headerGridView5,
          // headerText: '%NV đóng',
  
          // field: 'JoinedOn',
          template: this.colGridView5,
          width: '200',
        },
        // {
        //   // headerTemplate: this.grvSetup['Status']['headerText'],
        //   headerTemplate: this.headerGridView6,
        //   // headerText: 'Số tiền Cty đóng',
  
        //   // field: 'Status',
        //   template: this.colGridView6,
        //   width: '120',
        // },
        // {
        //   // headerTemplate: this.grvSetup['Status']['headerText'],
        //   headerTemplate: this.headerGridView7,
        //   // headerText: 'Số tiền NV đóng',
        //   // field: 'Status',
        //   template: this.colGridView7,
        //   width: '120',
        // }
      ];
    }
  }

  getRefreshFlag(event){
    if(event?.field == 'rowCount'){
      this.grid.dataService.rowCount = event.value;
    }
  }

  lstTabFake: any[] = [


    {
      functionID: 1,
      customName: "Dashboard",
      largeIcon: "icon-columns_gap" // Fake icon class
    },
    {
      functionID: 2,
      customName: "Thông tin cá nhân",
      largeIcon: "icon-assignment_ind" // Fake icon class
    },
    {
      functionID: 3,
      customName: "Quá trình làm việc",
      largeIcon: "icon-timeline" // Fake icon class
    },
    {
      functionID: 4,
      customName: "Khen thưởng kỷ luật",
      largeIcon: "icon-elevator" // Fake icon class
    }

  ];

}

