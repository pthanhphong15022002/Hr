import {
  ChangeDetectorRef,
  Component,
  Injector,
  OnDestroy,
  TemplateRef,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  ApiHttpService,
  AuthStore,
  ButtonModel,
  CodxListviewComponent,
  CodxService,
  FormModel,
  NotificationsService,
  PageTitleService,
  ResourceModel,
  UIComponent,
  UserModel,
  Util,
  ViewModel,
  ViewType,
  ViewsComponent,
} from 'codx-core';
import { Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'lib-emp-contacts',
  templateUrl: './emp-contacts.component.html',
  styleUrls: ['./emp-contacts.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class EmpContactsComponent extends UIComponent implements OnDestroy {
  
  @ViewChild('headerTemplateList') headerTemplateList: TemplateRef<any>;
  @ViewChild('itemTemplateList') itemTemplateList: TemplateRef<any>;
  @ViewChild('itemTemplateCard') itemTemplateCard: TemplateRef<any>;

  @ViewChild('tmpColEmployeeID') tmpColEmployeeID: TemplateRef<any>;
  @ViewChild('tmpColEmployeeName') tmpColEmployeeName: TemplateRef<any>;
  @ViewChild('tmpColContact') tmpColContact: TemplateRef<any>;
  @ViewChild('tmpColInfo') tmpColInfo: TemplateRef<any>;

  views: ViewModel[] = [];
  request: ResourceModel;
  itemSelected: any;
  columnsGrid = [];
  user:UserModel = null;
  destroy$ = new Subject<void>();
  constructor
  (
    private inject: Injector,
    private auth:AuthStore,
    private notisv:NotificationsService,
    private pageTitle:PageTitleService

  ) 
  { 
    super(inject); 
    this.user = auth.get();
  }


  onInit(): void {
    
  }

  ngAfterViewInit(): void {
    this.columnsGrid = [
      {
        field: 'employeeID',
        headerText: 'Mã nhân viên',
        width: 100,
        template: this.tmpColEmployeeID,
      },
      {
        field: 'employeeName',
        headerText: 'Họ tên',
        width: 300,
        template: this.tmpColEmployeeName,
      },
      {
        field: 'birthday',
        headerText: 'Thông tin cá nhân',
        width: 300,
        template: this.tmpColInfo,
      },
      {
        field: 'email',
        headerText: 'Liên hệ',
        width: 300,
        template: this.tmpColContact,
      }
    ];
    this.views = [
      {
        id: '1',
        type: ViewType.list,
        sameData: true,
        model: {
          template: this.itemTemplateList,
          headerTemplate: this.headerTemplateList,
        },
      },
      {
        id: '2',
        type: ViewType.card,
        sameData: true,
        model: {
          template: this.itemTemplateCard,
        },
      },
      {
        id: '3',
        type: ViewType.grid,
        sameData: true,
        model: {
          //resources: this.columnsGrid, Chị Thương muốn view lưới dạng thuần túy
          hideMoreFunc:true
        },
      },
    ];
  }

  ngOnDestroy(): void { 
    this.destroy$.next();
    this.destroy$.complete();
  }

  onLoading(event:any){
    this.api.execSv("HR","HR","EmployeesBusiness_Old","GetCountFavoriteAsync",[this.view.funcID])
    .pipe(takeUntil(this.destroy$))
    .subscribe((res:any) => {
      if(res)
      {
        let data = res.map(item => Util.camelizekeyObj(item));
        let breadCrumb = { title:""};
        let favActive = data.find(x => x.recID == this.view.codxService.activeFav);
        if(favActive)
          breadCrumb.title = `${favActive.favorite} (${favActive.count})`;
        this.pageTitle.setBreadcrumbs([breadCrumb]);
        this.pageTitle.setFavs({function: null, favs: data});
      }
    });
  }

  changeDataMF(event:any){
    event.forEach(item => {item.disabled = item.functionID != "WPT0501";});
  }

  clickMF(event:any){
    let data = this.view.dataService.dataSelected;
    if(!event || !data) return;
    switch(event.functionID)
    {
      case "WPT0501":
        this.favorite(data);
        break;
      default:
        break;
    }
  }

  favorite(employee:any){
    if(!employee) return;
    this.api.execSv("WP","WP","ContactFavoriteBusiness","InsertFavoriteAsync",[employee.employeeID,employee.employeeName,employee.userID])
    .pipe(takeUntil(this.destroy$))
    .subscribe((res:boolean) => {
      if(res)
      {
        if(!employee.favorite)
          employee.favorite = true;
        else
          employee.favorite = false;
        this.notisv.notifyCode("SYS007");
        this.detectorRef.detectChanges();
      }
      else
      {
        this.notisv.notifyCode("SYS021");
      }
    });
  }

}