import {
  ChangeDetectorRef,
  Component,
  Injector,
  TemplateRef,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import {
  ApiHttpService,
  AuthStore,
  ButtonModel,
  CodxListviewComponent,
  CodxService,
  FormModel,
  PageTitleService,
  ResourceModel,
  UIComponent,
  UserModel,
  Util,
  ViewModel,
  ViewType,
  ViewsComponent,
} from 'codx-core';
import { catchError, map, Observable, of, finalize, Subscription, Subject, takeUntil } from 'rxjs';

@Component({
  selector: 'lib-emp-contacts',
  templateUrl: './emp-contacts.component.html',
  styleUrls: ['./emp-contacts.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class EmpContactsComponent extends UIComponent {
  
  @ViewChild('colEmployeeName') colEmployeeName: TemplateRef<any>;
  @ViewChild('colPhone') colPhone: TemplateRef<any>;
  @ViewChild('colEmail') colEmail: TemplateRef<any>;
  @ViewChild('colStatus') colStatus: TemplateRef<any>;
  @ViewChild('headerTemplate') headerTemplate: TemplateRef<any>;
  @ViewChild('itemTemplateList') itemTemplateList: TemplateRef<any>;
  @ViewChild('itemTemplateCard') itemTemplateCard: TemplateRef<any>;


  views: ViewModel[] = [];
  request: ResourceModel;
  itemSelected: any;
  columnsGrid = [];
  user:UserModel = null;
  destroy$ = new Subject<void>();
  constructor
  (
    private inject: Injector,
    private auth:AuthStore,
    private pageTitle:PageTitleService

  ) 
  { 
    super(inject); 
    this.user = auth.get();
  }


  onInit(): void {
    
  }

  ngAfterViewInit(): void {
    this.columnsGrid = [
      {
        field: 'employeeName',
        headerText: 'Họ và tên',
        template: this.colEmployeeName,
      },
      {
        field: 'employeeID',
        headerText: 'Mã nhân viên',
      },
      {
        field: 'gender',
        headerText: 'Giới tính',
      },
      {
        field: 'birthDay',
        headerText: 'Ngày sinh',
      },
      {
        field: 'phone',
        headerText: 'Di động',
        template: this.colPhone,
      },
      {
        field: 'email',
        headerText: 'Email',
        template: this.colEmail,
      },
      {
        field: 'joinedOn',
        headerText: 'Ngày vào làm',
      },
      {
        field: 'statusName',
        headerText: 'Trạng thái',
        template: this.colStatus,
      },
    ];
    this.views = [
      {
        id: '1',
        type: ViewType.list,
        sameData: true,
        model: {
          template: this.itemTemplateList,
          headerTemplate: this.headerTemplate,
        },
      },
      {
        id: '2',
        type: ViewType.card,
        sameData: true,
        model: {
          template: this.itemTemplateCard,
        },
      }
    ];
  }

  ngOnDestroy(): void { 
    this.destroy$.next();
    this.destroy$.complete();
  }

  onLoading(event:any){
    this.api.execSv("HR","HR","EmployeesBusiness_Old","GetCountFavoriteAsync",[this.view.funcID])
    .pipe(takeUntil(this.destroy$))
    .subscribe((res:any) => {
      if(res)
      {
        let data = res.map(item => Util.camelizekeyObj(item));
        let breadCrumb = { title:""};
        let favActive = data.find(x => x.recID == this.view.codxService.activeFav);
        if(favActive)
          breadCrumb.title = `${favActive.favorite} (${favActive.count})`;
        this.pageTitle.setBreadcrumbs([breadCrumb]);
        this.pageTitle.setFavs({function: null, favs: data});
      }
    });
  }

}