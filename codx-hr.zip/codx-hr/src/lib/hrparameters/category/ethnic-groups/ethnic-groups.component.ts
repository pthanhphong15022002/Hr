import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-ethnic-groups',
  templateUrl: './ethnic-groups.component.html',
  styleUrls: ['./ethnic-groups.component.css']
})
export class EthnicGroupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
