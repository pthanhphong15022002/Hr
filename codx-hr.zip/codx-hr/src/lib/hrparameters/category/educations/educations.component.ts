import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-educations',
  templateUrl: './educations.component.html',
  styleUrls: ['./educations.component.css']
})
export class EducationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
