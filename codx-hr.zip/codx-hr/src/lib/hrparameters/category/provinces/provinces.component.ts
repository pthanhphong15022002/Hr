import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-provinces',
  templateUrl: './provinces.component.html',
  styleUrls: ['./provinces.component.css']
})
export class ProvincesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
