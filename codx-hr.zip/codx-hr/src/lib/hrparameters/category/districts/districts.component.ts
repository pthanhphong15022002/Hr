import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-districts',
  templateUrl: './districts.component.html',
  styleUrls: ['./districts.component.css']
})
export class DistrictsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
