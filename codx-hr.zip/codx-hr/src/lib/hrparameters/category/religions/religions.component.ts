import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-religions',
  templateUrl: './religions.component.html',
  styleUrls: ['./religions.component.css']
})
export class ReligionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
