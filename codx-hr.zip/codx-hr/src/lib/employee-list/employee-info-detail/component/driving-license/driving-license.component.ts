import { ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CRUDService, CacheService, UIComponent } from 'codx-core';

@Component({
  selector: 'lib-driving-license',
  templateUrl: './driving-license.component.html',
  styleUrls: ['./driving-license.component.css']
})
export class DrivingLicenseComponent implements OnInit {
  
  dataService: CRUDService;
  user: any;
  mssgNoData: string = "";

  itemSelected: any = null;
  constructor (
    private dt: ChangeDetectorRef,
    private cache : CacheService,  
  ) {}
  ngOnInit(): void {
    this.initEmpPassport();
    this.initDataFakes();
    this.initFakes();
    this.cache.message("SYS010")
    .subscribe((mssg:any) => {
      if(mssg){
        this.mssgNoData = mssg.defaultName;
      }
    });
  }

  onSelectionChanged(event: any)
  {
    event.data.isActive = true;
    this.itemSelected = JSON.parse(JSON.stringify(event.data));
    this.dt.detectChanges();
  }
  
  ePassport!: any[];

  @ViewChild('templatePassportCol1', { static: true })
  templatePassportCol1: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol2', { static: true })
  templatePassportCol2: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol3', { static: true })
  templatePassportCol3: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol4', { static: true })
  templatePassportCol4: TemplateRef<any> | undefined;

  initEmpPassport() {
    if (!this.ePassport) {
      this.ePassport = [
        {
          headerText: 'Ngày mượn',
          template: this.templatePassportCol1,
          width: '25%',
        },
        {
          headerText: 'Ngày trả ',
          template: this.templatePassportCol2,
          width: '25%',
        },
        {
          headerText: 'Ghi chú',
          template: this.templatePassportCol3,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templatePassportCol4,
          width: '25%',
        },
      ];
    }
  }

  lstDataFake: any;
  initDataFakes(): void {
    this.lstDataFake = [
      {
        code: '#B5028441',
        location: 'TP Hồ Chí Minh',
        typePassport: 'PASSPORT',
        dateRange: '01/04/2024',
        dateExpire: '01/12/2024',
        note: 'Đi công tác lấy yêu cầu nghiệp vụ',
        detail: [
          {
            nationTo: 'Australia',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác',
          },
          {
            nationTo: 'Afghanistan',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác',
          },
          {
            nationTo: 'Colombia',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác',
          },
        ],
      },
    ];
  }

  lstFake: any;
  initFakes(): void {
    this.lstFake = [
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
    ];
  }
}
