import { AfterViewInit, Component, HostBinding, Injector, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { AuthStore, ButtonModel, CRUDService, CodxGridviewV2Component, CodxService, NotificationsService, RequestOption, ResourceModel, SidebarModel, UIComponent, Util, ViewModel, ViewType } from 'codx-core';
import { CodxShareService } from 'projects/codx-share/src/public-api';
import { Observable, catchError, finalize, map, of } from 'rxjs';

@Component({
  selector: 'lib-sidebar-treeview',
  templateUrl: './sidebar-treeview.component.html',
  styleUrls: ['./sidebar-treeview.component.css']
})
export class SidebarTreeviewComponent extends UIComponent implements AfterViewInit {
  
  @HostBinding('class') get valid() { return "w-100 h-100"; }
  views:ViewModel[];
  columnsGrid:any[] = [];
  gridViewSetup:any;
  dtServiceOrgUnit:CRUDService;
  dataValues:any;
  filters:any = {};
  loading:boolean = false;
  userPermission:any;
  mssgConfirm:string = "";
  itemSelected: any;
  @ViewChild("tmpLeft") tmpLeft:TemplateRef<any>;
  @ViewChild("tmpRight") tmpRight:TemplateRef<any>;
  @ViewChild("codxGridViewV2") codxGridViewV2 : CodxGridviewV2Component;
  @ViewChild("tmpColEmployee") tmpColEmployee:TemplateRef<any>;
  @ViewChild("tmpColCategory") tmpColCategory:TemplateRef<any>;
  @ViewChild("tmpColAmountF") tmpColAmountF:TemplateRef<any>;
  @ViewChild("tmpColGenDate") tmpColGenDate:TemplateRef<any>;
  @ViewChild("tmpColDowCode") tmpColDowCode:TemplateRef<any>;

  constructor(
    private injector:Injector,
    private notiSV: NotificationsService,
    private auth:AuthStore
  ) 
  {
    super(injector);
    
  }
  

  override onInit(): void {
    this.getCurrentDowCode();
    this.cache.message("HR049")
    .subscribe((mssg:any) => {
      if(mssg)
      {
        this.mssgConfirm = mssg.defaultName ?? mssg.customName;
      }
    });
    this.dtServiceOrgUnit = new CRUDService(this.injector);
    this.dtServiceOrgUnit.service = "HR";
    this.dtServiceOrgUnit.idField = "orgUnitID";
    this.dtServiceOrgUnit.parentField = "ParentID";
    this.dtServiceOrgUnit.selector= "OrgUnitID;OrgUnitName";
  }

  ngAfterViewInit(): void {
    this.views = [
      {
        type:ViewType.content,
        showFilter:true,
        sameData:false,
        model:{
          panelLeftRef: this.tmpLeft,
          collapsed: false,
          resizable: true
        }
      }
    ]; 
  }

  // get CurrentPayrollDow
  getCurrentDowCode(){
    this.api.execSv("SYS","SYS","SettingValuesBusiness","GetParameterByHRAsync",["PRParameters","1"])
    .subscribe((res:any) => {
      if(res)
      {
        let setting = JSON.parse(res)
        this.filters["DowCode"] = setting["CurrentPayrollDow"];
      }
    });
  }
  // double click gridview
  onDoubleClick(event){
    if(this.userPermission.write == "9"|| this.userPermission.isAdmin)
    {
      this.view.dataService.addNew()
      .subscribe((model:any) => {
        if(model)
        {
          model.employeeID = event.rowData.employeeID;
          let obj = {
            data:model,
            employeeID : event.rowData.employeeID,
            dowCode:this.filters.DowCode,
            userPermission : this.userPermission,
            headerText : this.view.function.defaultName ?? this.view.function.customName
          };
          let option = new SidebarModel();
          option.Width = '550px';
          option.FormModel = this.view.formModel;
          option.DataService = this.view.dataService;
        }
      });
    }
  }
  
  // select orgUnitID

  async onSelectionChanged($event) {
    await this.setEmployeePredicate($event.dataItem.orgUnitID);
    // this.employList.onChangeSearch();
  }
  setEmployeePredicate(orgUnitID): Promise<any> {
    return new Promise((resolve, reject) => {
      this.loadEOrgChartListChild(orgUnitID)
        .pipe()
        .subscribe((response) => {
          if (response) {
            var v = '';
            var p = '';
            for (let index = 0; index < response.length; index++) {
              const element = response[index];
              if (v != '') v = v + ';';
              if (p != '') p = p + '||';
              v = v + element;
              p = p + 'OrgUnitID==@' + index.toString();
            }
            // this.employList.predicate = p;
            // this.employList.dataValue = v;
          }
          resolve('');
        });
    });
  }
  loadEOrgChartListChild(orgUnitID): Observable<any> {
    return this.api
      .call(
        'ERM.Business.HR',
        'OrganizationUnitsBusiness_Old',
        'GetOrgChartListChildAsync',
        orgUnitID
      )
      .pipe(
        map((data: any) => {
          if (data.error) return;
          return data.msgBodyData[0];
        }),
        catchError((err) => {
          return of(undefined);
        }),
        finalize(() => null)
      );
  }
}