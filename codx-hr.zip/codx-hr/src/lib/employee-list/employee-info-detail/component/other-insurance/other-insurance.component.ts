import { ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CRUDService, CacheService, FormModel, UIComponent } from 'codx-core';

@Component({
  selector: 'lib-other-insurance',
  templateUrl: './other-insurance.component.html',
  styleUrls: ['./other-insurance.component.css']
})
export class OtherInsuranceComponent implements OnInit {
  
  dataService: CRUDService;
  user: any;
  mssgNoData: string = "";

  itemSelected: any = null;
  hrService: any;
  constructor (
    private dt: ChangeDetectorRef,
    private cache : CacheService,  
  ) {}
  ngOnInit(): void {
    this.initEmpInsuranceOther();
    this.initDataFakes();
    this.initFakes();
    this.cache.message("SYS010")
    .subscribe((mssg:any) => {
      if(mssg){
        this.mssgNoData = mssg.defaultName;
      }
    });
  }

  onSelectionChanged(event: any)
  {
    event.data.isActive = true;
    this.itemSelected = JSON.parse(JSON.stringify(event.data));
    this.dt.detectChanges();
  }
  
  eEmpInsuranceOtherFormModel: FormModel;
  initEInsuranceOther() {
    this.hrService.getFormModel('HREM10310').then((res) => {
      this.eEmpInsuranceOtherFormModel = res;
    }); 
  }

  eInsuranceOther!: any[];

  @ViewChild('templateInsuranceOtherCol1', { static: true })
  templateInsuranceOtherCol1: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol2', { static: true })
  templateInsuranceOtherCol2: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol3', { static: true })
  templateInsuranceOtherCol3: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol4', { static: true })
  templateInsuranceOtherCol4: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol5', { static: true })
  templateInsuranceOtherCol5: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol6', { static: true })
  templateInsuranceOtherCol6: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol7', { static: true })
  templateInsuranceOtherCol7: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol8', { static: true })
  templateInsuranceOtherCol8: TemplateRef<any> | undefined;

  initEmpInsuranceOther() {
    if (!this.eInsuranceOther) {
      this.eInsuranceOther = [
        {
          headerText: 'Ngày',
          template: this.templateInsuranceOtherCol1,
        },
        {
          headerText: 'Số tiền',
          template: this.templateInsuranceOtherCol2,
        },
        {
          headerText: 'Nguyên tệ',
          template: this.templateInsuranceOtherCol3,
        },
        {
          headerText: 'Tỉ giá quy đổi',
          template: this.templateInsuranceOtherCol4,
        },
        {
          headerText: 'Lý do',
          template: this.templateInsuranceOtherCol5,
        },
        {
          headerText: 'Chuyển vào thu nhập',
          template: this.templateInsuranceOtherCol6,
        },
        {
          headerText: 'Ghi chú',
          template: this.templateInsuranceOtherCol7,
        },
        {
          headerText: '',
          template: this.templateInsuranceOtherCol8,
        },
      ];
    }
  }

  lstDataFake: any;
  initDataFakes(): void {
    this.lstDataFake = [
      {
        code: '#B5028441',
        location: 'TP Hồ Chí Minh',
        typePassport: 'PASSPORT',
        dateRange: '01/04/2024',
        dateExpire: '01/12/2024',
        note: 'Đi công tác lấy yêu cầu nghiệp vụ',
        detail: [
          {
            nationTo: 'Australia',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác',
          },
          {
            nationTo: 'Afghanistan',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác',
          },
          {
            nationTo: 'Colombia',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác',
          },
        ],
      },
    ];
  }

  lstFake: any;
  initFakes(): void {
    this.lstFake = [
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
    ];
  }
}
