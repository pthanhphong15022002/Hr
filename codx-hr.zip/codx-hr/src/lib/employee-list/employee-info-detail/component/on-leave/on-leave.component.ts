import { ChangeDetectorRef, Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { CRUDService, CacheService, UIComponent } from 'codx-core';

@Component({
  selector: 'lib-on-leave',
  templateUrl: './on-leave.component.html',
  styleUrls: ['./on-leave.component.css']
})
export class OnLeaveComponent implements OnInit {
  
  dataService: CRUDService;
  user: any;
  mssgNoData: string = "";

  itemSelected: any = null;
  constructor (
    private dt: ChangeDetectorRef,
    private cache : CacheService,  
  ) {}
  ngOnInit(): void {
    this.initEmpPassport();
    this.initFakes();
    this.cache.message("SYS010")
    .subscribe((mssg:any) => {
      if(mssg){
        this.mssgNoData = mssg.defaultName;
      }
    });
  }
  ePassport!: any[];

  @ViewChild('templatePassportCol1', { static: true })
  templatePassportCol1: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol2', { static: true })
  templatePassportCol2: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol3', { static: true })
  templatePassportCol3: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol4', { static: true })
  templatePassportCol4: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol5', { static: true })
  templatePassportCol5: TemplateRef<any> | undefined;

  initEmpPassport() {
    if (!this.ePassport) {
      this.ePassport = [
        {
          headerText: 'Loại nghỉ',
          template: this.templatePassportCol1,
          width: '20%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templatePassportCol2,
          width: '20%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templatePassportCol3,
          width: '20%',
        },
        {
          headerText: 'Số ngày',
          template: this.templatePassportCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templatePassportCol5,
          width: '20%',
        },
      ];
    }
  }


  lstFake: any;
  initFakes(): void {
    this.lstFake = [
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
      {
        code: '#B5028441',
      },
    ];
  }
}

