import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompensatoryLeaveComponent } from './compensatory-leave.component';

describe('CompensatoryLeaveComponent', () => {
  let component: CompensatoryLeaveComponent;
  let fixture: ComponentFixture<CompensatoryLeaveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CompensatoryLeaveComponent]
    });
    fixture = TestBed.createComponent(CompensatoryLeaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
