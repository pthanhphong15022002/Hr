import { AfterViewInit, Component, ElementRef, HostListener, Input, OnInit, Renderer2, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'list-tab',
  templateUrl: './list-tab.component.html',
  styleUrls: ['./list-tab.component.scss']
})
export class ListTabComponent implements OnInit, AfterViewInit {
  @Input() item_datas: any[]
  @ViewChild('item_menu') item_menu!: ElementRef;
  @ViewChild('list_tab') list_tab!: ElementRef;
  @ViewChild('prev') prev!: ElementRef;
  @ViewChild('next') next!: ElementRef;
  isDivVisible: boolean = false
  @Input() active_item_id: any
  list_tab_function: any[] = [
    {
      id: '1',
      icon: 'assignment_ind',
      text: 'Sơ yếu lý lịch',
    },
    {
      id: '2',
      icon: 'icon-gavel',
      text: 'Thông tin pháp lý',
    },
    {
      id: '3',
      icon: 'icon-card_giftcard',
      text: 'Phúc lợi',
    },
    {
      id: '4',
      icon: 'icon-timeline',
      text: 'Quá trình làm việc',
    }, 
    {
      id: '5',
      icon: 'icon-school',
      text: 'Kiến thức',
    },
    {
      id: '6',
      icon: 'icon-elevator',
      text: 'Khen thưởng - Kỷ luật',
    }, 
    {
      id: '7',
      icon: 'icon-accessibility_new',
      text: 'Sức khỏe - Hoạt động',
    }, {
      id: '8',
      icon: 'icon-i-person-dash',
      text: 'Thôi việc',
    },
    {
      id: '9',
      icon: 'icon-eye',
      text: 'Theo dõi thay đổi',
    },
    {
      id: '10',
      icon: 'icon-reduce_capacity',
      text: 'Thành tích - Vị trí kế thừa',
    },
  ]
  currentdiv: string = ''

  public activeSubmenu: HTMLElement | null = null;

  constructor(private router: Router, private route: ActivatedRoute, private el: ElementRef,private renderer: Renderer2) {

  }
  ngAfterViewInit(): void {
    this.onCheckContainerOverflow()    
    


  }

  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    const currentWidth = window.innerWidth;
    this.onCheckContainerOverflow()
  }
  protected onCheckContainerOverflow() {
    var condition: boolean = this.list_tab.nativeElement.scrollWidth - this.list_tab.nativeElement.clientWidth > 0;
    if (condition) {
      this.prev.nativeElement.style.display = 'inline-block'
      this.prev.nativeElement.style.visibility = 'visible'
      this.next.nativeElement.style.visibility = 'visible'
    }
    else {
      this.prev.nativeElement.style.display = 'none'
      this.prev.nativeElement.style.visibility = 'hidden'
      this.next.nativeElement.style.visibility = 'hidden'
    }
  }

  ngOnInit() {
    this.active_item_id = this.list_tab_function[0].id
    this.currentdiv = 'submenu-' + this.active_item_id
   
    
  }

  toggleDiv() {
    this.isDivVisible = !this.isDivVisible;
    if(this.isDivVisible){
      setTimeout(() => {
        const submenu = document.getElementById('submenu-' + this.active_item_id); 
        if (submenu) {
          // submenu.style.top='115px'
          submenu.style.display = 'block';
          // submenu.scrollIntoView({ behavior: 'smooth', block: 'start'  });

          const elementId = `item-${this.active_item_id}`;
          const element = document.getElementById(elementId);
          if (element) {
            console.log(element)
            // element.scrollIntoView({ behavior: 'smooth' });
            this.submenuReady = true;
          // Cuộn màn hình khi submenu đã hiển thị
            this.scrollIntoViewIfNeeded(element);
          }
        }
      }, 1);
    }
  }
  submenuReady: boolean = false;
  scrollIntoViewIfNeeded(element: HTMLElement) {
    // Kiểm tra xem submenu đã hiển thị và sẵn sàng
    if (this.submenuReady) {
      // Cuộn màn hình đến phần tử
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }
  // test
  activeSubmenuId: number | null = null;

  onMenuScroll() {
    if (this.activeSubmenuId !== null) {
      this.updateSubmenuPosition(this.activeSubmenuId);
    }
  }
  onchangeitem(event: MouseEvent,id: any) {
    this.active_item_id = id
    this.currentdiv = 'submenu-' + this.active_item_id
    
  }
  @ViewChild('scrollableMenu') scrollableMenu: ElementRef;
  hoverEnter(event: MouseEvent, itemId: number) {
    this.activeSubmenuId = itemId;
    this.currentDivActive(false, itemId)
    this.updateSubmenuPosition(itemId);
    

  }
  activeflag = false
  hoverdivEnter(event: MouseEvent, itemId: number) {
    this.activeSubmenuId = itemId;

    this.activeflag = true
    const submenu = document.getElementById('submenu-' + itemId);
    this.currentDivActive(false, itemId)
    if (submenu) {
      submenu.style.display = 'block';
    }
  }
  hoverdivLeave(event: MouseEvent, itemId: number) {
    this.activeSubmenuId = null;
    this.activeflag = false
    this.currentDivActive(true, itemId)

  }

  hoverLeave(event: MouseEvent, itemId: number) {
    this.activeSubmenuId = null;
    this.currentDivActive(true, itemId)
    if (!this.activeflag && this.active_item_id!=itemId)
      this.hideSubmenu(itemId);


  }
  currentDivActive(flag: boolean, id: any) {
    const submenu = document.getElementById(this.currentdiv);
    if(!flag && this.active_item_id == id)  {
      if (submenu) {
        submenu.style.display = 'block';
      }
      return;
    }
    if (flag && this.active_item_id != id) {
      if (submenu) {
        submenu.style.display = 'block';
      }
    } else
      if (!flag) {
        if (submenu) {
          submenu.style.display = 'none';
        }
      }
   
  }


  private updateSubmenuPosition(itemId: number) {
    const submenu = document.getElementById('submenu-' + itemId);
    if (submenu) {
      const itemRect = (event?.target as HTMLElement).getBoundingClientRect();
      const scrollRect = this.scrollableMenu.nativeElement.getBoundingClientRect();
      submenu.style.top = itemRect.top - scrollRect.top+115 + 'px';
      submenu.style.display = 'block';
    }
  }
  private hideSubmenu(itemId: number) {
    const submenu = document.getElementById('submenu-' + itemId);
    if (submenu) {
      submenu.style.display = 'none';
    }
    
  }
  onOutsideClick(): void {
    // Xử lý sự kiện ở đây, ví dụ: ẩn div
    this.isDivVisible = false
  }
  // test

  navigation(item: any) {
    let nu
    if (this.item_datas.length / 2 < parseInt(item.id))
      nu = parseInt(item.id) + 1
    else nu = parseInt(item.id) - 1
    const element = document.getElementById('tab-' + nu);
    element?.scrollIntoView({ behavior: 'smooth', block: 'center' });

  }
  scrollLeft() {
    this.list_tab.nativeElement.scrollBy({ left: -150, behavior: 'smooth' });
  }
  scrollRight() {
    this.list_tab.nativeElement.scrollBy({ left: 150, behavior: 'smooth' });
  }
  OnConfirm(data:any){
    this.item_datas=[
    ]
    data.list.forEach((element: { id: any; text: any; navigation: any;active:boolean }) => {
     let item={ 
        id:element.id,
        name:element.text,
        icon:'attach-money-icon',
        height:'20px',
        width:'20px',
        navigation:element.navigation
     }
     if(element.active)
     this.item_datas.push(item)
   });
   this.isDivVisible= false
   if(data.id=='2')
   this.router.navigate(['eprofile/legal-infor'])
  if(data.id=='1')
    this.router.navigate(['eprofile/vitae'])
  }
}

