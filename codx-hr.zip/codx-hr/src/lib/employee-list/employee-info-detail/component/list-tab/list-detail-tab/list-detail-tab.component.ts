import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'list-detail-tab',
  templateUrl: './list-detail-tab.component.html',
  styleUrls: ['./list-detail-tab.component.scss']
})
export class ListDetailTabComponent implements OnInit {
  @Input() id: string = '1'
  @Output() listtab = new EventEmitter<any>();
  
  list_item: any[] = []
  textHeader: string = ''
  constructor() { }

  ngOnInit() {
    if (this.id == '1') {
      this.textHeader = 'Sơ yếu lý lịch'
      this.list_item = [
        {
          id: '1',
          text: 'Thông tin cá nhân',
          active: true,
        },
        {
          id: '2',
          text: 'Thông tin công việc',
          active: true,
        },
        {
          id: '3',
          text: 'Thông tin tuyển dụng',
          active: true,
        },
        {
          id: '4',
          text: 'Thân nhân',
          active: true,
        },
        {
          id: '5',
          text: 'Thông tin Đảng - Đoàn',
          active: true,
        },
        {
          id: '6',
          text: 'Tiểu sử cá nhân',
          active: true,
        },
        {
          id: '7',
          text: 'Lao động nước ngoài',
          active: true,
        },
        {
          id: '8',
          text: 'Hồ sơ cần nộp',
          active: true,
        },
      ]
    }
    if (this.id == '2') {
      this.textHeader = 'Thông tin pháp lý'
      this.list_item = [
        {
          id: '1',
          text: 'Sổ bảo hiểm - Sổ lao động',
          active: true,
        },
        {
          id: '2',
          text: 'Tài khoản cá nhân',
          active: true,
        },
        {
          id: '3',
          text: 'Hợp đồng lao động',
          active: true,
        },
        {
          id: '4',
          text: 'Hộ chiếu',
          active: true,
          navigation:''
        },
        {
          id: '5',
          text: 'Thị thực',
          active: true,
        },
        {
          id: '6',
          text: 'Giấy phép lao động',
          active: true,
        },
        {
          id: '7',
          text: 'Miễn giấy phép lao động',
          active: true,
        },
        {
          id: '8',
          text: 'Thẻ tạm trú',
          active: true,
        },
        {
          id: '9',
          text: 'Đăng ký tạm trú',
          active: true,
        },
        {
          id: '10',
          text: 'Giấy phép lái xe',
          active: true,
        },
        {
          id: '10',
          text: 'Thông tin ủy quyền',
          active: true,
        },
      ]
    }
    

  }
  changeActive(id:any){
    const index = this.list_item.findIndex(item => item.id ==id);
    if (index !== -1) {
      this.list_item[index].active=!this.list_item[index].active
    }
  }
  list_final:any={
    id:'',
    list:[]
  }

  Onconfirm(){
    this.list_final={
      id:this.id,
      list:this.list_item
    }
      this.listtab.emit(this.list_final)
  }
}