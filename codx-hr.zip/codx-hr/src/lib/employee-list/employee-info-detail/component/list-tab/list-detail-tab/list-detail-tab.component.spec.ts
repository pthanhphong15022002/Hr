import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListDetailTabComponent } from './list-detail-tab.component';

describe('ListDetailTabComponent', () => {
  let component: ListDetailTabComponent;
  let fixture: ComponentFixture<ListDetailTabComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListDetailTabComponent]
    });
    fixture = TestBed.createComponent(ListDetailTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
