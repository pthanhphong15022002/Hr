import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { CoreModule } from '@core/core.module';
import { FormsModule } from '@angular/forms';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { TabModule } from '@syncfusion/ej2-angular-navigations';
import { LegalInfoComponent } from './legal-info.component';

export const routes: Routes = [
  {
    path:'',
    children:[
    {
        path:'einfo',
        component: LegalInfoComponent
    },
    {
        path:'winfo',
    },
    {
        path:'',
        pathMatch:'full',
        redirectTo:'vitae'
    },
    ]
    }

];

const T_Component = [
]


@NgModule({
  declarations: [T_Component],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    CoreModule,
    NgbModule,
    FormsModule,
    OverlayModule,
    HttpClientModule,
    TabModule,
  ]
})
export class LegalInfoModule { }
