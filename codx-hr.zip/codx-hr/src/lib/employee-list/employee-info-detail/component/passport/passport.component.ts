import { Component, Injector, TemplateRef, ViewChild } from '@angular/core';
import { UIComponent, ViewType } from 'codx-core';
import { CodxShareService } from 'projects/codx-share/src/public-api';

@Component({
  selector: 'lib-passport',
  templateUrl: './passport.component.html',
  styleUrls: ['./passport.component.css']
})
export class PassportComponent {
  lstDataFake: any;
  initDataFakes(): void {
    this.lstDataFake = [
      {
         code: '#B5028441',
         location: 'TP Hồ Chí Minh',
         typePassport: 'PASSPORT',
         dateRange: '01/04/2024',
         dateExpire: '01/12/2024',
         note: 'Đi công tác lấy yêu cầu nghiệp vụ',
         detail: [
          {
              nationTo: 'Australia',
              fromDate: '01/04/2024',
              toDate: '05/04/2024',
              numberDay: '10',
              noteChildren: 'Đi công tác'
          },
          {
            nationTo: 'Afghanistan',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác'
          },
          {
            nationTo: 'Colombia',
            fromDate: '01/04/2024',
            toDate: '05/04/2024',
            numberDay: '10',
            noteChildren: 'Đi công tác'
          },
         ]
      }
    ]
  }
}