import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-vaccine-schedule',
  templateUrl: './hsnv-vaccine-schedule.component.html',
  styleUrls: ['./hsnv-vaccine-schedule.component.scss']
})
export class HsnvVaccineScheduleComponent  extends UIComponent {
  @Input() employeeID:any;
  // @Input() crrFunctionID: any;
   // Lịch tiêm vaccine
   eScheduleColumnGrid!: any[];

   @ViewChild('templateScheduleCol1', { static: true })
   templateScheduleCol1: TemplateRef<any> | undefined;
   @ViewChild('templateScheduleCol2', { static: true })
   templateScheduleCol2: TemplateRef<any> | undefined;
   @ViewChild('templateScheduleCol3', { static: true })
   templateScheduleCol3: TemplateRef<any> | undefined;
   @ViewChild('templateScheduleCol4', { static: true })
   templateScheduleCol4: TemplateRef<any> | undefined;
   // Button Edit, Delete
   @ViewChild('templateEditGridCol', { static: true })
   templateEditGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateDeleteGridCol', { static: true })
   templateDeleteGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateButtonGridCol', { static: true })
   templateButtonGridCol: TemplateRef<any> | undefined;

   eVaccineFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  

  override onInit(): void {
    this.initEVaccine();
    this.initEmpSchedule();
  }

  // HREM10705
  initEVaccine() {
    // this.hrService.getFormModel(this.crrFunctionID).then((res) => {
    this.hrService.getFormModel('HREM10705').then((res) => {
      this.eVaccineFormModel = res;
    });
  }
  initEmpSchedule() {
    if (!this.eScheduleColumnGrid) {
      this.eScheduleColumnGrid = [
        {
          headerText: 'Loại Vaccine',
          template: this.templateScheduleCol1,
          width: '20%',
        },
        {
          headerText: 'Ngày tiêm',
          template: this.templateScheduleCol2,
          width: '20%',
        },
        {
          headerText: 'Nơi khám',
          template: this.templateScheduleCol3,
          width: '30%',
        },
        {
          headerText: 'Chi phí',
          template: this.templateScheduleCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };
}
