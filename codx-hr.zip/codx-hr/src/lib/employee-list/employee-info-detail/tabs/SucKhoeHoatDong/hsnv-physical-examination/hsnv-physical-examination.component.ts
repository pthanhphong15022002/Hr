import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-physical-examination',
  templateUrl: './hsnv-physical-examination.component.html',
  styleUrls: ['./hsnv-physical-examination.component.scss']
})
export class HsnvPhysicalExaminationComponent extends UIComponent {
  @Input() employeeID:any;

  eExaminationColumnGrid!: any[];
  @ViewChild('templateExaminationCol1', { static: true })
  templateExaminationCol1: TemplateRef<any> | undefined;
  @ViewChild('templateExaminationCol2', { static: true })
  templateExaminationCol2: TemplateRef<any> | undefined;
  @ViewChild('templateExaminationCol3', { static: true })
  templateExaminationCol3: TemplateRef<any> | undefined;
  @ViewChild('templateExaminationCol4', { static: true })
  templateExaminationCol4: TemplateRef<any> | undefined;

   // Button Edit, Delete
   @ViewChild('templateEditGridCol', { static: true })
   templateEditGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateDeleteGridCol', { static: true })
   templateDeleteGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateButtonGridCol', { static: true })
   templateButtonGridCol: TemplateRef<any> | undefined;
   eHealthFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  override onInit(): void {
    this.initEmpExamination()
    this.initEHealth();
  }

   // Khám sức khỏe
   initEHealth() {
     this.hrService.getFormModel('HREM10703').then((res) => {
       this.eHealthFormModel = res;
     });
   }
 

  initEmpExamination() {
    if (!this.eExaminationColumnGrid) {
      this.eExaminationColumnGrid = [
        {
          headerText: 'Ngày khám',
          template: this.templateExaminationCol1,
          width: '15%',
        },
        {
          headerText: 'Nơi khám',
          template: this.templateExaminationCol2,
          width: '25%',
        },
        {
          headerText: 'Địa chỉ',
          template: this.templateExaminationCol3,
          width: '25%',
        },
        {
          headerText: 'Lý do khám',
          template: this.templateExaminationCol4,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

}
