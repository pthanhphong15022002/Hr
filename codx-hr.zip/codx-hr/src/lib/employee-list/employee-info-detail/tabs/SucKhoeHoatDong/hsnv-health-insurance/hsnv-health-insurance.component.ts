import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-health-insurance',
  templateUrl: './hsnv-health-insurance.component.html',
  styleUrls: ['./hsnv-health-insurance.component.scss']
})
export class HsnvHealthInsuranceComponent extends UIComponent {
  @Input() employeeID:any;
  
  @ViewChild('templateHealthInsuranceCol1', { static: true })
  templateHealthInsuranceCol1: TemplateRef<any> | undefined;
  @ViewChild('templateHealthInsuranceCol2', { static: true })
  templateHealthInsuranceCol2: TemplateRef<any> | undefined;
  @ViewChild('templateHealthInsuranceCol3', { static: true })
  templateHealthInsuranceCol3: TemplateRef<any> | undefined;
  @ViewChild('templateHealthInsuranceCol4', { static: true })
  templateHealthInsuranceCol4: TemplateRef<any> | undefined;
  // Button Edit, Delete
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eHICardFormModel: FormModel = null;
  eHealthInsuranceColumnGrid!: any[];
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  onInit(): void {
    //this.initEInsurance()
    this.initEHICard();
    this.initEmpHealthInsurance();
  }

  

  // Thẻ Bảo hiểm y tế
  initEHICard() {
    this.hrService.getFormModel('HREM10701').then((res) => {
      this.eHICardFormModel = res;
    });
  }


  initEmpHealthInsurance() {
    if (!this.eHealthInsuranceColumnGrid) {
      this.eHealthInsuranceColumnGrid = [
        {
          headerText: 'Từ ngày',
          template: this.templateHealthInsuranceCol1,
          width: '20%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templateHealthInsuranceCol2,
          width: '20%',
        },
        {
          headerText: 'Nơi khám chữa bệnh',
          template: this.templateHealthInsuranceCol3,
          width: '30%',
        },
        {
          headerText: 'Phiếu khám chữa bệnh',
          template: this.templateHealthInsuranceCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };
}
