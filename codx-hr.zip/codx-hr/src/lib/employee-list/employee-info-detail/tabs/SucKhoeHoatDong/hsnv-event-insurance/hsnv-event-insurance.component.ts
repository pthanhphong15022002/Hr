import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-event-insurance',
  templateUrl: './hsnv-event-insurance.component.html',
  styleUrls: ['./hsnv-event-insurance.component.scss']
})
export class HsnvEventInsuranceComponent extends UIComponent {
  @Input() employeeID:any;
  // Sự kiện
  eEventColumnGrid!: any[];

  @ViewChild('templateEventCol1', { static: true })
  templateEventCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEventCol2', { static: true })
  templateEventCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEventCol3', { static: true })
  templateEventCol3: TemplateRef<any> | undefined;
  // Button Edit, Delete
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eEventFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpEvent();
    this.initEEvent();
  }


  
  initEmpEvent() {
    if (!this.eEventColumnGrid) {
      this.eEventColumnGrid = [
        {
          headerText: 'Ngày hiệu lực',
          template: this.templateEventCol1,
          width: '30%',
        },
        {
          headerText: 'Sự kiện',
          template: this.templateEventCol2,
          width: '30%',
        },
        {
          headerText: 'Chi phí',
          template: this.templateEventCol3,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  // Sự kiện
  initEEvent() {
    this.hrService.getFormModel('HREM10708').then((res) => {
      this.eEventFormModel = res;
    });
  }



 

}
