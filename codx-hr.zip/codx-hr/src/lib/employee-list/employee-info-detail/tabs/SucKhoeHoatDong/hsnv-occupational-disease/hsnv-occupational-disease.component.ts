import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-occupational-disease',
  templateUrl: './hsnv-occupational-disease.component.html',
  styleUrls: ['./hsnv-occupational-disease.component.scss']
})
export class HsnvOccupationalDiseaseComponent extends UIComponent {
  @Input() employeeID:any;
  eDiseaseColumnGrid!: any[];

  @ViewChild('templateDiseaseCol1', { static: true })
  templateDiseaseCol1: TemplateRef<any> | undefined;
  @ViewChild('templateDiseaseCol2', { static: true })
  templateDiseaseCol2: TemplateRef<any> | undefined;
  @ViewChild('templateDiseaseCol3', { static: true })
  templateDiseaseCol3: TemplateRef<any> | undefined;
  @ViewChild('templateDiseaseCol4', { static: true })
  templateDiseaseCol4: TemplateRef<any> | undefined;
 // Button Edit, Delete
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eDiseaseFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  override onInit(): void {
    this.initEmpDisease();
    this.initEDisease();
  }

   // Bệnh nghề nghiệp
   initEDisease() {
     this.hrService.getFormModel('HREM10704').then((res) => {
       this.eDiseaseFormModel = res;
     });
   }

  initEmpDisease() {
    if (!this.eDiseaseColumnGrid) {
      this.eDiseaseColumnGrid = [
        {
          headerText: 'Ngày khám',
          template: this.templateDiseaseCol1,
          width: '20%',
        },
        {
          headerText: 'Bệnh khám',
          template: this.templateDiseaseCol2,
          width: '20%',
        },
        {
          headerText: 'Nơi khám',
          template: this.templateDiseaseCol3,
          width: '30%',
        },
        {
          headerText: 'Chi phí',
          template: this.templateDiseaseCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };
}
