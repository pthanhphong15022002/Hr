import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-title-conferred',
  templateUrl: './hsnv-title-conferred.component.html',
  styleUrls: ['./hsnv-title-conferred.component.scss']
})
export class HsnvTitleConferredComponent extends UIComponent {
  @Input() employeeID:any;
 // Danh hiệu được phong
 eConferredColumnGrid!: any[];

 @ViewChild('templateConferredCol1', { static: true })
 templateConferredCol1: TemplateRef<any> | undefined;
 @ViewChild('templateConferredCol2', { static: true })
 templateConferredCol2: TemplateRef<any> | undefined;
 @ViewChild('templateConferredCol3', { static: true })
 templateConferredCol3: TemplateRef<any> | undefined;
 @ViewChild('templateConferredCol4', { static: true })
 templateConferredCol4: TemplateRef<any> | undefined;
 eConferTitleFormModel: FormModel = null;

   // Button Edit, Delete
   @ViewChild('templateEditGridCol', { static: true })
   templateEditGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateDeleteGridCol', { static: true })
   templateDeleteGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateButtonGridCol', { static: true })
   templateButtonGridCol: TemplateRef<any> | undefined;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  override onInit(): void {
    this.initEmpConferred();
    this.initEConferTitle();
  }

    // Danh hiệu được phong
    initEConferTitle() {
      this.hrService.getFormModel('HREM10707').then((res) => {
        this.eConferTitleFormModel = res;
      });
    }
  

  initEmpConferred() {
    if (!this.eConferredColumnGrid) {
      this.eConferredColumnGrid = [
        {
          headerText: 'Danh hiệu được phong',
          template: this.templateConferredCol1,
          width: '25%%',
        },
        {
          headerText: 'Ngày phong danh hiệu',
          template: this.templateConferredCol2,
          width: '20%',
        },
        {
          headerText: 'Số quyết định',
          template: this.templateConferredCol3,
          width: '15%',
        },
        {
          headerText: 'Lý do được phong',
          template: this.templateConferredCol4,
          width: '30%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

}
