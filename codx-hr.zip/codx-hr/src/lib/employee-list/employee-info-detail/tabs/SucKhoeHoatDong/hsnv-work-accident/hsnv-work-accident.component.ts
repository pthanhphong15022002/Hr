import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-work-accident',
  templateUrl: './hsnv-work-accident.component.html',
  styleUrls: ['./hsnv-work-accident.component.scss']
})
export class HsnvWorkAccidentComponent extends UIComponent {
  
  @Input() employeeID:any;
  // Tai nạn lao động
  @ViewChild('templateAccidentGridCol1', { static: true })
  templateAccidentGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAccidentGridCol2', { static: true })
  templateAccidentGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAccidentGridCol3', { static: true })
  templateAccidentGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAccidentGridCol4', { static: true })
  templateAccidentGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateAccidentGridCol5', { static: true })
  templateAccidentGridCol5: TemplateRef<any> | undefined;

   // Button Edit, Delete
   @ViewChild('templateEditGridCol', { static: true })
   templateEditGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateDeleteGridCol', { static: true })
   templateDeleteGridCol: TemplateRef<any> | undefined;
   @ViewChild('templateButtonGridCol', { static: true })
   templateButtonGridCol: TemplateRef<any> | undefined;
  eAccidentColumnGrid!: any[];
  // Tai nạn lao động
  eAccidentFormModel: FormModel;
 
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  override onInit(): void {
    this.initEmpAccident();
    this.initEAccident()
  }

  initEAccident() {
    this.hrService.getFormModel('HREM10702').then((res) => {
      this.eAccidentFormModel = res;
    });
  }
  initEmpAccident() {
    if (!this.eAccidentColumnGrid) {
      this.eAccidentColumnGrid = [
        {
          headerText: 'Ngày xảy ra',
          template: this.templateAccidentGridCol1,
          width: '15%',
        },
        {
          headerText: 'Loại TNLĐ',
          template: this.templateAccidentGridCol2,
          width: '20%',
        },
        {
          headerText: 'Nơi xảy ra',
          template: this.templateAccidentGridCol3,
          width: '15%',
        },
        {
          headerText: 'Tình trạng',
          template: this.templateAccidentGridCol4,
          width: '25%',
        },
        {
          headerText: 'Nguyên nhân TNLĐ ',
          template: this.templateAccidentGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };
}
