import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-member-inssurance',
  templateUrl: './hsnv-member-inssurance.component.html',
  styleUrls: ['./hsnv-member-inssurance.component.scss']
})
export class HsnvMemberInssuranceComponent extends UIComponent {
  @Input() employeeID:any;
 // Hội viên
 eMemberColumnGrid!: any[];

 @ViewChild('templateMemberGridCol1', { static: true })
 templateMemberGridCol1: TemplateRef<any> | undefined;
 @ViewChild('templateMemberGridCol2', { static: true })
 templateMemberGridCol2: TemplateRef<any> | undefined;
 @ViewChild('templateMemberGridCol3', { static: true })
 templateMemberGridCol3: TemplateRef<any> | undefined;
 @ViewChild('templateMemberGridCol4', { static: true })
 templateMemberGridCol4: TemplateRef<any> | undefined;
 @ViewChild('templateMemberGridCol5', { static: true })
 templateMemberGridCol5: TemplateRef<any> | undefined;

 @ViewChild('templateEditGridCol', { static: true })
 templateEditGridCol: TemplateRef<any> | undefined;
 @ViewChild('templateDeleteGridCol', { static: true })
 templateDeleteGridCol: TemplateRef<any> | undefined;
 @ViewChild('templateButtonGridCol', { static: true })
 templateButtonGridCol: TemplateRef<any> | undefined;
 eMemberFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  override onInit(): void {
    this.initEmpMember();
    this.initEMember();
  }


  
  // Hội viên
  initEMember() {
    this.hrService.getFormModel('HREM10706').then((res) => {
      this.eMemberFormModel = res;
    });
  }

  initEmpMember() {
    if (!this.eMemberColumnGrid) {
      this.eMemberColumnGrid = [
        {
          headerText: 'Hiệp hội đoàn thể tham gia',
          template: this.templateMemberGridCol1,
          width: '30%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templateMemberGridCol2,
          width: '10%',
        },
        {
          headerText: 'Đơn vị',
          template: this.templateMemberGridCol3,
          width: '25%',
        },
        {
          headerText: 'Chức vụ',
          template: this.templateMemberGridCol4,
          width: '10%',
        },
        {
          headerText: 'Đang hoạt động',
          template: this.templateMemberGridCol5,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };
}
