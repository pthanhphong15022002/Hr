import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-loan',
  templateUrl: './hsnv-emp-loan.component.html',
  styleUrls: ['./hsnv-emp-loan.component.scss']
})
export class HsnvEmpLoanComponent  extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eLoanFormModel: FormModel = null;
  eLoanInfoColumnGrid!: any[];

  @ViewChild('templateLoanInfoGridCol1', { static: true })
  templateLoanInfoGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateLoanInfoGridCol2', { static: true })
  templateLoanInfoGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateLoanInfoGridCol3', { static: true })
  templateLoanInfoGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateLoanInfoGridCol4', { static: true })
  templateLoanInfoGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateLoanInfoGridCol5', { static: true })
  templateLoanInfoGridCol5: TemplateRef<any> | undefined;

  // Hình thức trả
  ePaymentColumnGrid!: any[];

  @ViewChild('templatePaymentGridCol1', { static: true })
  templatePaymentGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templatePaymentGridCol2', { static: true })
  templatePaymentGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templatePaymentGridCol3', { static: true })
  templatePaymentGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templatePaymentGridCol4', { static: true })
  templatePaymentGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templatePaymentGridCol5', { static: true })
  templatePaymentGridCol5: TemplateRef<any> | undefined;

  eHistoryColumnGrid!: any[];

  @ViewChild('templateHistoryGridCol1', { static: true })
  templateHistoryGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateHistoryGridCol2', { static: true })
  templateHistoryGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateHistoryGridCol3', { static: true })
  templateHistoryGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateHistoryGridCol4', { static: true })
  templateHistoryGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateHistoryGridCol5', { static: true })
  templateHistoryGridCol5: TemplateRef<any> | undefined;
  
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initELoan();
    this.initEmpLoanInfo();
    this.initEmpPayment();
    this.initEmpHistory();
  }

  initELoan() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eLoanFormModel = res;
    });
  }


  initEmpLoanInfo() {
    if (!this.eLoanInfoColumnGrid) {
      this.eLoanInfoColumnGrid = [
        {
          headerText: 'Ngày vay',
          template: this.templateLoanInfoGridCol1,
          width: '20%',
        },
        {
          headerText: 'Số tiền vay',
          template: this.templateLoanInfoGridCol2,
          width: '20%',
        },
        {
          headerText: 'Nguyên tệ',
          template: this.templateLoanInfoGridCol3,
          width: '20%',
        },
        {
          headerText: 'Tỉ giá',
          template: this.templateLoanInfoGridCol4,
          width: '10%',
        },
        {
          headerText: 'Ghi chú',
          template: this.templateLoanInfoGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  initEmpPayment() {
    if (!this.ePaymentColumnGrid) {
      this.ePaymentColumnGrid = [
        {
          headerText: 'Số tiền trừ/tháng',
          template: this.templatePaymentGridCol1,
          width: '20%',
        },
        {
          headerText: 'Trả từ tháng',
          template: this.templatePaymentGridCol2,
          width: '15%',
        },
        {
          headerText: 'Đến tháng',
          template: this.templatePaymentGridCol3,
          width: '15%',
        },
        {
          headerText: 'Trả vào khoản',
          template: this.templatePaymentGridCol4,
          width: '20%',
        },
        {
          headerText: 'Ngày khấu trừ khoản vay',
          template: this.templatePaymentGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  

  initEmpHistory() {
    if (!this.eHistoryColumnGrid) {
      this.eHistoryColumnGrid = [
        {
          headerText: 'Loại khấu trừ',
          template: this.templateHistoryGridCol1,
          width: '20%',
        },
        {
          headerText: 'Ngày phát sinh',
          template: this.templateHistoryGridCol2,
          width: '15%',
        },
        {
          headerText: 'Tính vào tháng',
          template: this.templateHistoryGridCol3,
          width: '15%',
        },
        {
          headerText: 'Số tiền',
          template: this.templateHistoryGridCol4,
          width: '20%',
        },
        {
          headerText: 'Số tiền VND',
          template: this.templateHistoryGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };


}
