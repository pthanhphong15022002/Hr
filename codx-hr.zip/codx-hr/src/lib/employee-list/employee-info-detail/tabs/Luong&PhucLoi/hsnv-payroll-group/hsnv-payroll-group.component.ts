import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-payroll-group',
  templateUrl: './hsnv-payroll-group.component.html',
  styleUrls: ['./hsnv-payroll-group.component.scss']
})
export class HsnvPayrollGroupComponent extends UIComponent {
  @Input() infoPersonal:any
  eInfoSalaryInfoFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  onInit(): void {
    this.initEInfoSalaryInfo();
  }

  initEInfoSalaryInfo() {
    this.hrService.getFormModel('HREM10301').then((res) => {
      this.eInfoSalaryInfoFormModel = res;
    }); 
  }
}
