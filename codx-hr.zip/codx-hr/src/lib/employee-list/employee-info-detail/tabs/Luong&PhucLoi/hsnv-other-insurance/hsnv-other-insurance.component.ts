import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { AuthStore, FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-other-insurance',
  templateUrl: './hsnv-other-insurance.component.html',
  styleUrls: ['./hsnv-other-insurance.component.scss']
})
export class HsnvOtherInsuranceComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID:any;
  user:any
  eEmpInsuranceOtherFormModel: FormModel = null;
  eInsuranceOther!: any[];

  @ViewChild('templateInsuranceOtherCol1', { static: true })
  templateInsuranceOtherCol1: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol2', { static: true })
  templateInsuranceOtherCol2: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol3', { static: true })
  templateInsuranceOtherCol3: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol4', { static: true })
  templateInsuranceOtherCol4: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol5', { static: true })
  templateInsuranceOtherCol5: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol6', { static: true })
  templateInsuranceOtherCol6: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol7', { static: true })
  templateInsuranceOtherCol7: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceOtherCol8', { static: true })
  templateInsuranceOtherCol8: TemplateRef<any> | undefined;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private auth: AuthStore,
  ){
    super(inject);
    this.user = this.auth.get();
  }
  override onInit(): void {
    this.initEmpInsuranceOther();
    this.initEInsuranceOther();
  }

  initEInsuranceOther() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpInsuranceOtherFormModel = res;
    }); 
  }

  initEmpInsuranceOther() {
    if (!this.eInsuranceOther) {
      this.eInsuranceOther = [
        {
          headerText: 'Ngày',
          template: this.templateInsuranceOtherCol1,
        },
        {
          headerText: 'Số tiền',
          template: this.templateInsuranceOtherCol2,
        },
        {
          headerText: 'Nguyên tệ',
          template: this.templateInsuranceOtherCol3,
        },
        {
          headerText: 'Tỉ giá quy đổi',
          template: this.templateInsuranceOtherCol4,
        },
        {
          headerText: 'Lý do',
          template: this.templateInsuranceOtherCol5,
        },
        {
          headerText: 'Chuyển vào thu nhập',
          template: this.templateInsuranceOtherCol6,
        },
        {
          headerText: 'Ghi chú',
          template: this.templateInsuranceOtherCol7,
        },
        {
          headerText: '',
          template: this.templateInsuranceOtherCol8,
        },
      ];
    }
  }

}
