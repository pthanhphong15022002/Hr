import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-basic-benefit',
  templateUrl: './hsnv-basic-benefit.component.html',
  styleUrls: ['./hsnv-basic-benefit.component.scss']
})
export class HsnvBasicBenefitComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID:any;
  eBenefitColumnGrid!: any[];

  @ViewChild('eBasicBenefitGridViewID') eBasicBenefitGridViewID: CodxGridviewV2Component;

  //Header
  @ViewChild('templateBenefitHeaderGridCol1', { static: true })
  templateBenefitHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitHeaderGridCol2', { static: true })
  templateBenefitHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitHeaderGridCol3', { static: true })
  templateBenefitHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitHeaderGridCol4', { static: true })
  templateBenefitHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitHeaderGridCol5', { static: true })
  templateBenefitHeaderGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateBenefitGridCol1', { static: true })
  templateBenefitGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitGridCol2', { static: true })
  templateBenefitGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitGridCol3', { static: true })
  templateBenefitGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitGridCol4', { static: true })
  templateBenefitGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateBenefitGridCol5', { static: true })
  templateBenefitGridCol5: TemplateRef<any> | undefined;
  
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eSalaryFormModel: FormModel = null;
  eSalaryGroupFormModel: FormGroup;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpBenefit();
    this.initEmpSalary()
  }

  initEmpSalary() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eSalaryFormModel = res;
        console.log( this.eSalaryFormModel)
        this.hrService
        .getFormGroup(
          this.eSalaryFormModel.formName,
          this.eSalaryFormModel.gridViewName,
          this.eSalaryFormModel
        )
        .then((fg) => {
          this.eSalaryGroupFormModel = fg;
          this.eSalaryGroupFormModel.patchValue(this.infoPersonal);
          this.eSalaryFormModel.currentData = this.infoPersonal;
        });
    });
    
  }

  initEmpBenefit() {
    if (!this.eBenefitColumnGrid) {
      this.eBenefitColumnGrid = [
        {
          headerTemplate: this.templateBenefitHeaderGridCol1,
          template: this.templateBenefitGridCol1,
          width: '15%',
        },
        {
          headerTemplate: this.templateBenefitHeaderGridCol2,
          template: this.templateBenefitGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateBenefitHeaderGridCol3,
          template: this.templateBenefitGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateBenefitHeaderGridCol4,
          template: this.templateBenefitGridCol4,
          width: '20%',
        },
        {
          headerTemplate: this.templateBenefitHeaderGridCol5,
          template: this.templateBenefitGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        },
      ];
    }
  };

  deleteBasicBenefit(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteBasicBenefitInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eBasicBenefitGridViewID){
                    console.log('refresh grid')
                    clearInterval(ins);
                    this.eBasicBenefitGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteBasicBenefitInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpBasicSalaryBusiness',
      'DeleteBasicBenefitInfoAsync',
      data
    );
  }
}
