import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-authorization-letter',
  templateUrl: './hsnv-authorization-letter.component.html',
  styleUrls: ['./hsnv-authorization-letter.component.scss']
})
export class HsnvAuthorizationLetterComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eAuthorityColumnGrid!: any[];

  @ViewChild('eAuthorizationGridViewID') eAuthorizationGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateAuthorityHeaderGridCol1', { static: true })
  templateAuthorityHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityHeaderGridCol2', { static: true })
  templateAuthorityHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityHeaderGridCol3', { static: true })
  templateAuthorityHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityHeaderGridCol4', { static: true })
  templateAuthorityHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityHeaderGridCol5', { static: true })
  templateAuthorityHeaderGridCol5: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityHeaderGridCol6', { static: true })
  templateAuthorityHeaderGridCol6: TemplateRef<any> | undefined;

  @ViewChild('templateAuthorityGridCol1', { static: true })
  templateAuthorityGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityGridCol2', { static: true })
  templateAuthorityGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityGridCol3', { static: true })
  templateAuthorityGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityGridCol4', { static: true })
  templateAuthorityGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityGridCol5', { static: true })
  templateAuthorityGridCol5: TemplateRef<any> | undefined;
  @ViewChild('templateAuthorityGridCol6', { static: true })
  templateAuthorityGridCol6: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eAuthorizationLetterFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpAuthority();
    this.initEAuthorizationLetter()
  }


  initEAuthorizationLetter() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eAuthorizationLetterFormModel = res;
    });
  }

  

  
  initEmpAuthority() {
    if (!this.eAuthorityColumnGrid) {
      this.eAuthorityColumnGrid = [
        {
          headerTemplate: this.templateAuthorityHeaderGridCol1,
          template: this.templateAuthorityGridCol1,
          width: '10%',
        },
        {
          headerTemplate: this.templateAuthorityHeaderGridCol2,
          template: this.templateAuthorityGridCol2,
          width: '15%',
        },
        {
          headerTemplate: this.templateAuthorityHeaderGridCol3,
          template: this.templateAuthorityGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateAuthorityHeaderGridCol4,
          template: this.templateAuthorityGridCol4,
          width: '15%',
        },
        {
          headerTemplate: this.templateAuthorityHeaderGridCol5,
          template: this.templateAuthorityGridCol5,
          width: '15%',
        },
        {
          headerTemplate: this.templateAuthorityHeaderGridCol6,
          template: this.templateAuthorityGridCol6,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  deleteAuthorizationLetter(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteAuthorizationLetterInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eAuthorizationGridViewID){
                    clearInterval(ins);
                    this.eAuthorizationGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteAuthorizationLetterInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpAuthorizationLetterBusiness',
      'DeleteAuthorizationLetterInfoAsync',
      data
    );
  }
}
