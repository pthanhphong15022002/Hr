import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-driver-account',
  templateUrl: './hsnv-driver-account.component.html',
  styleUrls: ['./hsnv-driver-account.component.scss']
})
export class HsnvDriverAccountComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eDriverColumnGrid!: any[];

  @ViewChild('eDriverAccountGridViewID') eDriverAccountGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateDriverHeaderGridCol1', { static: true })
  templateDriverHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateDriverHeaderGridCol2', { static: true })
  templateDriverHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateDriverHeaderGridCol3', { static: true })
  templateDriverHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateDriverHeaderGridCol4', { static: true })
  templateDriverHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateDriverHeaderGridCol5', { static: true })
  templateDriverHeaderGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateDriverGridCol1', { static: true })
  templateDriverGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateDriverGridCol2', { static: true })
  templateDriverGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateDriverGridCol3', { static: true })
  templateDriverGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateDriverGridCol4', { static: true })
  templateDriverGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateDriverGridCol5', { static: true })
  templateDriverGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eDriverAccountFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpDriver();
    this.initEDriverAccount();
  }

  initEDriverAccount() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eDriverAccountFormModel = res;
    });
  }

  initEmpDriver() {
    if (!this.eDriverColumnGrid) {
      this.eDriverColumnGrid = [
        {
          headerTemplate: this.templateDriverHeaderGridCol1,
          template: this.templateDriverGridCol1,
          width: '25%',
        },
        {
          headerTemplate: this.templateDriverHeaderGridCol2,
          template: this.templateDriverGridCol2,
          width: '15%',
        },
        {
          headerTemplate: this.templateDriverHeaderGridCol3,
          template: this.templateDriverGridCol3,
          width: '15%',
        },
        {
          headerTemplate: this.templateDriverHeaderGridCol4,
          template: this.templateDriverGridCol4,
          width: '15%',
        },
        {
          headerTemplate: this.templateDriverHeaderGridCol5,
          template: this.templateDriverGridCol5,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteDriverAccount(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteDriverAccountInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eDriverAccountGridViewID){
                    clearInterval(ins);
                    this.eDriverAccountGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteDriverAccountInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpDriverAccountBusiness',
      'DeleteDriverAccountInfoAsync',
      data
    );
  }
}
