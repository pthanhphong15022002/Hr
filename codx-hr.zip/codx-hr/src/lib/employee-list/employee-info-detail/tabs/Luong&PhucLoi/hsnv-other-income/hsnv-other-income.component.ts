import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-other-income',
  templateUrl: './hsnv-other-income.component.html',
  styleUrls: ['./hsnv-other-income.component.scss']
})
export class HsnvOtherIncomeComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eOtherIncomeColumnGrid!: any[];

  @ViewChild('eOtherIncomeGridViewID') eOtherIncomeGridViewID: CodxGridviewV2Component;

  //Header
  @ViewChild('templateOtherIncomeHeaderGridCol1', { static: true })
  templateOtherIncomeHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateOtherIncomeHeaderGridCol2', { static: true })
  templateOtherIncomeHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateOtherIncomeHeaderGridCol3', { static: true })
  templateOtherIncomeHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateOtherIncomeHeaderGridCol4', { static: true })
  templateOtherIncomeHeaderGridCol4: TemplateRef<any> | undefined;

  // Row
  @ViewChild('templateOtherIncomeGridCol1', { static: true })
  templateOtherIncomeGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateOtherIncomeGridCol2', { static: true })
  templateOtherIncomeGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateOtherIncomeGridCol3', { static: true })
  templateOtherIncomeGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateOtherIncomeGridCol4', { static: true })
  templateOtherIncomeGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eOtherIncomeFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpOtherIncome();
    this.initEOtherIncome();
  }

  initEOtherIncome() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eOtherIncomeFormModel = res;
    });
  }


  initEmpOtherIncome() {
    if (!this.eOtherIncomeColumnGrid) {
      this.eOtherIncomeColumnGrid = [
        {
          headerTemplate: this.templateOtherIncomeHeaderGridCol1,
          template: this.templateOtherIncomeGridCol1,
          width: '30%',
        },
        {
          headerTemplate: this.templateOtherIncomeHeaderGridCol2,
          template: this.templateOtherIncomeGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateOtherIncomeHeaderGridCol3,
          template: this.templateOtherIncomeGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateOtherIncomeHeaderGridCol4,
          template: this.templateOtherIncomeGridCol4,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteOtherIncome(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteOtherIncomeInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eOtherIncomeGridViewID){
                    console.log('refresh grid')
                    clearInterval(ins);
                    this.eOtherIncomeGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteOtherIncomeInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'PayTExceptBusiness',
      'DeleteOtherIncomeInfoAsync',
      data
    );
  }
}
