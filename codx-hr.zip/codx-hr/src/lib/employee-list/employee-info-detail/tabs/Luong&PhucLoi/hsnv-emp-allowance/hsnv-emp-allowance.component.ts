import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-allowance',
  templateUrl: './hsnv-emp-allowance.component.html',
  styleUrls: ['./hsnv-emp-allowance.component.scss']
})
export class HsnvEmpAllowanceComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID:any;
  eAllowanceColumnGrid!: any[];

  @ViewChild('eAllowanceGridViewID') eAllowanceGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateAllowanceHeaderGridCol1', { static: true })
  templateAllowanceHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAllowanceHeaderGridCol2', { static: true })
  templateAllowanceHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAllowanceHeaderGridCol3', { static: true })
  templateAllowanceHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAllowanceHeaderGridCol4', { static: true })
  templateAllowanceHeaderGridCol4: TemplateRef<any> | undefined;

  // Row
  @ViewChild('templateAllowanceGridCol1', { static: true })
  templateAllowanceGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAllowanceGridCol2', { static: true })
  templateAllowanceGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAllowanceGridCol3', { static: true })
  templateAllowanceGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAllowanceGridCol4', { static: true })
  templateAllowanceGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eAllowanceFormModel: FormModel = null;
  eAllowanceGroupFormModel: FormGroup;
  
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpAllowance();
    this.initEAllowance();
  }

  initEAllowance() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eAllowanceFormModel = res;
    });
    
  }

  initEmpAllowance() {
    if (!this.eAllowanceColumnGrid) {
      this.eAllowanceColumnGrid = [
        {
          headerTemplate: this.templateAllowanceHeaderGridCol1,
          template: this.templateAllowanceGridCol1,
          width: '30%',
        },
        {
          headerTemplate: this.templateAllowanceHeaderGridCol2,
          template: this.templateAllowanceGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateAllowanceHeaderGridCol3,
          template: this.templateAllowanceGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateAllowanceHeaderGridCol4,
          template: this.templateAllowanceGridCol4,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteAllowance(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteAllowanceInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eAllowanceGridViewID){
                    console.log('refresh grid')
                    clearInterval(ins);
                    this.eAllowanceGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteAllowanceInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpAllowanceBusiness',
      'DeleteAllowanceInfoAsync',
      data
    );
  }
}
