import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-salary-job-position',
  templateUrl: './hsnv-salary-job-position.component.html',
  styleUrls: ['./hsnv-salary-job-position.component.scss']
})
export class HsnvSalaryJobPositionComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  ePositionSalaryColumnGrid!: any[];

  @ViewChild('eSalaryJobPositionGridViewID') eSalaryJobPositionGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templatePositionSalaryHeaderGridCol1', { static: true })
  templatePositionSalaryHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templatePositionSalaryHeaderGridCol2', { static: true })
  templatePositionSalaryHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templatePositionSalaryHeaderGridCol3', { static: true })
  templatePositionSalaryHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templatePositionSalaryHeaderGridCol4', { static: true })
  templatePositionSalaryHeaderGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templatePositionSalaryGridCol1', { static: true })
  templatePositionSalaryGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templatePositionSalaryGridCol2', { static: true })
  templatePositionSalaryGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templatePositionSalaryGridCol3', { static: true })
  templatePositionSalaryGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templatePositionSalaryGridCol4', { static: true })
  templatePositionSalaryGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  ePositionSalaryFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpPositionSalary();
    this.initEPositionSalary();
  }
  initEPositionSalary() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.ePositionSalaryFormModel = res;
    });
  }
  initEmpPositionSalary() {
    if (!this.ePositionSalaryColumnGrid) {
      this.ePositionSalaryColumnGrid = [
        {
          headerTemplate: this.templatePositionSalaryHeaderGridCol1,
          template: this.templatePositionSalaryGridCol1,
          width: '20%',
        },
        {
          headerTemplate: this.templatePositionSalaryHeaderGridCol2,
          template: this.templatePositionSalaryGridCol2,
          width: '25%',
        },
        {
          headerTemplate: this.templatePositionSalaryHeaderGridCol3,
          template: this.templatePositionSalaryGridCol3,
          width: '25%',
        },
        {
          headerTemplate: this.templatePositionSalaryHeaderGridCol4,
          template: this.templatePositionSalaryGridCol4,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteSalaryJobPosition(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteSalaryJobPositionInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eSalaryJobPositionGridViewID){
                    clearInterval(ins);
                    this.eSalaryJobPositionGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteSalaryJobPositionInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpJWSalaryBusiness',
      'DeleteSalaryJobPositionInfoAsync',
      data
    );
  }
}
