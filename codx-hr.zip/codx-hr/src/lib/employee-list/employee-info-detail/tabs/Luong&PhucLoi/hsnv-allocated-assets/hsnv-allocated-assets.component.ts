import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-allocated-assets',
  templateUrl: './hsnv-allocated-assets.component.html',
  styleUrls: ['./hsnv-allocated-assets.component.scss']
})
export class HsnvAllocatedAssetsComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID:any;

  AssetColumnGrid!: any[];

  @ViewChild('eAssetGridViewID') eAssetGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateAssetHeaderGridCol1', { static: true })
  templateAssetHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAssetHeaderGridCol2', { static: true })
  templateAssetHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAssetHeaderGridCol3', { static: true })
  templateAssetHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAssetHeaderGridCol4', { static: true })
  templateAssetHeaderGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateAssetGridCol1', { static: true })
  templateAssetGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAssetGridCol2', { static: true })
  templateAssetGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAssetGridCol3', { static: true })
  templateAssetGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAssetGridCol4', { static: true })
  templateAssetGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eAssetsFormModel: FormModel = null;



  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpAsset();
    this.initEAssets();
  }

  initEAssets() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eAssetsFormModel = res;
    });
  }

  
  initEmpAsset() {
    if (!this.AssetColumnGrid) {
      this.AssetColumnGrid = [
        {
          headerTemplate: this.templateAssetHeaderGridCol1,
          template: this.templateAssetGridCol1,
          width: '30%',
        },
        {
          headerTemplate: this.templateAssetHeaderGridCol2,
          template: this.templateAssetGridCol2,
          width: '15%',
        },
        {
          headerTemplate: this.templateAssetHeaderGridCol3,
          template: this.templateAssetGridCol3,
          width: '25%',
        },
        {
          headerTemplate: this.templateAssetHeaderGridCol4,
          template: this.templateAssetGridCol4,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteAsset(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteAssetInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eAssetGridViewID){
                    clearInterval(ins);
                    this.eAssetGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteAssetInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpFortuneBusiness',
      'DeleteAssetInfoAsync',
      data
    );
  }
}
