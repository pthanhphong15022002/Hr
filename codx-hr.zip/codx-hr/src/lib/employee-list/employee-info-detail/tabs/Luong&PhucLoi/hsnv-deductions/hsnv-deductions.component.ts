import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-deductions',
  templateUrl: './hsnv-deductions.component.html',
  styleUrls: ['./hsnv-deductions.component.scss']
})
export class HsnvDeductionsComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eOtherDeductionColumnGrid!: any[];

  @ViewChild('eDeductionGridViewID') eDeductionGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateDeductionHeaderGridCol1', { static: true })
  templateDeductionHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionHeaderGridCol2', { static: true })
  templateDeductionHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionHeaderGridCol3', { static: true })
  templateDeductionHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionHeaderGridCol4', { static: true })
  templateDeductionHeaderGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateOtherDeductionGridCol1', { static: true })
  templateOtherDeductionGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateOtherDeductionGridCol2', { static: true })
  templateOtherDeductionGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateOtherDeductionGridCol3', { static: true })
  templateOtherDeductionGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateOtherDeductionGridCol4', { static: true })
  templateOtherDeductionGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eDeductionsFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpOtherDeduction();
    this.initEDeductions();
  }

  
  initEDeductions() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eDeductionsFormModel = res;
    });
  }
  initEmpOtherDeduction() {
    if (!this.eOtherDeductionColumnGrid) {
      this.eOtherDeductionColumnGrid = [
        {
          headerTemplate: this.templateDeductionHeaderGridCol1,
          template: this.templateOtherDeductionGridCol1,
          width: '30%',
        },
        {
          headerTemplate: this.templateDeductionHeaderGridCol2,
          template: this.templateOtherDeductionGridCol2,
          width: '25%',
        },
        {
          headerTemplate: this.templateDeductionHeaderGridCol3,
          template: this.templateOtherDeductionGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateDeductionHeaderGridCol4,
          template: this.templateOtherDeductionGridCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteDeduction(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteDeductionInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eDeductionGridViewID){
                    clearInterval(ins);
                    this.eDeductionGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteDeductionInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'PayTExceptBusiness',
      'DeleteDeductionInfoAsync',
      data
    );
  }
}
