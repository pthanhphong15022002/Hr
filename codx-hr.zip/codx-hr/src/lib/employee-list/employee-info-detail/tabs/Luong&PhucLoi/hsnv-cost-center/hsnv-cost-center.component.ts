import { Component, Input } from '@angular/core';

@Component({
  selector: 'lib-hsnv-cost-center',
  templateUrl: './hsnv-cost-center.component.html',
  styleUrls: ['./hsnv-cost-center.component.css']
})
export class HsnvCostCenterComponent {
  @Input() funID: any;

}
