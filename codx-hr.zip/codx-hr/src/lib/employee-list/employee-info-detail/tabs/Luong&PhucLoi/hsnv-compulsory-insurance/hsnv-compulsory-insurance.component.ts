import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-compulsory-insurance',
  templateUrl: './hsnv-compulsory-insurance.component.html',
  styleUrls: ['./hsnv-compulsory-insurance.component.scss']
})
export class HsnvCompulsoryInsuranceComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID:any;
  eInsuranceColumnGrid!: any[];

  @ViewChild('eInsuranceGridViewID') eInsuranceGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateInsuranceHeaderGridCol1', { static: true })
  templateInsuranceHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceHeaderGridCol2', { static: true })
  templateInsuranceHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceHeaderGridCol3', { static: true })
  templateInsuranceHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceHeaderGridCol4', { static: true })
  templateInsuranceHeaderGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateInsuranceGridCol1', { static: true })
  templateInsuranceGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceGridCol2', { static: true })
  templateInsuranceGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceGridCol3', { static: true })
  templateInsuranceGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateInsuranceGridCol4', { static: true })
  templateInsuranceGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eInsuranceFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpInsurance();
    this.initEInsurance();
  }

  initEInsurance() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eInsuranceFormModel = res;
    });
  }
  initEmpInsurance() {
    if (!this.eInsuranceColumnGrid) {
      this.eInsuranceColumnGrid = [
        {
          headerTemplate: this.templateInsuranceHeaderGridCol1,
          template: this.templateInsuranceGridCol1,
          width: '20%',
        },
        {
          headerTemplate: this.templateInsuranceHeaderGridCol2,
          template: this.templateInsuranceGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateInsuranceHeaderGridCol3,
          template: this.templateInsuranceGridCol3,
          width: '25%',
        },
        {
          headerTemplate: this.templateInsuranceHeaderGridCol4,
          template: this.templateInsuranceGridCol4,
          width: '30%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteInsurance(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteInsuranceInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eInsuranceGridViewID){
                    clearInterval(ins);
                    this.eInsuranceGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteInsuranceInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpInsuranceBusiness',
      'DeleteInsuranceInfoAsync',
      data
    );
  }
}
