import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-previous-experience',
  templateUrl: './hsnv-previous-experience.component.html',
  styleUrls: ['./hsnv-previous-experience.component.scss']
})
export class HsnvPreviousExperienceComponent  extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;


  eExperiencesColumnGrid!: any[];

  @ViewChild('eExperienceGridViewID') eExperienceGridViewID: CodxGridviewV2Component;

  //Header
  @ViewChild('templateExperiencesHeaderGridCol1', { static: true })
  templateExperiencesHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateExperiencesHeaderGridCol2', { static: true })
  templateExperiencesHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateExperiencesHeaderGridCol3', { static: true })
  templateExperiencesHeaderGridCol3: TemplateRef<any> | undefined;

  @ViewChild('templateExperiencesGridCol1', { static: true })
  templateExperiencesGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateExperiencesGridCol2', { static: true })
  templateExperiencesGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateExperiencesGridCol3', { static: true })
  templateExperiencesGridCol3: TemplateRef<any> | undefined;

  
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eExperienceFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpExperiences();
    this.initEExperience();
  }

  initEExperience() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eExperienceFormModel = res;
    });
  }

  initEmpExperiences() {
    if (!this.eExperiencesColumnGrid) {
      this.eExperiencesColumnGrid = [
        {
          headerTemplate: this.templateExperiencesHeaderGridCol1,
          template: this.templateExperiencesGridCol1,
          width: '40%',
        },
        {
          headerTemplate: this.templateExperiencesHeaderGridCol2,
          template: this.templateExperiencesGridCol2,
          width: '25%',
        },
        {
          headerTemplate: this.templateExperiencesHeaderGridCol3,
          template: this.templateExperiencesGridCol3,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  deleteExperience(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteExperienceInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eExperienceGridViewID){
                    clearInterval(ins);
                    this.eExperienceGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteExperienceInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpExperienceBusiness',
      'DeleteExperienceInfoAsync',
      data
    );
  }
}
