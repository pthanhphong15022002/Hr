import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-appoint',
  templateUrl: './hsnv-appoint.component.html',
  styleUrls: ['./hsnv-appoint.component.scss']
})
export class HsnvAppointComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eAppointColumnGrid!: any[];

  @ViewChild('eAppointGridViewID') eAppointGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateAppointHeaderGridCol1', { static: true })
  templateAppointHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAppointHeaderGridCol2', { static: true })
  templateAppointHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAppointHeaderGridCol3', { static: true })
  templateAppointHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAppointHeaderGridCol4', { static: true })
  templateAppointHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateAppointHeaderGridCol5', { static: true })
  templateAppointHeaderGridCol5: TemplateRef<any> | undefined;
  @ViewChild('templateAppointHeaderGridCol6', { static: true })
  templateAppointHeaderGridCol6: TemplateRef<any> | undefined;
  
  @ViewChild('templateAppointGridCol1', { static: true })
  templateAppointGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateAppointGridCol2', { static: true })
  templateAppointGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateAppointGridCol3', { static: true })
  templateAppointGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateAppointGridCol4', { static: true })
  templateAppointGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateAppointGridCol5', { static: true })
  templateAppointGridCol5: TemplateRef<any> | undefined;
  @ViewChild('templateAppointGridCol6', { static: true })
  templateAppointGridCol6: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eAppointFormModel: FormModel = null;
 

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpAppoint();
    this.initEAppoint();
  }

  initEmpAppoint() {
    if (!this.eAppointColumnGrid) {
      this.eAppointColumnGrid = [
        {
          headerTemplate: this.templateAppointHeaderGridCol1,
          template: this.templateAppointGridCol1,
          width: '15%',
        },
        {
          headerTemplate: this.templateAppointHeaderGridCol2,
          template: this.templateAppointGridCol2,
          width: '10%',
        },
        {
          headerTemplate: this.templateAppointHeaderGridCol3,
          template: this.templateAppointGridCol3,
          width: '15%',
        },
        {
          headerTemplate: this.templateAppointHeaderGridCol4,
          template: this.templateAppointGridCol4,
          width: '10%',
        },
        {
          headerTemplate: this.templateAppointHeaderGridCol5,
          template: this.templateAppointGridCol5,
          width: '20%',
        },
        {
          headerTemplate: this.templateAppointHeaderGridCol6,
          template: this.templateAppointGridCol6,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  initEAppoint() {
    this.hrService.getFormModel('HREM10403').then((res) => {
      this.eAppointFormModel = res;
    });
  }

  deleteAppoint(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteAppointInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eAppointGridViewID){
                    clearInterval(ins);
                    this.eAppointGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteAppointInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpWorkingBusiness',
      'DeleteAppointInfoAsync',
      data
    );
  }
}
