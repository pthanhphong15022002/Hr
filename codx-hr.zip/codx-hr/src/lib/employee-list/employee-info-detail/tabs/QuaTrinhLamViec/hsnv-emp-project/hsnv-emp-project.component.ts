import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-project',
  templateUrl: './hsnv-emp-project.component.html',
  styleUrls: ['./hsnv-emp-project.component.scss']
})
export class HsnvEmpProjectComponent  extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eProjectColumnGrid!: any[];

  @ViewChild('eProjectGridViewID') eProjectGridViewID: CodxGridviewV2Component;

  // Header 
  @ViewChild('templateProjectHeaderGridCol1', { static: true })
  templateProjectHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateProjectHeaderGridCol2', { static: true })
  templateProjectHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateProjectHeaderGridCol3', { static: true })
  templateProjectHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateProjectHeaderGridCol4', { static: true })
  templateProjectHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateProjectHeaderGridCol5', { static: true })
  templateProjectHeaderGridCol5: TemplateRef<any> | undefined;
  @ViewChild('templateProjectHeaderGridCol6', { static: true })
  templateProjectHeaderGridCol6: TemplateRef<any> | undefined;

  @ViewChild('templateProjectGridCol1', { static: true })
  templateProjectGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateProjectGridCol2', { static: true })
  templateProjectGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateProjectGridCol3', { static: true })
  templateProjectGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateProjectGridCol4', { static: true })
  templateProjectGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateProjectGridCol5', { static: true })
  templateProjectGridCol5: TemplateRef<any> | undefined;
  @ViewChild('templateProjectGridCol6', { static: true })
  templateProjectGridCol6: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eProjectFormModel: FormModel = null;
 


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpProject();
    this.initEProject();
  }

  initEProject() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eProjectFormModel = res;
    });
  }

  initEmpProject() {
    if (!this.eProjectColumnGrid) {
      this.eProjectColumnGrid = [
        {
          headerTemplate: this.templateProjectHeaderGridCol1,
          template: this.templateProjectGridCol1,
          width: '10%',
        },
        {
          headerTemplate: this.templateProjectHeaderGridCol2,
          template: this.templateProjectGridCol2,
          width: '10%',
        },
        {
          headerTemplate: this.templateProjectHeaderGridCol3,
          template: this.templateProjectGridCol3,
          width: '10%',
        },
        {
          headerTemplate: this.templateProjectHeaderGridCol4,
          template: this.templateProjectGridCol4,
          width: '20%',
        },
        {
          headerTemplate: this.templateProjectHeaderGridCol5,
          template: this.templateProjectGridCol5,
          width: '30%',
        },
        {
          headerTemplate: this.templateProjectHeaderGridCol6,
          template: this.templateProjectGridCol6,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

  deleteProject(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteProjectInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eProjectGridViewID){
                    clearInterval(ins);
                    this.eProjectGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteProjectInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpProjectBusiness',
      'DeleteProjectInfoAsync',
      data
    );
  }
}
