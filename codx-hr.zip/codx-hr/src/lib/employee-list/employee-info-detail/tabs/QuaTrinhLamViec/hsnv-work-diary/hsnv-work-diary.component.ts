import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-work-diary',
  templateUrl: './hsnv-work-diary.component.html',
  styleUrls: ['./hsnv-work-diary.component.scss']
})
export class HsnvWorkDiaryComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eWorkDiaryColumnGrid!: any[];

  @ViewChild('eDiaryGridViewID') eDiaryGridViewID: CodxGridviewV2Component;
  
  // Header
  @ViewChild('templateWorkDiaryHeaderGridCol1', { static: true })
  templateWorkDiaryHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryHeaderGridCol2', { static: true })
  templateWorkDiaryHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryHeaderGridCol3', { static: true })
  templateWorkDiaryHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryHeaderGridCol4', { static: true })
  templateWorkDiaryHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryHeaderGridCol5', { static: true })
  templateWorkDiaryHeaderGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateWorkDiaryGridCol1', { static: true })
  templateWorkDiaryGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryGridCol2', { static: true })
  templateWorkDiaryGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryGridCol3', { static: true })
  templateWorkDiaryGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryGridCol4', { static: true })
  templateWorkDiaryGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateWorkDiaryGridCol5', { static: true })
  templateWorkDiaryGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eDiaryFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpWorkDiary();
    this.initEDiary();
  }

   // Nhật ký công tác
  initEDiary() {
     this.hrService.getFormModel(this.funID).then((res) => {
       this.eDiaryFormModel = res;
     });
   }
 

  initEmpWorkDiary() {
    if (!this.eWorkDiaryColumnGrid) {
      this.eWorkDiaryColumnGrid = [
        {
          headerTemplate: this.templateWorkDiaryHeaderGridCol1,
          template: this.templateWorkDiaryGridCol1,
          width: '10%',
        },
        {
          headerTemplate: this.templateWorkDiaryHeaderGridCol2,
          template: this.templateWorkDiaryGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateWorkDiaryHeaderGridCol3,
          template: this.templateWorkDiaryGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateWorkDiaryHeaderGridCol4,
          template: this.templateWorkDiaryGridCol4,
          width: '20%',
        },
        {
          headerTemplate: this.templateWorkDiaryHeaderGridCol5,
          template: this.templateWorkDiaryGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  deleteWorkDiary(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteWorkDiaryInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eDiaryGridViewID){
                    clearInterval(ins);
                    this.eDiaryGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteWorkDiaryInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpBusinessDiaryBusiness',
      'DeleteWorkDiaryInfoAsync',
      data
    );
  }
}
