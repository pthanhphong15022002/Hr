import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-work-performed',
  templateUrl: './hsnv-work-performed.component.html',
  styleUrls: ['./hsnv-work-performed.component.scss']
})
export class HsnvWorkPerformedComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eWorkPerformedColumnGrid!: any[];

  @ViewChild('eWorkGridViewID') eWorkGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateWorkHeaderGridCol1', { static: true })
  templateWorkHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateWorkHeaderGridCol2', { static: true })
  templateWorkHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateWorkHeaderGridCol3', { static: true })
  templateWorkHeaderGridCol3: TemplateRef<any> | undefined;

  @ViewChild('templateWorkPerformedGridCol1', { static: true })
  templateWorkPerformedGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateWorkPerformedGridCol2', { static: true })
  templateWorkPerformedGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateWorkPerformedGridCol3', { static: true })
  templateWorkPerformedGridCol3: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eTaskFormModel: FormModel = null;
  
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpWorkPerformed();
    this.initETask();
  }

  initETask() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eTaskFormModel = res;
    });
  }

  initEmpWorkPerformed() {
    if (!this.eWorkPerformedColumnGrid) {
      this.eWorkPerformedColumnGrid = [
        {
          headerTemplate: this.templateWorkHeaderGridCol1,
          template: this.templateWorkPerformedGridCol1,
          width: '20%',
        },
        {
          headerTemplate: this.templateWorkHeaderGridCol2,
          template: this.templateWorkPerformedGridCol2,
          width: '40%',
        },
        {
          headerTemplate: this.templateWorkHeaderGridCol3,
          template: this.templateWorkPerformedGridCol3,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  deleteWorkPerformed(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteWorkPerformedInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eWorkGridViewID){
                    clearInterval(ins);
                    this.eWorkGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteWorkPerformedInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpTask2Business',
      'DeleteWorkPerformedInfoAsync',
      data
    );
  }
}
