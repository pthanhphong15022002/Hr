import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-internal-training',
  templateUrl: './hsnv-internal-training.component.html',
  styleUrls: ['./hsnv-internal-training.component.scss']
})
export class HsnvInternalTrainingComponent extends UIComponent {
  @Input() employeeID:any;
  eTrainingColumnGrid!: any[];

  @ViewChild('templateTrainingGridCol1', { static: true })
  templateTrainingGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateTrainingGridCol2', { static: true })
  templateTrainingGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateTrainingGridCol3', { static: true })
  templateTrainingGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateTrainingGridCol4', { static: true })
  templateTrainingGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eTrainCoursesFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpTraining();
    this.initETrainCourse();
  }

  initETrainCourse() {
    this.hrService.getFormModel('HREM10504').then((res) => {
      this.eTrainCoursesFormModel = res;
    });
  }

  initEmpTraining() {
    if (!this.eTrainingColumnGrid) {
      this.eTrainingColumnGrid = [
        {
          headerText: 'Khóa đào tạo',
          template: this.templateTrainingGridCol1,
          width: '20%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templateTrainingGridCol2,
          width: '25%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templateTrainingGridCol3,
          width: '25%',
        },
        {
          headerText: 'Năm công bố',
          template: this.templateTrainingGridCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };
}
