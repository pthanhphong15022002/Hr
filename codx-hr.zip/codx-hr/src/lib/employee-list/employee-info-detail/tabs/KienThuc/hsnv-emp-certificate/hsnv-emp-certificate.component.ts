import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-certificate',
  templateUrl: './hsnv-emp-certificate.component.html',
  styleUrls: ['./hsnv-emp-certificate.component.scss']
})
export class HsnvEmpCertificateComponent extends UIComponent {
  @Input() employeeID:any;
  eCertificatesColumnGrid!: any[];

  @ViewChild('templateCertificatesGridCol1', { static: true })
  templateCertificatesGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateCertificatesGridCol2', { static: true })
  templateCertificatesGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateCertificatesGridCol3', { static: true })
  templateCertificatesGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eCertificatesFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpCertificates();
    this.initECertificates();
  }


  initEmpCertificates() {
    if (!this.eCertificatesColumnGrid) {
      this.eCertificatesColumnGrid = [
        {
          headerText: 'Chứng chỉ',
          template: this.templateCertificatesGridCol1,
          width: '30%',
        },
        {
          headerText: 'Loại chứng chỉ',
          template: this.templateCertificatesGridCol2,
          width: '30%',
        },
        {
          headerText: 'Ngày cấp ',
          template: this.templateCertificatesGridCol3,
          width: '30%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  // Chứng chỉ
  initECertificates() {
    this.hrService.getFormModel('HREM10502').then((res) => {
      this.eCertificatesFormModel = res;
    });
  }


}
