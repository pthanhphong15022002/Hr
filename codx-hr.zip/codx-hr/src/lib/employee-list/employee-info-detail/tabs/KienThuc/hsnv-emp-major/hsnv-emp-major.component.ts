import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-major',
  templateUrl: './hsnv-emp-major.component.html',
  styleUrls: ['./hsnv-emp-major.component.scss']
})
export class HsnvEmpMajorComponent extends UIComponent {
  @Input() employeeID:any;
  eMajorColumnGrid!: any[];

  @ViewChild('templateMajorGridCol1', { static: true })
  templateMajorGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateMajorGridCol2', { static: true })
  templateMajorGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateMajorGridCol3', { static: true })
  templateMajorGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eMajorFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpMajor();
    this.initEMajor()
  }


  initEmpMajor() {
    if (!this.eMajorColumnGrid) {
      this.eMajorColumnGrid = [
        {
          headerText: 'Chuyên ngành',
          template: this.templateMajorGridCol1,
          width: '40%',
        },
        {
          headerText: 'Thời gian đào tạo',
          template: this.templateMajorGridCol2,
          width: '20%',
        },
        {
          headerText: 'Đến',
          template: this.templateMajorGridCol3,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  // Chuyên ngành đào tạo
  initEMajor() {
    this.hrService.getFormModel('HREM10501').then((res) => {
      this.eMajorFormModel = res;
    });
  }
}
