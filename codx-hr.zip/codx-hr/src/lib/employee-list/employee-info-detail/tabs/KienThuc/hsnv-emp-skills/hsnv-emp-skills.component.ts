import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-skills',
  templateUrl: './hsnv-emp-skills.component.html',
  styleUrls: ['./hsnv-emp-skills.component.scss']
})
export class HsnvEmpSkillsComponent extends UIComponent {
  @Input() employeeID:any;
  eSkillsColumnGrid!: any[];

  @ViewChild('templateSkillsGridCol1', { static: true })
  templateSkillsGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateSkillsGridCol2', { static: true })
  templateSkillsGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateSkillsGridCol3', { static: true })
  templateSkillsGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eSkillFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initESkill();
    this.initEmpSkills();
  }
  


  initEmpSkills() {
    if (!this.eSkillsColumnGrid) {
      this.eSkillsColumnGrid = [
        {
          headerText: 'Kỹ năng',
          template: this.templateSkillsGridCol1,
          width: '30%',
        },
        {
          headerText: 'Cấp độ',
          template: this.templateSkillsGridCol2,
          width: '20%',
        },
        {
          headerText: 'Ghi chú',
          template: this.templateSkillsGridCol3,
          width: '30%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  initESkill() {
    this.hrService.getFormModel('HREM10503').then((res) => {
      this.eSkillFormModel = res;
    });
  }

}
