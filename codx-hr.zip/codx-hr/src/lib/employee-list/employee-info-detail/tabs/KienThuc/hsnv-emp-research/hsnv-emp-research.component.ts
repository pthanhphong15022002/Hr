import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-research',
  templateUrl: './hsnv-emp-research.component.html',
  styleUrls: ['./hsnv-emp-research.component.scss']
})
export class HsnvEmpResearchComponent extends UIComponent {
  @Input() employeeID:any;

  eResearchColumnGrid!: any[];

  @ViewChild('templateResearchGridCol1', { static: true })
  templateResearchGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateResearchGridCol2', { static: true })
  templateResearchGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateResearchGridCol3', { static: true })
  templateResearchGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateResearchGridCol4', { static: true })
  templateResearchGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateResearchGridCol5', { static: true })
  templateResearchGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eResearchFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpResearch();
    this.initEResearch();
  }

  initEmpResearch() {
    if (!this.eResearchColumnGrid) {
      this.eResearchColumnGrid = [
        {
          headerText: 'Mã',
          template: this.templateResearchGridCol1,
          width: '10%',
        },
        {
          headerText: 'Tên nghiên cứu',
          template: this.templateResearchGridCol2,
          width: '30%',
        },
        {
          headerText: 'Năm công bố',
          template: this.templateResearchGridCol3,
          width: '15%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templateResearchGridCol4,
          width: '15%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templateResearchGridCol5,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '15%',
        }
      ];
    }
  };

  initEResearch() {
    this.hrService.getFormModel('HREM10505').then((res) => {
      this.eResearchFormModel = res;
    });
  }
}
