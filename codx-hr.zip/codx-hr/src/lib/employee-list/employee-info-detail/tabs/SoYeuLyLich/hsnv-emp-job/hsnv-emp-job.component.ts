import { ChangeDetectorRef, Component, Injector, Input } from '@angular/core';
import { CRUDService, CallFuncService, CodxFormDynamicComponent, DataRequest, FormModel, SidebarModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-job',
  templateUrl: './hsnv-emp-job.component.html',
  styleUrls: ['./hsnv-emp-job.component.scss']
})
export class HsnvEmpJobComponent extends UIComponent {
  override onInit(): void {
    this.initEInfoCVPersonal();
    this.initEmpInfoCVJobInfoTS();
    this.initEmpInfoCVJobInfoPosition();
    this.initEmpInfoCVJobInfoDept();
  }
  @Input() infoPersonal:any
  empInfoCVJobInfoFuncId = "HREM1010201";
  empInfoCVJobInfoTSFuncId = "HREM1010202";
  empInfoCVJobInfoDeptFuncId = "HREM1010203";
  empInfoCVJobInfoPositionFuncId = "HREM1010204";
  @Input() funID: any;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService,
  ){
    super(inject);
  }

// khởi tạo form model cho thông tin cơ bản
  eEmpInfoCVJobFormModel: FormModel;
  initEInfoCVPersonal() {
    this.hrService.getFormModel(this.empInfoCVJobInfoFuncId).then((res) => {
      this.eEmpInfoCVJobFormModel = res;
      this.hrService
        .getFormGroup(
          this.eEmpInfoCVJobFormModel.formName,
          this.eEmpInfoCVJobFormModel.gridViewName,
          this.eEmpInfoCVJobFormModel
        );
    }); 
  }
// hàm khi gọi sự kiện chỉnh sửa thông tin cơ bản
  editEmployeeJobInfo() {
    this.handleEditInfo('Chỉnh sửa', this.eEmpInfoCVJobFormModel);
    }
 
// hàm khi gọi sự kiện chỉnh sửa thông tin chấm công
editEmpInfoCVJobInfoTS() {
  this.handleEditInfo('Chỉnh sửa', this.empInfoCVJobInfoTSFormModel);
  }
  // khởi tạo form model cho thông tin chám công
  empInfoCVJobInfoTSFormModel: FormModel;
  initEmpInfoCVJobInfoTS() {
    this.hrService.getFormModel(this.empInfoCVJobInfoTSFuncId).then((res) => {
      this.empInfoCVJobInfoTSFormModel = res;
      this.hrService
        .getFormGroup(
          this.empInfoCVJobInfoTSFormModel.formName,
          this.empInfoCVJobInfoTSFormModel.gridViewName,
          this.empInfoCVJobInfoTSFormModel
        );
    }); 
  }
// hàm khi gọi sự kiện chỉnh sửa thông tin Bộ phận làm việc
  editEmpInfoCVJobInfoDept() {
    this.handleEditInfo('Chỉnh sửa', this.empInfoCVJobInfoDeptFormModel);
    }

      // khởi tạo form model cho thông tin bộ phận làm việc
  empInfoCVJobInfoDeptFormModel: FormModel;
  initEmpInfoCVJobInfoDept() {
    this.hrService.getFormModel(this.empInfoCVJobInfoDeptFuncId).then((res) => {
      this.empInfoCVJobInfoTSFormModel = res;
      this.hrService
        .getFormGroup(
          this.empInfoCVJobInfoDeptFormModel.formName,
          this.empInfoCVJobInfoDeptFormModel.gridViewName,
          this.empInfoCVJobInfoDeptFormModel
        );
    }); 
  }

// hàm khi gọi sự kiện chỉnh sửa thông tin công việc
editEmpInfoCVJobInfoPosition() {
  this.handleEditInfo('Chỉnh sửa', this.empInfoCVJobInfoPositionFormModel);
  }

    // khởi tạo form model cho thông tin công việc
  empInfoCVJobInfoPositionFormModel: FormModel;
initEmpInfoCVJobInfoPosition() {
  this.hrService.getFormModel(this.empInfoCVJobInfoPositionFuncId).then((res) => {
    this.empInfoCVJobInfoPositionFormModel = res;
    this.hrService
      .getFormGroup(
        this.empInfoCVJobInfoPositionFormModel.formName,
        this.empInfoCVJobInfoPositionFormModel.gridViewName,
        this.empInfoCVJobInfoPositionFormModel
      );
  }); 
}
  
    // hàm thực thi gọi pop up chỉnh sửa thông tin
    handleEditInfo(actionHeaderText: string, formModel: FormModel) {
      let tempData = JSON.parse(JSON.stringify(this.infoPersonal));
      var dataService = new CRUDService(this.inject);
      let request = new DataRequest(
        formModel?.formName,
        formModel?.gridViewName,
        formModel?.entityName
        // "HR_Employees"
      );
      request.funcID = formModel?.funcID;
      dataService.service = 'HR';
      dataService.request = request;
      dataService.edit(tempData).subscribe((res) => {
        let option = new SidebarModel();
        option.FormModel = formModel;
        option.Width = '550px';
        let dialogAdd = this.callfunc.openSide(
          CodxFormDynamicComponent,
          {
            formModel: option.FormModel,
            data: res,
            function: null,
            dataService: dataService,
            isView: false,
            titleMore: actionHeaderText,
          },
          option
        );
  
        dialogAdd.closed.subscribe((res) => {
          dataService.clear();
          if (res?.event) {
            let temp3 = res.event.update.data;
            this.infoPersonal = temp3;
          }
          this.df.detectChanges();
        });
      });
    }

}
