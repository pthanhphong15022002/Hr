import { ChangeDetectorRef, Component, Injector, Input } from '@angular/core';
import { CRUDService, CallFuncService, CodxFormDynamicComponent, DataRequest, FormModel, SidebarModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-hiring',
  templateUrl: './hsnv-emp-hiring.component.html',
  styleUrls: ['./hsnv-emp-hiring.component.scss']
})
export class HsnvEmpHiringComponent  extends UIComponent  {

  @Input() infoPersonal:any;
  empInfoCVRecruitFuncId = 'HREM1010301';
  empInfoCVRecruitDeptFuncId = 'HREM1010302';
  empInfoCVRecruitResultFuncId = 'HREM1010303';



  @Input() funID:any;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService,
  ){
    super(inject);
    
  }

  onInit(): void {
    console.log(111);
    
    this.initEInfoCVRecruit();
    this.initEmpInfoCVRecruitDept();
    this.initEmpInfoCVRecruitResult();
  }

// khởi tao form model cho thông tin tuyển dụng
  eEmpInfoCVRecruitFormModel: FormModel = null;
  initEInfoCVRecruit() {
    this.hrService.getFormModel(this.empInfoCVRecruitFuncId).then((res) => {
      this.eEmpInfoCVRecruitFormModel = res;
      this.hrService
        .getFormGroup(
          this.eEmpInfoCVRecruitFormModel.formName,
          this.eEmpInfoCVRecruitFormModel.gridViewName,
          this.eEmpInfoCVRecruitFormModel
        );
    }); 
  }

  // hàm call pop up chỉnh sửa thông tin tuyển dụng
  editEmpInfoCVRecruit(actionHeaderText) {
    debugger
    let tempData = this.infoPersonal;
    var dataService = new CRUDService(this.inject);
    let request = new DataRequest(
      this.eEmpInfoCVRecruitFormModel?.formName,
      this.eEmpInfoCVRecruitFormModel?.gridViewName,
      this.eEmpInfoCVRecruitFormModel?.entityName
      // "HR_Employees"
    );
    request.funcID = this.eEmpInfoCVRecruitFormModel?.funcID;
    dataService.service = 'HR';
    dataService.request = request;
    dataService.edit(tempData).subscribe((res) => {
      let option = new SidebarModel();
      option.FormModel = this.eEmpInfoCVRecruitFormModel;
      option.Width = '550px';
      let dialogAdd = this.callfunc.openSide(
        CodxFormDynamicComponent,
        {
          formModel: option.FormModel,
          data: res,
          function: null,
          dataService: dataService,
          isView: false,
          titleMore: actionHeaderText,
        },
        option
      );

      dialogAdd.closed.subscribe((res) => {
        dataService.clear();
        if (res?.event) {
          let temp3 = res.event.update.data;
          this.infoPersonal = temp3;
        }
        this.df.detectChanges();
      });
    });
  }

// khởi tạo form model cho bộ phận tuyển dụng ban đầu
  eEmpInfoCVRecruitDept: FormModel = null;
  initEmpInfoCVRecruitDept() {
    this.hrService.getFormModel(this.empInfoCVRecruitDeptFuncId).then((res) => {
      this.eEmpInfoCVRecruitDept = res;
      this.hrService
      .getFormGroup(
        this.eEmpInfoCVRecruitDept.formName,
        this.eEmpInfoCVRecruitDept.gridViewName,
        this.eEmpInfoCVRecruitDept
      );
    }); 
  }

  // hàm call pop up chỉnh sửa bộ phân tuyển dụng ban đầu
  editEmpInfoCVRecruitDept(actionHeaderText) {
    let tempData = this.infoPersonal;
    var dataService = new CRUDService(this.inject);
    let request = new DataRequest(
      this.eEmpInfoCVRecruitDept?.formName,
      this.eEmpInfoCVRecruitDept?.gridViewName,
      this.eEmpInfoCVRecruitFormModel?.entityName
      // "HR_Employees"
    );
    request.funcID = this.eEmpInfoCVRecruitDept?.funcID;
    dataService.service = 'HR';
    dataService.request = request;
    dataService.edit(tempData).subscribe((res) => {
      let option = new SidebarModel();
      option.FormModel = this.eEmpInfoCVRecruitDept;
      option.Width = '550px';
      let dialogAdd = this.callfunc.openSide(
        CodxFormDynamicComponent,
        {
          formModel: option.FormModel,
          data: res,
          function: null,
          dataService: dataService,
          isView: false,
          titleMore: actionHeaderText,
        },
        option
      );

      dialogAdd.closed.subscribe((res) => {
        dataService.clear();
        if (res?.event) {
          let temp3 = res.event.update.data;
          this.infoPersonal = temp3;
        }
        this.df.detectChanges();
      });
    });
  }
  // khởi tạo form model cho kết quả tuyển dụng
  eEmpInfoCVRecruitResult: FormModel = null;
  initEmpInfoCVRecruitResult() {
    this.hrService.getFormModel(this.empInfoCVRecruitDeptFuncId).then((res) => {
      this.eEmpInfoCVRecruitResult = res;
      this.hrService
      .getFormGroup(
        this.eEmpInfoCVRecruitResult.formName,
        this.eEmpInfoCVRecruitResult.gridViewName,
        this.eEmpInfoCVRecruitResult
      );
    }); 
  }

  // hàm call pop up chỉnh sửa kết quả cho bộ phận tuyển dụng
  editEmpInfoCVRecruitResult(actionHeaderText) {
    let tempData = this.infoPersonal;
    var dataService = new CRUDService(this.inject);
    let request = new DataRequest(
      this.eEmpInfoCVRecruitResult?.formName,
      this.eEmpInfoCVRecruitResult?.gridViewName,
      this.eEmpInfoCVRecruitResult?.entityName
      // "HR_Employees"
    );
    request.funcID = this.eEmpInfoCVRecruitResult?.funcID;
    dataService.service = 'HR';
    dataService.request = request;
    dataService.edit(tempData).subscribe((res) => {
      let option = new SidebarModel();
      option.FormModel = this.eEmpInfoCVRecruitResult;
      option.Width = '550px';
      let dialogAdd = this.callfunc.openSide(
        CodxFormDynamicComponent,
        {
          formModel: option.FormModel,
          data: res,
          function: null,
          dataService: dataService,
          isView: false,
          titleMore: actionHeaderText,
        },
        option
      );

      dialogAdd.closed.subscribe((res) => {
        dataService.clear();
        if (res?.event) {
          let temp3 = res.event.update.data;
          this.infoPersonal = temp3;
        }
        this.df.detectChanges();
      });
    });
  }
}
