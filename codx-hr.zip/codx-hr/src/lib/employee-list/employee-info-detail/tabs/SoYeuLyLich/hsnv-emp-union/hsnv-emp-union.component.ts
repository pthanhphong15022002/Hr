import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-union',
  templateUrl: './hsnv-emp-union.component.html',
  styleUrls: ['./hsnv-emp-union.component.scss']
})
export class HsnvEmpUnionComponent extends UIComponent {
  @Input() infoPersonal:any;
  @Input() funID:any;
  eEmpInfoCVPartyFormModel: FormModel;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  onInit(): void {
    this.initEInfoCVParty();
  }
  initEInfoCVParty() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpInfoCVPartyFormModel = res;
    }); 
  }
  
}
