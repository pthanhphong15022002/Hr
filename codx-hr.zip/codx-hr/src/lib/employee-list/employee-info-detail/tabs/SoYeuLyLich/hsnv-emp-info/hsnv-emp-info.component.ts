import { ChangeDetectorRef, Component, Injector, Input, Output } from '@angular/core';
import { CRUDService, CallFuncService, CodxFormDynamicComponent, DataRequest, FormModel, SidebarModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-info',
  templateUrl: './hsnv-emp-info.component.html',
  styleUrls: ['./hsnv-emp-info.component.scss']
})
export class HsnvEmpInfoComponent extends UIComponent  {

  @Input() infoPersonal:any;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService,
  ){
    super(inject);
  }

  
  onInit(): void {
    this.initEInfoCVContact();
    this.initEInfoCVPersonal();
  }
 // Tab Sơ yếu lí lịch
  // Tab Thông tin cá nhân
  // Lý lịch cá nhân

  //Edit thông tin liên hệ
  editEmployeeInfoContact() {
    this.editEmployeeContactInfo("Chỉnh sửa");
    
  }

  // Edit Sơ yếu lý lịch
  editEmployeeInfo() {
    this.handleEditEmployeeInfo("Chỉnh sửa");
  }
  eEmpInfoCVPersonalFormModel: FormModel = null;
  initEInfoCVPersonal() {
    this.hrService.getFormModel('HREM1010101').then((res) => {
      this.eEmpInfoCVPersonalFormModel = res;
      this.hrService
        .getFormGroup(
          this.eEmpInfoCVPersonalFormModel.formName,
          this.eEmpInfoCVPersonalFormModel.gridViewName,
          this.eEmpInfoCVPersonalFormModel
        );
    }); 
  }

  handleEditEmployeeInfo(actionHeaderText) {
    // let tempData = this.infoPersonal;
    let tempData = JSON.parse(JSON.stringify(this.infoPersonal));
    console.log('temdata',tempData)
    var dataService = new CRUDService(this.inject);
    let request = new DataRequest(
      this.eEmpInfoCVPersonalFormModel?.formName,
      this.eEmpInfoCVPersonalFormModel?.gridViewName,
      // this.eEmpInfoCVPersonalFormModel?.entityName
      "HR_Employees"
    );
    request.funcID = this.eEmpInfoCVPersonalFormModel?.funcID;
    dataService.service = 'HR';
    dataService.request = request;
    dataService.edit(tempData).subscribe((res) => {
      let option = new SidebarModel();
      option.FormModel = this.eEmpInfoCVPersonalFormModel;
      option.Width = '850px';
      let dialogAdd = this.callfunc.openSide(
        CodxFormDynamicComponent,
        {
          formModel: option.FormModel,
          data: res,
          function: null,
          dataService: dataService,
          isView: false,
          titleMore: actionHeaderText,
        },
        option
      );

      dialogAdd.closed.subscribe((res) => {
        dataService.clear();
        if (res?.event) {
          let temp3 = res.event.update.data;
          this.infoPersonal = temp3;
        }
        this.df.detectChanges();
      });
    });
  }

  // Liên hệ
  eEmpInfoCVContactFormModel: FormModel = null;
  initEInfoCVContact() {
    this.hrService.getFormModel('HREM1010102').then((res) => {
      this.eEmpInfoCVContactFormModel = res;
    }); 
  }

  editEmployeeContactInfo(actionHeaderText) {
    let tempData = this.infoPersonal;
    var dataService = new CRUDService(this.inject);
    let request = new DataRequest(
      this.eEmpInfoCVContactFormModel?.formName,
      this.eEmpInfoCVContactFormModel?.gridViewName,
      // this.eEmpInfoCVContactFormModel?.entityName
      "HR_Employees"
    );
    request.funcID = this.eEmpInfoCVContactFormModel?.funcID;
    dataService.service = 'HR';
    dataService.request = request;
    dataService.edit(tempData).subscribe((res) => {
      let option = new SidebarModel();
      option.FormModel = this.eEmpInfoCVContactFormModel;
      option.Width = '550px';
      let dialogAdd = this.callfunc.openSide(
        CodxFormDynamicComponent,
        {
          formModel: option.FormModel,
          data: res,
          function: null,
          dataService: dataService,
          isView: false,
          titleMore: actionHeaderText,
        },
        option
      );

      dialogAdd.closed.subscribe((res) => {
        dataService.clear();
        if (res?.event) {
          let temp3 = res.event.update.data;
          this.infoPersonal = temp3;
        }
        this.df.detectChanges();
      });
    });
  }
}
