import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-foreign',
  templateUrl: './hsnv-emp-foreign.component.html',
  styleUrls: ['./hsnv-emp-foreign.component.scss']
})
export class HsnvEmpForeignComponent extends UIComponent {
  @Input() infoPersonal:any;
  @Input() funID:any;
  eEmpInfoCVForeignerFormModel: FormModel;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  onInit(): void {
    this.initEInfoCVForeigner();
  }

  initEInfoCVForeigner() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpInfoCVForeignerFormModel = res;
    }); 
  }
}
