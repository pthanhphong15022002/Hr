import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-document-submit',
  templateUrl: './hsnv-emp-document-submit.component.html',
  styleUrls: ['./hsnv-emp-document-submit.component.scss']
})
export class HsnvEmpDocumentSubmitComponent extends UIComponent {
  @Input() funID:any;

  eContractColumnGrid1!: any[];
  @ViewChild('eDocumentSubmitGridViewID') eDocumentSubmitGridViewID: CodxGridviewV2Component ;
  @ViewChild('templateEContractGridCol1', { static: true })
  templateEContractGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEContractGridCol2', { static: true })
  templateEContractGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEContractGridCol3', { static: true })
  templateEContractGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEContractGridCol4', { static: true })
  templateEContractGridCol4: TemplateRef<any> | undefined;

  // Header
  @ViewChild('templateEContractHeaderGridCol1', { static: true })
  templateEContractHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEContractHeaderGridCol2', { static: true })
  templateEContractHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEContractHeaderGridCol3', { static: true })
  templateEContractHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEContractHeaderGridCol4', { static: true })
  templateEContractHeaderGridCol4: TemplateRef<any> | undefined;

  // Button Edit, Delete
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  employeeID:any;
  eDocumentFormModel: FormModel;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }

  onInit(): void {
    this.initEmpContract();
    this.initEDocument();
    this.activedRoute.queryParams.subscribe((params) => {
      this.employeeID = params['employeeID'];
    })
  }

  initEDocument() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eDocumentFormModel = res;
    }); 
  }
  initEmpContract() {
    if (!this.eContractColumnGrid1) {
      this.eContractColumnGrid1 = [
        {
          headerTemplate: this.templateEContractHeaderGridCol1,          
          template: this.templateEContractGridCol1,
          width: '10%',
        },
        {
          headerTemplate: this.templateEContractHeaderGridCol2,
          template: this.templateEContractGridCol2,
          width: '30%',
        },
        {
          headerTemplate: this.templateEContractHeaderGridCol3,
          template: this.templateEContractGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateEContractHeaderGridCol4,
          template: this.templateEContractGridCol4,
          width: '30%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
    // this.df.detectChanges();
  };

  deleteDocumentSubmit(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteDocumentSubmitInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eDocumentSubmitGridViewID){
                    clearInterval(ins);
                    this.eDocumentSubmitGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteDocumentSubmitInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpDocumentBusiness',
      'DeleteDocumentSubmitInfoAsync',
      data
    );
  }
}
