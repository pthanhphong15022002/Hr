import {
  ChangeDetectorRef,
  Component,
  Injector,
  Input,
  TemplateRef,
  ViewChild,
  EventEmitter,
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import {
  CRUDService,
  CallFuncService,
  CodxFormDynamicComponent,
  DataRequest,
  FormModel,
  SidebarModel,
  UIComponent,
  DataService,
  CodxGridviewV2Component,
  NotificationsService,
  Util,
} from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-family',
  templateUrl: './hsnv-emp-family.component.html',
  styleUrls: ['./hsnv-emp-family.component.scss'],
})
export class HsnvEmpFamilyComponent extends UIComponent {
  @Input() infoPersonal: any;
  @Input() employeeID: any;
  @Input() funID: any;
  // Thân nhân
  eFamilyColumnGrid!: any[];
  lstFamily: any = []; // Danh sách thân nhân
  

  @ViewChild('eFamilyGridViewID') eFamilyGridViewID: CodxGridviewV2Component;

  @ViewChild('templateFamilyHeaderGridCol1', { static: true })
  templateFamilyHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyHeaderGridCol2', { static: true })
  templateFamilyHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyHeaderGridCol3', { static: true })
  templateFamilyHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyHeaderGridCol4', { static: true })
  templateFamilyHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyHeaderGridCol5', { static: true })
  templateFamilyHeaderGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateFamilyGridCol1', { static: true })
  templateFamilyGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyGridCol2', { static: true })
  templateFamilyGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyGridCol3', { static: true })
  templateFamilyGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyGridCol4', { static: true })
  templateFamilyGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateFamilyGridCol5', { static: true })
  templateFamilyGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eFamilyInfoFormModel: FormModel;
  eFamilyInfoGroupFormModel: FormGroup;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ) {
    super(inject);
  }

  onInit(): void {
    this.initTmplateEmpFamily();
    this.initEFamily();
    this.activedRoute.queryParams.subscribe((params) => {
      this.employeeID = params['employeeID'];
    });
    this.getEmpCurrentData(this.employeeID).subscribe((res) => {
      if (res) {
        this.lstFamily = res[3];
      }
    });
  }

   initTmplateEmpFamily() {
    if (!this.eFamilyColumnGrid) {
      this.eFamilyColumnGrid = [
        {
          headerTemplate: this.templateFamilyHeaderGridCol1,
          template: this.templateFamilyGridCol1,
          width: '25%',
        },
        {
          headerTemplate: this.templateFamilyHeaderGridCol2,
          template: this.templateFamilyGridCol2,
          width: '10%',
        },
        {
          headerTemplate: this.templateFamilyHeaderGridCol3,
          template: this.templateFamilyGridCol3,
          width: '15%',
        },
        {
          headerTemplate: this.templateFamilyHeaderGridCol4,
          template: this.templateFamilyGridCol4,
          width: '25%',
        },
        {
          headerTemplate: this.templateFamilyHeaderGridCol5,
          template: this.templateFamilyGridCol5,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        },
      ];
    }
  }

  initEFamily() {
    //hard code - fix later
    this.hrService.getFormModel('HREM10104').then((res) => {
      this.eFamilyInfoFormModel = res;
      console.log(this.eFamilyInfoFormModel);
    });
  }

  itemSelected: any;

  // Thêm thân nhân
  addFamilyInfo() {
    // this.addEmployeeFamilyInfo('Chỉnh sửa');
  }

  // Sửa thân nhân
  editFamilyInfo(data: any) {
    this.itemSelected = data;
    console.log('data edit', data)
    this.editEmployeeFamilyInfo1('Chỉnh sửa');
  }

  // Hàm edit 1
  editEmployeeFamilyInfo1(actionHeaderText) {
    // let tempData = this.itemSelected;
    let tempData = JSON.parse(JSON.stringify(this.itemSelected));
    var dataService = new CRUDService(this.inject);
    let request = new DataRequest(
      this.eFamilyInfoFormModel?.formName,
      this.eFamilyInfoFormModel?.gridViewName,
      this.eFamilyInfoFormModel?.entityName
      // "HR_EFamilies"
    );
    request.funcID = this.eFamilyInfoFormModel?.funcID;
    dataService.service = 'HR';
    dataService.request = request;
    console.log('data Sv', dataService)
    dataService.edit(tempData).subscribe((res) => {
      let option = new SidebarModel();
      option.FormModel = this.eFamilyInfoFormModel;
      option.Width = '850px';
      let dialogAdd = this.callfunc?.openSide(
        CodxFormDynamicComponent,
        {
          formModel: option.FormModel,
          data: res,
          function: null,          
          dataService: dataService,
          isView: false,
          titleMore: actionHeaderText,
        },
        option
      );

      // dialogAdd.closed.subscribe((res) => {
      //   dataService.clear();
      //   if (res?.event) {
      //     let temp3 = res.event.update.data;
      //     this.itemSelected = temp3;
      //   }
      //   this.df.detectChanges();
        dialogAdd.closed.subscribe((res) => {
        dataService.clear();
        if (res?.event) {
          this.itemSelected = JSON.parse(JSON.stringify(res.event.update.data));
          this.df.detectChanges();
        }
      });
    });
  }

  // Xóa thân nhân
  deleteFamilyInfo(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteFamilyInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eFamilyGridViewID){
                    clearInterval(ins);
                    this.eFamilyGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

    //#region API
    
    // Hàm trả về danh sách thân nhân của nhân viên
  getEmpCurrentData(employeeID: string) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmployeesBusiness',
      'GetEmpCurrentInfoAsync',
      [employeeID]
    );
  }

  // Hoặc sửa trong file codx-hr.service => Tìm hàm DeleteEmployeeFamilyInfo => EFamiliesBusiness_Old thành EFamiliesBusiness
  DeleteFamilyInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpFamilyBusiness',
      'DeleteEmployeeFamilyInfoAsync',
      data
    );
  }
}
