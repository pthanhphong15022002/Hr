import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-bio',
  templateUrl: './hsnv-emp-bio.component.html',
  styleUrls: ['./hsnv-emp-bio.component.scss']
})
export class HsnvEmpBioComponent extends UIComponent {
  @Input() infoPersonal:any;
  @Input() funID:any;
  eEmpInfoCVStoryFormModel: FormModel;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }


  onInit(): void {
    this.initEInfoCVStory();
  }

  initEInfoCVStory() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpInfoCVStoryFormModel = res;
    }); 
  }
}
