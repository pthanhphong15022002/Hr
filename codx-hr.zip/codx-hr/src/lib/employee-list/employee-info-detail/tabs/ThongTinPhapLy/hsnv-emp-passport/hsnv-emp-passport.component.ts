import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { AuthStore, FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-passport',
  templateUrl: './hsnv-emp-passport.component.html',
  styleUrls: ['./hsnv-emp-passport.component.scss']
})
export class HsnvEmpPassportComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID:any;
  ePassport!: any[];

  @ViewChild('templatePassportCol1', { static: true })
  templatePassportCol1: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol2', { static: true })
  templatePassportCol2: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol3', { static: true })
  templatePassportCol3: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol4', { static: true })
  templatePassportCol4: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol5', { static: true })
  templatePassportCol5: TemplateRef<any> | undefined;
  @ViewChild('templatePassportCol6', { static: true })
  templatePassportCol6: TemplateRef<any> | undefined;


  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  user:any
  empPassportFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private auth:AuthStore
  ){
    super(inject);
    this.user = this.auth.get()
  }
  override onInit(): void {
    this.initEmpPassport();
    this.initEPassport()
  }

  initEPassport() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.empPassportFormModel = res;
    }); 
  }

  initEmpPassport() {
    if (!this.ePassport) {
      this.ePassport = [
        {
          headerText: 'Số hộ chiếu',
          template: this.templatePassportCol1,
          width: '15%',
        },
        {
          headerText: 'Quốc gia đến',
          template: this.templatePassportCol2,
          width: '15%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templatePassportCol3,
          width: '15%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templatePassportCol4,
          width: '15%',
        },
        {
          headerText: 'Số ngày',
          template: this.templatePassportCol5,
          width: '15%',
        },
        {
          headerText: 'Ghi chú',
          template: this.templatePassportCol6,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        },
      ];
    }
  }


  

  

}
