import { debug } from 'util';
import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-contract',
  templateUrl: './hsnv-emp-contract.component.html',
  styleUrls: ['./hsnv-emp-contract.component.scss']
})
export class HsnvEmpContractComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eContractWorkColumnGrid!: any[];
  
  @ViewChild('eContractGridViewID') eContractGridViewID: CodxGridviewV2Component ;

  //Header
  @ViewChild('templateContractHeaderGridCol1', { static: true })
  templateContractHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateContractHeaderGridCol2', { static: true })
  templateContractHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateContractHeaderGridCol3', { static: true })
  templateContractHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateContractHeaderGridCol4', { static: true })
  templateContractHeaderGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateContractHeaderGridCol5', { static: true })
  templateContractHeaderGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateContractWorkGridCol1', { static: true })
  templateContractWorkGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateContractWorkGridCol2', { static: true })
  templateContractWorkGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateContractWorkGridCol3', { static: true })
  templateContractWorkGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateContractWorkGridCol4', { static: true })
  templateContractWorkGridCol4: TemplateRef<any> | undefined;
  @ViewChild('templateContractWorkGridCol5', { static: true })
  templateContractWorkGridCol5: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eContractWorkFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpContractWork();
    this.initEContractWork();
  }
  
  initEContractWork() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eContractWorkFormModel = res;
    }); 
  }
  
  initEmpContractWork() {
    if (!this.eContractWorkColumnGrid) {
      this.eContractWorkColumnGrid = [
        {
          headerTemplate: this.templateContractHeaderGridCol1,
          template: this.templateContractWorkGridCol1,
          width: '15%',
        },
        {
          headerTemplate: this.templateContractHeaderGridCol2,
          template: this.templateContractWorkGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateContractHeaderGridCol3,
          template: this.templateContractWorkGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateContractHeaderGridCol4,
          template: this.templateContractWorkGridCol4,
          width: '20%',
        },
        {
          headerTemplate: this.templateContractHeaderGridCol5,
          template: this.templateContractWorkGridCol5,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  deleteContract(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteContractInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eContractGridViewID){
                    clearInterval(ins);
                    this.eContractGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  //#region API
  DeleteContractInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpContractBusiness',
      'DeleteContractInfoAsync',
      data
    );
  }
}
