import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-visa',
  templateUrl: './hsnv-emp-visa.component.html',
  styleUrls: ['./hsnv-emp-visa.component.scss']
})
export class HsnvEmpVisaComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eVisaColumnGrid!: any[];

  @ViewChild('eVisaGridViewID') eVisaGridViewID: CodxGridviewV2Component;

  // Header
  @ViewChild('templateEVisaHeaderGridCol1', { static: true })
  templateEVisaHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEVisaHeaderGridCol2', { static: true })
  templateEVisaHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEVisaHeaderGridCol3', { static: true })
  templateEVisaHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEVisaHeaderGridCol4', { static: true })
  templateEVisaHeaderGridCol4: TemplateRef<any> | undefined;

  // Row
  @ViewChild('templateEVisaGridCol1', { static: true })
  templateEVisaGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEVisaGridCol2', { static: true })
  templateEVisaGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEVisaGridCol3', { static: true })
  templateEVisaGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEVisaGridCol4', { static: true })
  templateEVisaGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eVisaFormModel: FormModel = null;
  
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpVisa();
    this.initEVisa();
  }

  initEmpVisa() {
    if (!this.eVisaColumnGrid) {
      this.eVisaColumnGrid = [
        {
          headerTemplate: this.templateEVisaHeaderGridCol1,
          template: this.templateEVisaGridCol1,
          width: '20%',
        },
        {
          headerTemplate: this.templateEVisaHeaderGridCol2,
          template: this.templateEVisaGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateEVisaHeaderGridCol3,
          template: this.templateEVisaGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateEVisaHeaderGridCol4,
          template: this.templateEVisaGridCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  initEVisa() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eVisaFormModel = res;
    }); 
  }

  DeleteVisa(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteVisaInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eVisaGridViewID){
                    console.log('refresh grid')
                    clearInterval(ins);
                    this.eVisaGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }
  
  // #region API
  DeleteVisaInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpFamilyBusiness',
      'DeleteVisaInfoAsync',
      data
    );
  }
}
