import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { AuthStore, FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-driver-licence',
  templateUrl: './hsnv-driver-licence.component.html',
  styleUrls: ['./hsnv-driver-licence.component.scss']
})
export class HsnvDriverLicenceComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID: any;
  eDrivingLicense!: any[];
  @ViewChild('templateDrivingLicenseCol1', { static: true })
  templateDrivingLicenseCol1: TemplateRef<any> | undefined;
  @ViewChild('templateDrivingLicenseCol2', { static: true })
  templateDrivingLicenseCol2: TemplateRef<any> | undefined;
  @ViewChild('templateDrivingLicenseCol3', { static: true })
  templateDrivingLicenseCol3: TemplateRef<any> | undefined;

  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  user:any;
  eEmpDrivingLicenseFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private auth:AuthStore
  ){
    super(inject);
    this.user = this.auth.get()
  }
  override onInit(): void {
    this.initEmpDrivingLicense();
    this.initEDrivingLicense();
  }

  initEDrivingLicense() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpDrivingLicenseFormModel = res;
    }); 
  }

  initEmpDrivingLicense() {
    if (!this.eDrivingLicense) {
      this.eDrivingLicense = [
        {
          headerText: 'Ngày mượn',
          template: this.templateDrivingLicenseCol1,
          width: '25%',
        },
        {
          headerText: 'Ngày trả ',
          template: this.templateDrivingLicenseCol2,
          width: '25%',
        },
        {
          headerText: 'Ghi chú',
          template: this.templateDrivingLicenseCol3,
          width: '25%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '25%',
        },
      ];
    }
  }


}
