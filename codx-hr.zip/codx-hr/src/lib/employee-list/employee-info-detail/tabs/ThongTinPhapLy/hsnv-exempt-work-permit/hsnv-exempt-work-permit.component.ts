import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-exempt-work-permit',
  templateUrl: './hsnv-exempt-work-permit.component.html',
  styleUrls: ['./hsnv-exempt-work-permit.component.scss']
})
export class HsnvExemptWorkPermitComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID:any;
  eEmpWorkPermitExemptFormModel: FormModel = null;
  
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEWorkPermitExempt();
  }


  initEWorkPermitExempt() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpWorkPermitExemptFormModel = res;
    }); 
  }

}
