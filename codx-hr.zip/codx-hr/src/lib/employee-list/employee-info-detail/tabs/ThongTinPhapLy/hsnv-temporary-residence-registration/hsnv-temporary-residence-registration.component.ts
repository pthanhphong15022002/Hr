import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-temporary-residence-registration',
  templateUrl: './hsnv-temporary-residence-registration.component.html',
  styleUrls: ['./hsnv-temporary-residence-registration.component.scss']
})
export class HsnvTemporaryResidenceRegistrationComponent  extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID: any;
  eEmpTempResidenceFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initETempResidence()
  }
  initETempResidence() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpTempResidenceFormModel = res;
    }); 
  }
}
