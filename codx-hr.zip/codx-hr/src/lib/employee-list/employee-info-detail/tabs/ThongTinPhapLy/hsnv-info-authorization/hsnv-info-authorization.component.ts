import { Component } from '@angular/core';

@Component({
  selector: 'hsnv-info-authorization',
  templateUrl: './hsnv-info-authorization.component.html',
  styleUrls: ['./hsnv-info-authorization.component.scss']
})
export class HsnvInfoAuthorizationComponent {

}
