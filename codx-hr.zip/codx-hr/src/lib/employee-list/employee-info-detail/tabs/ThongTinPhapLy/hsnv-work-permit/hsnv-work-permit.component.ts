import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-work-permit',
  templateUrl: './hsnv-work-permit.component.html',
  styleUrls: ['./hsnv-work-permit.component.scss']
})
export class HsnvWorkPermitComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() infoPersonal:any;
  @Input() funID: any;
  eEmpWorkPermitFormModel: FormModel;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEWorkPermit();
  }

  initEWorkPermit() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpWorkPermitFormModel = res;
    }); 
  }
}
