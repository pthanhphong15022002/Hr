import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-labor-si-book',
  templateUrl: './hsnv-labor-si-book.component.html',
  styleUrls: ['./hsnv-labor-si-book.component.scss']
})
export class HsnvLaborSiBookComponent extends UIComponent  {
  @Input() infoPersonal:any;
  @Input() funID:any;
  eEmpInfoLawInfoFormModel: FormModel = null;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  onInit() {
    this.initEInfoLawInfo();
  }


  initEInfoLawInfo() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eEmpInfoLawInfoFormModel = res;
    }); 
  }

}
