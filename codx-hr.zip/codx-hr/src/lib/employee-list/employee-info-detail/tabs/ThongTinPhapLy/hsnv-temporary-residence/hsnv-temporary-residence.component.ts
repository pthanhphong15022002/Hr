import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-temporary-residence',
  templateUrl: './hsnv-temporary-residence.component.html',
  styleUrls: ['./hsnv-temporary-residence.component.scss']
})
export class HsnvTemporaryResidenceComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID:any;
  eCardColumnGrid!: any[];

  @ViewChild('eTemporaryResidenceGridViewID') eTemporaryResidenceGridViewID: CodxGridviewV2Component;

  //Header
  @ViewChild('templateECardHeaderGridCol1', { static: true })
  templateECardHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateECardHeaderGridCol2', { static: true })
  templateECardHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateECardHeaderGridCol3', { static: true })
  templateECardHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateECardHeaderGridCol4', { static: true })
  templateECardHeaderGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateECardGridCol1', { static: true })
  templateECardGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateECardGridCol2', { static: true })
  templateECardGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateECardGridCol3', { static: true })
  templateECardGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateECardGridCol4', { static: true })
  templateECardGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eTempCardFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpCard();
    this.initETempCard()
  }

  initETempCard() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.eTempCardFormModel = res;
    }); 
  }


  initEmpCard() {
    if (!this.eCardColumnGrid) {
      this.eCardColumnGrid = [
        {
          headerTemplate: this.templateECardHeaderGridCol1,
          template: this.templateECardGridCol1,
          width: '20%',
        },
        {
          headerTemplate: this.templateECardHeaderGridCol2,
          template: this.templateECardGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateECardHeaderGridCol3,
          template: this.templateECardGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateECardHeaderGridCol4,
          template: this.templateECardGridCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  deleteTemporaryResidence(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeleteTemporaryResidenceInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.eTemporaryResidenceGridViewID){
                    console.log('refresh grid')
                    clearInterval(ins);
                    this.eTemporaryResidenceGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }

  // #region API
  DeleteTemporaryResidenceInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpTempResidenceCardBusiness',
      'DeleteTemporaryResidenceInfoAsync',
      data
    );
  }
}
