import { ChangeDetectorRef, Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CallFuncService, CodxGridviewV2Component, FormModel, NotificationsService, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-personal-account',
  templateUrl: './hsnv-personal-account.component.html',
  styleUrls: ['./hsnv-personal-account.component.scss']
})
export class HsnvPersonalAccountComponent extends UIComponent {
  @Input() employeeID:any;
  @Input() funID: any;
  eAccountColumnGrid!: any[];

  @ViewChild('ePersonalAccountGridViewID') ePersonalAccountGridViewID: CodxGridviewV2Component ;

  // Header
  @ViewChild('templateEAccountHeaderGridCol1', { static: true })
  templateEAccountHeaderGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEAccountHeaderGridCol2', { static: true })
  templateEAccountHeaderGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEAccountHeaderGridCol3', { static: true })
  templateEAccountHeaderGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEAccountHeaderGridCol4', { static: true })
  templateEAccountHeaderGridCol4: TemplateRef<any> | undefined;

  @ViewChild('templateEAccountGridCol1', { static: true })
  templateEAccountGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEAccountGridCol2', { static: true })
  templateEAccountGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEAccountGridCol3', { static: true })
  templateEAccountGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEAccountGridCol4', { static: true })
  templateEAccountGridCol4: TemplateRef<any> | undefined;


  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  ePersonalAccountFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
    private activedRoute: ActivatedRoute,
    private notifiSV: NotificationsService,
    private df: ChangeDetectorRef,
    private callfunc: CallFuncService
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpAccount();
    this.initEmpPersonalAccount()
  }

  initEmpPersonalAccount() {
    this.hrService.getFormModel(this.funID).then((res) => {
      this.ePersonalAccountFormModel = res;
    }); 
  }


  initEmpAccount() {
    if (!this.eAccountColumnGrid) {
      this.eAccountColumnGrid = [
        {
          headerTemplate: this.templateEAccountHeaderGridCol1,
          template: this.templateEAccountGridCol1,
          width: '10%',
        },
        {
          headerTemplate: this.templateEAccountHeaderGridCol2,
          template: this.templateEAccountGridCol2,
          width: '20%',
        },
        {
          headerTemplate: this.templateEAccountHeaderGridCol3,
          template: this.templateEAccountGridCol3,
          width: '20%',
        },
        {
          headerTemplate: this.templateEAccountHeaderGridCol4,
          template: this.templateEAccountGridCol4,
          width: '40%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
  };

  deletePersonalAccount(data: any) {
    if (data) {
      this.notifiSV.alertCode('SYS030').subscribe((res) => {
        if (res.event.status == 'Y') {
          this
            .DeletePersonalAccountInfo(data)
            .subscribe((res: any) => {
              if (res) {
                this.notifiSV.notifyCode('SYS008');
                let ins = setInterval(() => {
                  if(this.ePersonalAccountGridViewID){
                    console.log('refresh grid')
                    clearInterval(ins);
                    this.ePersonalAccountGridViewID.refresh();
                  }
              }, 1);
            }
            else {
              this.notifiSV.notifyCode('SYS022');
            }
          });
        }
      });
    }
  }
  //#region API
  DeletePersonalAccountInfo(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmpBankBusiness',
      'DeletePersonalAccountInfoAsync',
      data
    );
  }
}
