import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-reward',
  templateUrl: './hsnv-emp-reward.component.html',
  styleUrls: ['./hsnv-emp-reward.component.scss']
})
export class HsnvEmpRewardComponent  extends UIComponent {
  @Input() employeeID:any;
  //Khen thưởng
  eAwardColumnGrid!: any[];

  @ViewChild('templateEAwardGridCol1', { static: true })
  templateEAwardGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEAwardGridCol2', { static: true })
  templateEAwardGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEAwardGridCol3', { static: true })
  templateEAwardGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEAwardGridCol4', { static: true })
  templateEAwardGridCol4: TemplateRef<any> | undefined;
  // Button Edit, Delete
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eAwardFormModel: FormModel = null;
  
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpAward();
    this.initEAward();
  }

// Khen thưởng
initEAward() {
  this.hrService.getFormModel('HREM10602').then((res) => {
    this.eAwardFormModel = res;
  });
}

  initEmpAward() {
    if (!this.eAwardColumnGrid) {
      this.eAwardColumnGrid = [
        {
          // headerText: this.eAwardHeaderTexts['DecisionNo'],
          headerText: 'Số quyết định',
          template: this.templateEAwardGridCol1,
          width: '15%',
        },
        {
          // headerText: this.eAwardHeaderTexts['AwardDate'],
          headerText: 'Hình thức khen thưởng',
          template: this.templateEAwardGridCol2,
          width: '25%',
        },
        {
          // headerText: this.eAwardHeaderTexts['AwardCode'],
          headerText: 'Lý do khen thưởng',
          template: this.templateEAwardGridCol3,
          width: '30%',
        },
        {
          // headerText: this.eAwardHeaderTexts['Amount'],
          headerText: 'Ngày khen thưởng',
          template: this.templateEAwardGridCol4,
          width: '20%',
        },
        {
          // headerText: this.eAwardHeaderTexts['Amount'],
          headerText: '',
          template: this.templateButtonGridCol,
          width: '10%',
        }
      ];
    }
    // this.df.detectChanges();
  };
  
}
