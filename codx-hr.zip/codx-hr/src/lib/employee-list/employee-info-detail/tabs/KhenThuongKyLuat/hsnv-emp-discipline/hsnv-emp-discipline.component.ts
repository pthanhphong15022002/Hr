import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-discipline',
  templateUrl: './hsnv-emp-discipline.component.html',
  styleUrls: ['./hsnv-emp-discipline.component.scss']
})
export class HsnvEmpDisciplineComponent extends UIComponent {
  @Input() employeeID:any;
  //Kỷ luật
  eDisciplinaryColumnGrid!: any[];
  
  @ViewChild('templateEDisciplinaryCol1', { static: true })
  templateEDisciplinaryCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEDisciplinaryCol2', { static: true })
  templateEDisciplinaryCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEDisciplinaryCol3', { static: true })
  templateEDisciplinaryCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEDisciplinaryCol4', { static: true })
  templateEDisciplinaryCol4: TemplateRef<any> | undefined;
  // Button Edit, Delete
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;
  eDisciplineFormModel: FormModel = null;


  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpDisciplinary();
    this.initEDiscipline()
  }

// Kỷ luật
  initEDiscipline() {
    this.hrService.getFormModel('HREM10603').then((res) => {
      this.eDisciplineFormModel = res;
    });
  }
  initEmpDisciplinary() {
    if (!this.eDisciplinaryColumnGrid) {
      this.eDisciplinaryColumnGrid = [
        {
          headerText: 'Số quyết định',
          template: this.templateEDisciplinaryCol1,
          width: '20%',
        },
        {
          headerText: 'Hình thức kỷ luật',
          template: this.templateEDisciplinaryCol2,
          width: '20%',
        },
        {
          headerText: 'Hình thức xử lý',
          template: this.templateEDisciplinaryCol3,
          width: '20%',
        },
        {
          headerText: 'Ngày quyết định',
          template: this.templateEDisciplinaryCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
    // this.df.detectChanges();
  };


}
