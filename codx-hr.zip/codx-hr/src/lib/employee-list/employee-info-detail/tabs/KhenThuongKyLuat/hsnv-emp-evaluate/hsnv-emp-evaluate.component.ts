import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-evaluate',
  templateUrl: './hsnv-emp-evaluate.component.html',
  styleUrls: ['./hsnv-emp-evaluate.component.scss']
})
export class HsnvEmpEvaluateComponent extends UIComponent {
  @Input() employeeID:any;
 //Đánh giá
 eEvaluateColumnGrid!: any[];

 // Header Text
 @ViewChild('templateEvaluateHeaderGridCol1', { static: true })
 templateEvaluateHeaderGridCol1: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateHeaderGridCol2', { static: true })
 templateEvaluateHeaderGridCol2: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateHeaderGridCol3', { static: true })
 templateEvaluateHeaderGridCol3: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateHeaderGridCol4', { static: true })
 templateEvaluateHeaderGridCol4: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateHeaderGridCol5', { static: true })
 templateEvaluateHeaderGridCol5: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateHeaderGridCol6', { static: true })
 templateEvaluateHeaderGridCol6: TemplateRef<any> | undefined;

 // Content
 @ViewChild('templateEvaluateGridCol1', { static: true })
 templateEvaluateGridCol1: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateGridCol2', { static: true })
 templateEvaluateGridCol2: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateGridCol3', { static: true })
 templateEvaluateGridCol3: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateGridCol4', { static: true })
 templateEvaluateGridCol4: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateGridCol5', { static: true })
 templateEvaluateGridCol5: TemplateRef<any> | undefined;
 @ViewChild('templateEvaluateGridCol6', { static: true })
 templateEvaluateGridCol6: TemplateRef<any> | undefined;

// Button Edit, Delete
@ViewChild('templateButtonGridCol', { static: true })
templateButtonGridCol: TemplateRef<any> | undefined;
// Đánh giá
eEvaluateFormModel: FormModel = null;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  override onInit(): void {
    this.initEmpEvaluate();
    this.initEEvaluate();
  }
  

  initEEvaluate() {
    this.hrService.getFormModel('HREM10601').then((res) => {
      this.eEvaluateFormModel = res;
      console.log('form danh gia', this.eEvaluateFormModel)
    });
  }

  initEmpEvaluate() {
    if (!this.eEvaluateColumnGrid) {
      this.eEvaluateColumnGrid = [
        {
          headerTemplate: this.templateEvaluateHeaderGridCol1,
          template: this.templateEvaluateGridCol1,
          width: '15%',
        },
        {
          headerTemplate: this.templateEvaluateHeaderGridCol2,
          template: this.templateEvaluateGridCol2,
          width: '15%',
        },
        {
          headerTemplate: this.templateEvaluateHeaderGridCol3,
          template: this.templateEvaluateGridCol3,
          width: '10%',
        },
        {
          headerTemplate: this.templateEvaluateHeaderGridCol4,
          template: this.templateEvaluateGridCol4,
          width: '30%',
        },
        {
          headerTemplate: this.templateEvaluateHeaderGridCol5,
          template: this.templateEvaluateGridCol5,
          width: '10%',
        },
        {
          headerTemplate: this.templateEvaluateHeaderGridCol6,
          template: this.templateEvaluateGridCol6,
          width: '15%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '5%',
        }
      ];
    }
  };

}
