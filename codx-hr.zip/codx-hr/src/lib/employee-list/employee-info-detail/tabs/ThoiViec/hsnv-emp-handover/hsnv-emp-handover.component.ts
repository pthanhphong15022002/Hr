import { Component, Injector, Input, TemplateRef, ViewChild } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-handover',
  templateUrl: './hsnv-emp-handover.component.html',
  styleUrls: ['./hsnv-emp-handover.component.scss']
})
export class HsnvEmpHandoverComponent extends UIComponent {
  
  @Input() employeeID:string;
  
  @ViewChild('templateQuitCol1', { static: true })
  templateQuitCol1: TemplateRef<any> | undefined;
  @ViewChild('templateQuitCol2', { static: true })
  templateQuitCol2: TemplateRef<any> | undefined;
  @ViewChild('templateQuitCol3', { static: true })
  templateQuitCol3: TemplateRef<any> | undefined;
  @ViewChild('templateQuitCol4', { static: true })
  templateQuitCol4: TemplateRef<any> | undefined;

  // Button Edit, Delete
  @ViewChild('templateEditGridCol', { static: true })
  templateEditGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateDeleteGridCol', { static: true })
  templateDeleteGridCol: TemplateRef<any> | undefined;
  @ViewChild('templateButtonGridCol', { static: true })
  templateButtonGridCol: TemplateRef<any> | undefined;

  eEmployeeColumnGrid!: any[];
  eCompanyColumnGrid!: any[];
  eTaskOffFormModel: FormModel;

  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }

  override onInit(): void {
    this.initETaskOff();
    this.initEmpCompany();
    this.initEmpEmployee();
  }

 // Chi tiết bàn giao
 initETaskOff() {
   this.hrService.getFormModel('HREM10802').then((res) => {
     this.eTaskOffFormModel = res;
   });
 }


  initEmpEmployee() {
    if (!this.eEmployeeColumnGrid) {
      this.eEmployeeColumnGrid = [
        {
          headerText: 'Tác vụ',
          template: this.templateQuitCol1,
          width: '20%',
        },
        {
          headerText: 'Người thực hiện',
          template: this.templateQuitCol2,
          width: '20%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templateQuitCol3,
          width: '20%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templateQuitCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };

  initEmpCompany() {
    if (!this.eCompanyColumnGrid) {
      this.eCompanyColumnGrid = [
        {
          headerText: 'Tác vụ',
          template: this.templateQuitCol1,
          width: '20%',
        },
        {
          headerText: 'Người thực hiện',
          template: this.templateQuitCol2,
          width: '20%',
        },
        {
          headerText: 'Từ ngày',
          template: this.templateQuitCol3,
          width: '20%',
        },
        {
          headerText: 'Đến ngày',
          template: this.templateQuitCol4,
          width: '20%',
        },
        {
          headerText: '',
          template: this.templateButtonGridCol,
          width: '20%',
        }
      ];
    }
  };
}
