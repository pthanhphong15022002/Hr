import { Component, Injector, Input } from '@angular/core';
import { UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-quit-aproval-process',
  templateUrl: './hsnv-quit-aproval-process.component.html',
  styleUrls: ['./hsnv-quit-aproval-process.component.scss']
})
export class HsnvQuitAprovalProcessComponent extends UIComponent  {
  @Input() infoPersonal:any
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  onInit() {

  }


}

