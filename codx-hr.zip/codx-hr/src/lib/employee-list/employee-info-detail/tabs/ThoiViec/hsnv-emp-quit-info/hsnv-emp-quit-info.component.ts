import { Component, Injector, Input } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';

@Component({
  selector: 'hsnv-emp-quit-info',
  templateUrl: './hsnv-emp-quit-info.component.html',
  styleUrls: ['./hsnv-emp-quit-info.component.scss']
})
export class HsnvEmpQuitInfoComponent extends UIComponent  {
  @Input() infoPersonal:any
  eInfoQuitInfoFormModel: FormModel = null;
  constructor(
    private inject: Injector,
    private hrService: CodxHrService,
  ){
    super(inject);
  }
  onInit() {
    this.initEInfoQuitInfo();
  }

  initEInfoQuitInfo() {
    this.hrService.getFormModel('HREM10801').then((res) => {
      this.eInfoQuitInfoFormModel = res;
    }); 
  }


}
