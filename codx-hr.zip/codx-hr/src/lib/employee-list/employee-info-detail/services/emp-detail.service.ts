import { Injectable } from "@angular/core";
import { ApiHttpService } from "codx-core";

@Injectable({
    providedIn: 'root',
})
export class EmpDetailService {

    constructor(private api: ApiHttpService){}  
    getEmpCurrentData(empID) {
        return this.api.execSv<any>(
          'HR',
          'HR',
          'EmployeesBusiness_Old',
          'GetEmpCurrentInfoAsync',
          empID
        );
    }

    loadEmpFullInfo(empID) {
      return this.api.execSv<any>(
        'HR',
        'HR',
        'EmployeesBusiness_Old',
        'GetEmpFullInfoAsync',
        empID,
      );
    }
}