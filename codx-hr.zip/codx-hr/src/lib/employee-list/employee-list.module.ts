import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HRLayoutOnlyHeaderComponent } from '../_layout_onlyHeader/_layout_onlyHeader.component';
import { EmployeeInfoProfileComponent } from './employee-info-profile/employee-info-profile.component';
import { DialogReviewLeaveApproveComponent } from './employee-info-profile/components/pop-up/dialog-review-leave-approve/dialog-review-leave-approve.component';
import { DialogWaitingLeavingApproveComponent } from './employee-info-profile/components/pop-up/dialog-waiting-leaving-approve/dialog-waiting-leaving-approve.component';
import { MenuSidebarComponent } from './employee-info-profile/components/pop-up/menu-sidebar/menu-sidebar.component';
import { DialogDetailRegisterApproveComponent } from '../dashboard/components/dialog-detail-register-approve/dialog-detail-register-approve.component';
import { CoreModule } from '@core/core.module';
import { FormsModule } from '@angular/forms';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PopupMyteamReponsiveComponent } from './employee-info-profile/components/pop-up/popup-myteam-reponsive/popup-myteam-reponsive.component';
import { MyTemComponent } from '../dashboard/widgets/my-team/my-tem.component';
import { EmployeeInfoDetailComponent } from './employee-info-detail/employee-info-detail.component';
import { DashboardRegisterAprroveComponent } from '../dashboard/components/dashboard-register-aprrove/dashboard-register-aprrove.component';
import { DirectivesModule } from '../codx-hr-common/directives/directives.module';
import { CodxHRCommonModule } from '../codx-hr-common/codx-hr-common.module';
import { SidebarTreeviewComponent } from './employee-info-detail/component/sidebar-treeview/sidebar-treeview.component';
import { PersonalInfoComponent } from './employee-info-detail/component/personal-info/personal-info.component';
import { SharedModule } from '@shared/shared.module';
import { ProfileLast7dayComponent } from '../dashboard/components/profile-last7day/profile-last7day.component';
import { ProfileDashboardLeaveComponent } from '../dashboard/components/profile-dashboard-leave/profile-dashboard-leave.component';
import { AgeStatisticComponent } from '../dashboard/widgets/age-statistic/age-statistic.component';
import { PopupMenusidebarReponsiveComponent } from './employee-info-profile/components/pop-up/popup-menusidebar-reponsive/popup-menusidebar-reponsive.component';
import { PopupReviewRegisterApproveComponent } from './employee-info-profile/components/pop-up/popup-review-register-approve/popup-review-register-approve.component';
import { TabModule } from '@syncfusion/ej2-angular-navigations';
import { ListTabComponent } from './employee-info-detail/component/list-tab/list-tab.component';
import { ListDetailTabComponent } from './employee-info-detail/component/list-tab/list-detail-tab/list-detail-tab.component';
import { ClickOutsideDirective } from './employee-info-detail/component/list-tab/click-outside.directive';
import { LayoutComponent } from 'projects/codx-hr/src/lib/_layout/layout.component';
import { EmployeeListComponent } from './employee-list.component';
import { TranformValueNumberPipe } from 'projects/codx-ac/src/lib/pipes/tranform-value-number.pipe';
import { PassportComponent } from './employee-info-detail/component/passport/passport.component';
//import { CompensatoryLeaveComponent } from './employee-info-detail/component/compensatory-leave/compensatory-leave.component';
//import { OnLeaveComponent } from './employee-info-detail/component/on-leave/on-leave.component';
import { DrivingLicenseComponent } from './employee-info-detail/component/driving-license/driving-license.component';
import { OtherInsuranceComponent } from './employee-info-detail/component/other-insurance/other-insurance.component';
import { HsnvEmpInfoComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-info/hsnv-emp-info.component';
import { HsnvEmpJobComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-job/hsnv-emp-job.component';
import { HsnvEmpHiringComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-hiring/hsnv-emp-hiring.component';
import { HsnvEmpFamilyComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-family/hsnv-emp-family.component';
import { HsnvEmpUnionComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-union/hsnv-emp-union.component';
import { HsnvEmpBioComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-bio/hsnv-emp-bio.component';
import { HsnvEmpForeignComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-foreign/hsnv-emp-foreign.component';
import { HsnvEmpDocumentSubmitComponent } from './employee-info-detail/tabs/SoYeuLyLich/hsnv-emp-document-submit/hsnv-emp-document-submit.component';
import { HsnvPayrollGroupComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-payroll-group/hsnv-payroll-group.component';
import { HsnvEmpQuitInfoComponent } from './employee-info-detail/tabs/ThoiViec/hsnv-emp-quit-info/hsnv-emp-quit-info.component';
import { HsnvEmpHandoverComponent } from './employee-info-detail/tabs/ThoiViec/hsnv-emp-handover/hsnv-emp-handover.component';
import { HsnvQuitAprovalProcessComponent } from './employee-info-detail/tabs/ThoiViec/hsnv-quit-aproval-process/hsnv-quit-aproval-process.component';
import { HsnvHealthInsuranceComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-health-insurance/hsnv-health-insurance.component';
import { HsnvWorkAccidentComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-work-accident/hsnv-work-accident.component';
import { HsnvPhysicalExaminationComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-physical-examination/hsnv-physical-examination.component';
import { HsnvOccupationalDiseaseComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-occupational-disease/hsnv-occupational-disease.component';
import { HsnvVaccineScheduleComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-vaccine-schedule/hsnv-vaccine-schedule.component';
import { HsnvMemberInssuranceComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-member-inssurance/hsnv-member-inssurance.component';
import { HsnvTitleConferredComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-title-conferred/hsnv-title-conferred.component';
import { HsnvEventInsuranceComponent } from './employee-info-detail/tabs/SucKhoeHoatDong/hsnv-event-insurance/hsnv-event-insurance.component';
import { HsnvEmpEvaluateComponent } from './employee-info-detail/tabs/KhenThuongKyLuat/hsnv-emp-evaluate/hsnv-emp-evaluate.component';
import { HsnvEmpRewardComponent } from './employee-info-detail/tabs/KhenThuongKyLuat/hsnv-emp-reward/hsnv-emp-reward.component';
import { HsnvEmpDisciplineComponent } from './employee-info-detail/tabs/KhenThuongKyLuat/hsnv-emp-discipline/hsnv-emp-discipline.component';
import { HsnvEmpMajorComponent } from './employee-info-detail/tabs/KienThuc/hsnv-emp-major/hsnv-emp-major.component';
import { HsnvEmpCertificateComponent } from './employee-info-detail/tabs/KienThuc/hsnv-emp-certificate/hsnv-emp-certificate.component';
import { HsnvEmpSkillsComponent } from './employee-info-detail/tabs/KienThuc/hsnv-emp-skills/hsnv-emp-skills.component';
import { HsnvInternalTrainingComponent } from './employee-info-detail/tabs/KienThuc/hsnv-internal-training/hsnv-internal-training.component';
import { HsnvEmpResearchComponent } from './employee-info-detail/tabs/KienThuc/hsnv-emp-research/hsnv-emp-research.component';
import { HSNVCompensatoryLeaveComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-compensatory-leave/hsnv-compensatory-leave.component';
import { HSNVOnLeaveComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-on-leave/hsnv-on-leave.component';
import { HsnvAppointComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-appoint/hsnv-appoint.component';
import { HsnvWorkDiaryComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-work-diary/hsnv-work-diary.component';
import { HsnvEmpProjectComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-emp-project/hsnv-emp-project.component';
import { HsnvWorkPerformedComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-work-performed/hsnv-work-performed.component';
import { HsnvPreviousExperienceComponent } from './employee-info-detail/tabs/QuaTrinhLamViec/hsnv-previous-experience/hsnv-previous-experience.component';
import { HsnvBasicBenefitComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-basic-benefit/hsnv-basic-benefit.component';
import { HsnvSalaryJobPositionComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-salary-job-position/hsnv-salary-job-position.component';
import { HsnvEmpAllowanceComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-emp-allowance/hsnv-emp-allowance.component';
import { HsnvOtherIncomeComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-other-income/hsnv-other-income.component';
import { HsnvCompulsoryInsuranceComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-compulsory-insurance/hsnv-compulsory-insurance.component';
import { HsnvDeductionsComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-deductions/hsnv-deductions.component';
import { HsnvAllocatedAssetsComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-allocated-assets/hsnv-allocated-assets.component';
import { HsnvEmpLoanComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-emp-loan/hsnv-emp-loan.component';
import { HsnvOtherInsuranceComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-other-insurance/hsnv-other-insurance.component';
import { HsnvCostCenterComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-cost-center/hsnv-cost-center.component';
import { HsnvDriverAccountComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-driver-account/hsnv-driver-account.component';
import { HsnvAuthorizationLetterComponent } from './employee-info-detail/tabs/Luong&PhucLoi/hsnv-authorization-letter/hsnv-authorization-letter.component';
import { HsnvLaborSiBookComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-labor-si-book/hsnv-labor-si-book.component';
import { HsnvPersonalAccountComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-personal-account/hsnv-personal-account.component';
import { HsnvEmpContractComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-emp-contract/hsnv-emp-contract.component';
import { HsnvEmpPassportComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-emp-passport/hsnv-emp-passport.component';
import { HsnvEmpVisaComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-emp-visa/hsnv-emp-visa.component';
import { HsnvWorkPermitComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-work-permit/hsnv-work-permit.component';
import { HsnvExemptWorkPermitComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-exempt-work-permit/hsnv-exempt-work-permit.component';
import { HsnvTemporaryResidenceComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-temporary-residence/hsnv-temporary-residence.component';
import { HsnvTemporaryResidenceRegistrationComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-temporary-residence-registration/hsnv-temporary-residence-registration.component';
import { HsnvDriverLicenceComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-driver-licence/hsnv-driver-licence.component';
import { HsnvInfoAuthorizationComponent } from './employee-info-detail/tabs/ThongTinPhapLy/hsnv-info-authorization/hsnv-info-authorization.component';

export const routes: Routes = [
  {
    path:'',
    component: HRLayoutOnlyHeaderComponent,
    children:[
      {
        path: 'employeeprofile/:funcID',
        component: EmployeeInfoProfileComponent
      },
      {
        path: 'employeedetail/:funcID',
        component: EmployeeInfoDetailComponent,
      },
    ]
  },
  {
    path: '',
    component: LayoutComponent,
    children: [
      {
        path: 'emplist/:funcID',
        data: { noReuse: true },
        component: EmployeeListComponent,
      }
    ]
  }

];

const T_TabHSNV = [
  HsnvEmpInfoComponent,
  HsnvEmpJobComponent,
  HsnvEmpHiringComponent,
  HsnvEmpFamilyComponent,
  HsnvEmpUnionComponent,
  HsnvEmpBioComponent,
  HsnvEmpForeignComponent,
  HsnvEmpDocumentSubmitComponent,
  HsnvPayrollGroupComponent,
  HsnvEmpQuitInfoComponent,
  HsnvEmpHandoverComponent,
  HsnvQuitAprovalProcessComponent,
  HsnvHealthInsuranceComponent,
  HsnvWorkAccidentComponent,
  HsnvPhysicalExaminationComponent,
  HsnvOccupationalDiseaseComponent,
  HsnvVaccineScheduleComponent,
  HsnvMemberInssuranceComponent,
  HsnvTitleConferredComponent,
  HsnvEventInsuranceComponent,
  HsnvEmpEvaluateComponent,
  HsnvEmpRewardComponent, 
  HsnvEmpDisciplineComponent,
  HSNVCompensatoryLeaveComponent,
  HSNVOnLeaveComponent,
  HsnvEmpMajorComponent,
  HsnvEmpCertificateComponent,
  HsnvEmpSkillsComponent,
  HsnvInternalTrainingComponent,
  HsnvEmpResearchComponent,
  HsnvAppointComponent,
  HsnvWorkDiaryComponent,
  HsnvEmpProjectComponent,
  HsnvWorkPerformedComponent,
  HsnvPreviousExperienceComponent
]

const T_Component = [
  DialogReviewLeaveApproveComponent,
  DialogWaitingLeavingApproveComponent,
  MenuSidebarComponent,
  PopupMyteamReponsiveComponent,
  EmployeeInfoProfileComponent,
  EmployeeInfoDetailComponent,
  DashboardRegisterAprroveComponent,
  SidebarTreeviewComponent,
  PersonalInfoComponent,
  PopupMenusidebarReponsiveComponent,
  ProfileLast7dayComponent,
  ProfileDashboardLeaveComponent,
  MyTemComponent,
  AgeStatisticComponent,
  PopupReviewRegisterApproveComponent,
  ListTabComponent,
  ListDetailTabComponent,
  PassportComponent,
  DrivingLicenseComponent, 
  OtherInsuranceComponent,
  //HSNV
]


@NgModule({
  declarations: [T_TabHSNV,T_Component, HsnvBasicBenefitComponent, HsnvSalaryJobPositionComponent, HsnvEmpAllowanceComponent, HsnvOtherIncomeComponent, HsnvCompulsoryInsuranceComponent, HsnvDeductionsComponent, HsnvAllocatedAssetsComponent, HsnvEmpLoanComponent, HsnvOtherInsuranceComponent, HsnvCostCenterComponent, HsnvDriverAccountComponent, HsnvAuthorizationLetterComponent, HsnvLaborSiBookComponent, HsnvPersonalAccountComponent, HsnvEmpContractComponent, HsnvEmpPassportComponent, HsnvEmpVisaComponent, HsnvWorkPermitComponent, HsnvExemptWorkPermitComponent, HsnvTemporaryResidenceComponent, HsnvTemporaryResidenceRegistrationComponent, HsnvDriverLicenceComponent, HsnvInfoAuthorizationComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    CoreModule,
    NgbModule,
    FormsModule,
    SharedModule,
    OverlayModule,
    HttpClientModule,
    DirectivesModule,
    DialogDetailRegisterApproveComponent,
    CodxHRCommonModule,
    TabModule,
    ClickOutsideDirective,
    TranformValueNumberPipe
    
  ]
})
export class EmployeeListModule { }
