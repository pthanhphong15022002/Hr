import { Component } from '@angular/core';

@Component({
  selector: 'lib-popup-register-approve',
  templateUrl: './popup-review-register-approve.component.html',
  styleUrls: ['./popup-review-register-approve.component.css']
})
export class PopupReviewRegisterApproveComponent {

}
