import { Component } from '@angular/core';

@Component({
  selector: 'lib-menu-sidebar',
  templateUrl: './menu-sidebar.component.html',
  styleUrls: ['./menu-sidebar.component.css']
})
export class MenuSidebarComponent {

}
