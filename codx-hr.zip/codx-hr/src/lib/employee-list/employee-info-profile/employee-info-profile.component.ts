import { PopupEbenefitComponent } from './../../employee-profile/popup-ebenefit/popup-ebenefit.component';
import { PopupEdayoffsComponent } from './../../employee-profile/popup-edayoffs/popup-edayoffs.component';
import { PopupEappointionsComponent } from './../../employee-profile/popup-eappointions/popup-eappointions.component';
import { PopupEJobSalariesComponent } from './../../employee-profile/popup-ejob-salaries/popup-ejob-salaries.component';
import { PopupETraincourseComponent } from './../../employee-profile/popup-etraincourse/popup-etraincourse.component';
import { PopupESkillsComponent } from './../../employee-profile/popup-eskills/popup-eskills.component';
import { PopupEFamiliesComponent } from './../../employee-profile/popup-efamilies/popup-efamilies.component';
import { PopupEDisciplinesComponent } from './../../employee-profile/popup-edisciplines/popup-edisciplines.component';
import { PopupEDegreesComponent } from './../../employee-profile/popup-edegrees/popup-edegrees.component';
import { PopupECertificatesComponent } from './../../employee-profile/popup-ecertificates/popup-ecertificates.component';
import { PopupEAwardsComponent } from './../../employee-profile/popup-eawards/popup-eawards.component';
import { PopupEAssetsComponent } from './../../employee-profile/popup-eassets/popup-eassets.component';

import {
  Component,
  Injector,
  ChangeDetectorRef,
  TemplateRef,
  ViewChild,
  ViewEncapsulation,
  ElementRef,
  ChangeDetectionStrategy,
} from '@angular/core';
import {
  ApiHttpService,
  AuthStore,
  CallFuncService,
  CodxFormDynamicComponent,
  CodxGridviewV2Component,
  CRUDService,
  DataRequest,
  DataService,
  DialogModel,
  DialogRef,
  FormModel,
  LayoutService,
  NotificationsService,
  PageTitleService,
  SidebarModel,
  SortModel,
  UIComponent,
  Util,
  ViewModel,
  ViewType,
} from 'codx-core';
import { CodxHrService } from 'projects/codx-hr/src/public-api';
import { ActivatedRoute } from '@angular/router';
import { PopupEhealthsComponent } from '../../employee-profile/popup-ehealths/popup-ehealths.component';
import { PopupEmpBusinessTravelsComponent } from '../../employee-profile/popup-emp-business-travels/popup-emp-business-travels.component';
import { PopupSubEContractComponent } from '../../employee-profile/popup-sub-econtract/popup-sub-econtract.component';
import { PopupEProcessContractComponent } from '../../employee-contract/popup-eprocess-contract/popup-eprocess-contract.component';
//import { PopupViewAllComponent } from './pop-up/popup-view-all/popup-view-all.component';
import { FormGroup } from '@angular/forms';
import { PopupEdocumentsComponent } from '../../employee-profile/popup-edocuments/popup-edocuments.component';
import { CodxShareService } from 'projects/codx-share/src/public-api';
import { PopupEBasicSalariesComponent } from '../../employee-profile/popup-ebasic-salaries/popup-ebasic-salaries.component';
import { PopupViewAllComponent } from '../employee-info-detail/pop-up/popup-view-all/popup-view-all.component';
import { MyTeamComponent } from 'projects/codx-wp/src/lib/dashboard/home/my-team/my-team.component';
import { MyTemComponent } from '../../dashboard/widgets/my-team/my-tem.component';
import { DialogDetailRegisterApproveComponent } from '../../dashboard/components/dialog-detail-register-approve/dialog-detail-register-approve.component';
import { DialogRegisterApproveComponent } from '../../dashboard/components/dialog-register-approve/dialog-register-approve.component';
import { DialogReviewLeaveApproveComponent } from './components/pop-up/dialog-review-leave-approve/dialog-review-leave-approve.component';
import { DialogWaitingLeavingApproveComponent } from './components/pop-up/dialog-waiting-leaving-approve/dialog-waiting-leaving-approve.component';
import { PopupMyteamReponsiveComponent } from './components/pop-up/popup-myteam-reponsive/popup-myteam-reponsive.component';
import { PopupMenusidebarReponsiveComponent } from './components/pop-up/popup-menusidebar-reponsive/popup-menusidebar-reponsive.component';
import { PopupReviewRegisterApproveComponent } from './components/pop-up/popup-review-register-approve/popup-review-register-approve.component';

@Component({
  selector: 'lib-employee-info-profile',
  templateUrl: './employee-info-profile.component.html',
  styleUrls: ['./employee-info-profile.component.css'], 
  // encapsulation: ViewEncapsulation.None ,
  // changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EmployeeInfoProfileComponent extends UIComponent {
  @ViewChild('panelContent') panelContent: TemplateRef<any>;
  @ViewChild('button') button: TemplateRef<any>;
  @ViewChild('itemTemplate') template: TemplateRef<any>;
  @ViewChild('paneRight') panelRight: TemplateRef<any>;
  @ViewChild('itemAction', { static: true }) itemAction: TemplateRef<any>;



  views: Array<ViewModel> | any = [];
  minType = 'MinRange';
  user;
  isClick: boolean = false;
  dataService: DataService = null;

  active = [1, 1, 1, 1, 1, 1, 1];

  infoPersonal: any;
  myInfoPersonal: any;
  lineManager: any;
  indirectManager: any;

  crrEContract: any;
  lstContractType: any = []; //phân loại HĐ không xác định

  service = '';
  assemblyName = '';
  entity = '';
  idField = 'recID';
  functionID: string;
  lstFamily: any = [];
  lstOrg: any; //view bo phan
  lstBtnAdd: any = []; //nut add chung
  orgUnitStr: any;
  DepartmentStr: any;

  //Kinh nghiem
  lstExperiences: any;

  crrPassport: any;

  crrVisa: any;

  crrWorkpermit: any;

  crrJobSalaries: any;

  formModel;

  myEmployeeID;
  employeeID;
  employeeID2;
  //crrTab: number = 0;

  lstAsset: any;

  crrEBSalary: any;

  listCrrBenefit: any = [];

  lstEmpDocument: any = [];

  lstESkill: any;
  // IsMax = false;
  Current_Grade_ESkill: any = [];


  crrFuncTabNum = 1;


  //#region gridViewSetup
  //nhtrung do sthing here
  eAwardGrvSetup;
  eDisciplinaryGrvSetup;

  eWorkingGrvSetUp;



  eDocumentGrvSetup;
  eVaccineGrvSetup;
  eSkillgrvSetup;
  eBenefitGrvSetup;
  eAssetGrvSetup;
  eDayOffGrvSetup;
  eTrainCourseGrvSetup;
  eDiseasesGrvSetup;
  eAccidentsGrvSetup;
  //#endregion

  //#region sortModels
  dayOffSortModel: SortModel;
  disciplinesSortModel: SortModel;
  assetSortModel: SortModel;
  experienceSortModel: SortModel;
  businessTravelSortModel: SortModel;
  benefitSortModel: SortModel;
  passportSortModel: SortModel;
  workPermitSortModel: SortModel;
  visaSortModel: SortModel;
  skillIDSortModel: SortModel;
  skillGradeSortModel: SortModel;
  appointionSortModel: SortModel;
  bSalarySortModel: SortModel;
  issuedDateSortModel: SortModel;
  TrainFromDateSortModel: SortModel;
  injectDateSortModel: SortModel;
  healthDateSortModel: SortModel;
  diseasesFromDateSortModel: SortModel;
  accidentDateSortModel: SortModel;
  eContractSortModel: SortModel;
  eAwardsSortModel1: SortModel;
  eAwardsSortModel2: SortModel;
  //#endregion

  positionColumnsGrid;
  // holidayColumnsGrid;
  // workDiaryColumnGrid;
  awardColumnsGrid;
  // disciplineColumnGrid;
  eDegreeColumnsGrid;
  // eCertificateColumnGrid;
  eExperienceColumnGrid;
  eAssetColumnGrid;
  eSkillColumnGrid;
  // basicSalaryColumnGrid;
  eTrainCourseColumnGrid;
  eHealthColumnGrid;
  businessTravelColumnGrid;
  eVaccineColumnGrid;
  benefitColumnGrid;
  dayoffColumnGrid;
  appointionColumnGrid;
  jobSalaryColumnGrid;
  eContractColumnGrid;
  eDisciplineColumnsGrid;
  eDiseasesColumnsGrid;
  eAccidentsColumnsGrid;
  //#endregion

  filterByBenefitIDArr: any = [];
  filterEBenefitPredicates: string;
  startDateEBenefitFilterValue;
  endDateEBenefitFilterValue;

  // ViewAllEBenefitFlag = false;
  ViewAllEAssetFlag = false;
  // ViewAllVisaFlag = false;
  ViewAllEskillFlag = false;
  ViewAllEBasicSalaryFlag = false;
  ViewAllEJobSalaryFlag = false;
  // ViewAllEContractFlag = false;
  // ViewAllPassportFlag = false;
  ops = ['y'];

  //#region filter variables of form main eAssets
  filterByAssetCatIDArr: any = [];
  startDateEAssetFilterValue;
  endDateEAssetFilterValue;
  filterEAssetPredicates: string;

  //#endregion

  //#region filter variables of form main eDiseases
  Filter_By_EDiseases_IDArr: any = [];
  Filter_EDiseases_Predicates: string;

  //#region filter variables of form main eAccident
  filterByAccidentIDArr: any = [];
  filterAccidentIdPredicate: string;

  //#endregion

  //#region filter variables of form main eVaccine
  filterByVaccineTypeIDArr: any = [];
  startDateEVaccineFilterValue;
  endDateEVaccineFilterValue;
  filterEVaccinePredicates: string;

  //#endregion

  //#region filter variables of form main eSKill
  filterByESkillIDArr: any = [];
  startDateESkillFilterValue;
  endDateESkillFilterValue;
  filterESkillPredicates: string;

  //#endregion

  //#region filter variables of form main eTrainCourse
  Filter_By_ETrainCourse_IDArr: any = [];
  Start_Date_ETrainCourse_Filter_Value;
  End_Date_ETrainCourse_Filter_Value;
  Filter_ETrainCourse_Predicates: string;
  //#endregion

  //#region filter variables of form main eAwards
  Start_Date_Award_Filter_Value;
  End_Date_Award_Filter_Value;
  Filter_Award_Predicates;
  //#endregion

  //#region ViewChild template
  @ViewChild('healthPeriodID', { static: true })
  healthPeriodID: TemplateRef<any>;
  @ViewChild('healthPeriodDate', { static: true })
  healthPeriodDate: TemplateRef<any>;
  @ViewChild('healthPeriodPlace', { static: true })
  healthPeriodPlace: TemplateRef<any>;
  @ViewChild('healthType', { static: true }) healthType: TemplateRef<any>;
  @ViewChild('healthPeriodResult', { static: true })
  healthPeriodResult: TemplateRef<any>;
  @ViewChild('EExperience', { static: true })
  EExperienceTmp: TemplateRef<any>;
  @ViewChild('tempFromDate', { static: true }) tempFromDate;
  @ViewChild('tempToDate', { static: true }) tempToDate: TemplateRef<any>;


  //New nhtrung update here
  //Khen thưởng
  eAwardColumnGrid!: any[];

  @ViewChild('templateEAwardGridCol1', { static: true })
  templateEAwardGridCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEAwardGridCol2', { static: true })
  templateEAwardGridCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEAwardGridCol3', { static: true })
  templateEAwardGridCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEAwardGridCol4', { static: true })
  templateEAwardGridCol4: TemplateRef<any> | undefined;

  @ViewChild('headeEAwardsCol1', { static: true })
  headeEAwardsCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEAwardsCol2', { static: true })
  headeEAwardsCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEAwardsCol3', { static: true })
  headeEAwardsCol3: TemplateRef<any> | undefined;
  @ViewChild('headeEAwardsCol4', { static: true })
  headeEAwardsCol4: TemplateRef<any> | undefined;


  //Kỷ luật
  eDisciplinaryColumnGrid!: any[];

  @ViewChild('templateEDisciplinaryCol1', { static: true })
  templateEDisciplinaryCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEDisciplinaryCol2', { static: true })
  templateEDisciplinaryCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEDisciplinaryCol3', { static: true })
  templateEDisciplinaryCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEDisciplinaryCol4', { static: true })
  templateEDisciplinaryCol4: TemplateRef<any> | undefined;

  @ViewChild('headeEDisciplinaryCol1', { static: true })
  headeEDisciplinaryCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEDisciplinaryCol2', { static: true })
  headeEDisciplinaryCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEDisciplinaryCol3', { static: true })
  headeEDisciplinaryCol3: TemplateRef<any> | undefined;
  @ViewChild('headeEDisciplinaryCol4', { static: true })
  headeEDisciplinaryCol4: TemplateRef<any> | undefined;

  //Đào tạo
  eTrainColumnGrid!: any[];

  @ViewChild('templateETrainCol1', { static: true })
  templateETrainCol1: TemplateRef<any> | undefined;
  @ViewChild('templateETrainCol2', { static: true })
  templateETrainCol2: TemplateRef<any> | undefined;
  @ViewChild('templateETrainCol3', { static: true })
  templateETrainCol3: TemplateRef<any> | undefined;
  @ViewChild('templateETrainCol4', { static: true })
  templateETrainCol4: TemplateRef<any> | undefined;


  //Đánh giá
  //Chuyên nghành đào tạo
  eSpecializationColumnGrid;

  @ViewChild('templateESpecializationCol1', { static: true })
  templateESpecializationCol1: TemplateRef<any> | undefined;
  @ViewChild('templateESpecializationCol2', { static: true })
  templateESpecializationCol2: TemplateRef<any> | undefined;
  @ViewChild('templateESpecializationCol3', { static: true })
  templateESpecializationCol3: TemplateRef<any> | undefined;
  @ViewChild('templateESpecializationCol4', { static: true })
  templateESpecializationCol4: TemplateRef<any> | undefined;

  //Chứng chỉ
  eCertificateColumnGrid;

  @ViewChild('templateECertificateCol1', { static: true })
  templateECertificateCol1: TemplateRef<any> | undefined;
  @ViewChild('templateECertificateCol2', { static: true })
  templateECertificateCol2: TemplateRef<any> | undefined;
  @ViewChild('templateECertificateCol3', { static: true })
  templateECertificateCol3: TemplateRef<any> | undefined;
  @ViewChild('templateECertificateCol4', { static: true })
  templateECertificateCol4: TemplateRef<any> | undefined;


  //Đánh giá
  eEvaluationColumnGrid;

  @ViewChild('templateEEvaluationCol1', { static: true })
  templateEEvaluationCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEEvaluationCol2', { static: true })
  templateEEvaluationCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEEvaluationCol3', { static: true })
  templateEEvaluationCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEEvaluationCol4', { static: true })
  templateEEvaluationCol4: TemplateRef<any> | undefined;

  @ViewChild('headEEvaluationCol1', { static: true })
  headEEvaluationCol1: TemplateRef<any> | undefined;
  @ViewChild('headEEvaluationCol2', { static: true })
  headEEvaluationCol2: TemplateRef<any> | undefined;
  @ViewChild('headEEvaluationCol3', { static: true })
  headEEvaluationCol3: TemplateRef<any> | undefined;
  @ViewChild('headEEvaluationCol4', { static: true })
  headEEvaluationCol4: TemplateRef<any> | undefined;


  //Quá trình làm việc

  //Bổ nhiệm - điều khiển
  ePromoColumnGrid!: any[];


  @ViewChild('templateEPromoCol1', { static: true })
  templateEPromoCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEPromoCol2', { static: true })
  templateEPromoCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEPromoCol3', { static: true })
  templateEPromoCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEPromoCol4', { static: true })
  templateEPromoCol4: TemplateRef<any> | undefined;
  @ViewChild('templateEPromoCol5', { static: true })
  templateEPromoCol5: TemplateRef<any> | undefined;
  @ViewChild('templateEPromoCol6', { static: true })
  templateEPromoCol6: TemplateRef<any> | undefined;

  @ViewChild('headeEPromoCol1', { static: true })
  headeEPromoCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEPromoCol2', { static: true })
  headeEPromoCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEPromoCol3', { static: true })
  headeEPromoCol3: TemplateRef<any> | undefined;
  @ViewChild('headeEPromoCol4', { static: true })
  headeEPromoCol4: TemplateRef<any> | undefined;
  @ViewChild('headeEPromoCol5', { static: true })
  headeEPromoCol5: TemplateRef<any> | undefined;
  @ViewChild('headeEPromoCol6', { static: true })
  headeEPromoCol6: TemplateRef<any> | undefined;

  eLeaveColumnGrid!: any[];

  @ViewChild('templateELeaveCol1', { static: true })
  templateELeaveCol1: TemplateRef<any> | undefined;
  @ViewChild('templateELeaveCol2', { static: true })
  templateELeaveCol2: TemplateRef<any> | undefined;
  @ViewChild('templateELeaveCol3', { static: true })
  templateELeaveCol3: TemplateRef<any> | undefined;
  @ViewChild('templateELeaveCol4', { static: true })
  templateELeaveCol4: TemplateRef<any> | undefined;
  @ViewChild('templateELeaveCol5', { static: true })
  templateELeaveCol5: TemplateRef<any> | undefined;
  @ViewChild('templateELeaveCol6', { static: true })
  templateELeaveCol6: TemplateRef<any> | undefined;
  @ViewChild('templateELeaveCol7', { static: true })
  templateELeaveCol7: TemplateRef<any> | undefined;

  @ViewChild('headeELeaveCol1', { static: true })
  headeELeaveCol1: TemplateRef<any> | undefined;
  @ViewChild('headeELeaveCol2', { static: true })
  headeELeaveCol2: TemplateRef<any> | undefined;
  @ViewChild('headeELeaveCol3', { static: true })
  headeELeaveCol3: TemplateRef<any> | undefined;
  @ViewChild('headeELeaveCol4', { static: true })
  headeELeaveCol4: TemplateRef<any> | undefined;
  @ViewChild('headeELeaveCol5', { static: true })
  headeELeaveCol5: TemplateRef<any> | undefined;
  @ViewChild('headeELeaveCol6', { static: true })
  headeELeaveCol6: TemplateRef<any> | undefined;
  @ViewChild('headeELeaveCol7', { static: true })
  headeELeaveCol7: TemplateRef<any> | undefined;

  //Thân nhân

  eFamilyColumnGrid!: any[];

  @ViewChild('templateEFamilyCol1', { static: true })
  templateEFamilyCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEFamilyCol2', { static: true })
  templateEFamilyCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEFamilyCol3', { static: true })
  templateEFamilyCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEFamilyCol4', { static: true })
  templateEFamilyCol4: TemplateRef<any> | undefined;
  @ViewChild('templateEFamilyCol5', { static: true })
  templateEFamilyCol5: TemplateRef<any> | undefined;


  @ViewChild('headeEFamilyCol1', { static: true })
  headeEFamilyCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEFamilyCol2', { static: true })
  headeEFamilyCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEFamilyCol3', { static: true })
  headeEFamilyCol3: TemplateRef<any> | undefined;
  @ViewChild('headeEFamilyCol4', { static: true })
  headeEFamilyCol4: TemplateRef<any> | undefined;
  @ViewChild('headeEFamilyCol5', { static: true })
  headeEFamilyCol5: TemplateRef<any> | undefined;


  //Phúc lợi

  eBasicSalaryColumnGrid!: any[];


  @ViewChild('templateEBasicSalaryCol1', { static: true })
  templateEBasicSalaryCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEBasicSalaryCol2', { static: true })
  templateEBasicSalaryCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEBasicSalaryCol3', { static: true })
  templateEBasicSalaryCol3: TemplateRef<any> | undefined;


  @ViewChild('headeEBasicSalaryCol1', { static: true })
  headeEBasicSalaryCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEBasicSalaryCol2', { static: true })
  headeEBasicSalaryCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEBasicSalaryCol3', { static: true })
  headeEBasicSalaryCol3: TemplateRef<any> | undefined;


  eJobSalaryColumnGrid!: any[];


  @ViewChild('templateEJobSalaryCol1', { static: true })
  templateEJobSalaryCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEJobSalaryCol2', { static: true })
  templateEJobSalaryCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEJobSalaryCol3', { static: true })
  templateEJobSalaryCol3: TemplateRef<any> | undefined;

  @ViewChild('headeEJobSalaryCol1', { static: true })
  headeEJobSalaryCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEJobSalaryCol2', { static: true })
  headeEJobSalaryCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEJobSalaryCol3', { static: true })
  headeEJobSalaryCol3: TemplateRef<any> | undefined;


  eAllowanceColumnGrid!: any[];


  @ViewChild('templateEAllowanceCol1', { static: true })
  templateEAllowanceCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEAllowanceCol2', { static: true })
  templateEAllowanceCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEAllowanceCol3', { static: true })
  templateEAllowanceCol3: TemplateRef<any> | undefined;

  @ViewChild('headeEAllowanceCol1', { static: true })
  headeEAllowanceCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEAllowanceCol2', { static: true })
  headeEAllowanceCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEAllowanceCol3', { static: true })
  headeEAllowanceCol3: TemplateRef<any> | undefined;


  //Thu nhập khác
  eAdditionalIncomeColumnGrid!: any[];


  @ViewChild('templateEAdditionalIncomeCol1', { static: true })
  templateEAdditionalIncomeCol1: TemplateRef<any> | undefined;
  @ViewChild('templateEAdditionalIncomeCol2', { static: true })
  templateEAdditionalIncomeCol2: TemplateRef<any> | undefined;
  @ViewChild('templateEAdditionalIncomeCol3', { static: true })
  templateEAdditionalIncomeCol3: TemplateRef<any> | undefined;
  @ViewChild('templateEAdditionalIncomeCol4', { static: true })
  templateEAdditionalIncomeCol4: TemplateRef<any> | undefined;

  @ViewChild('headeEAdditionalIncomeCol1', { static: true })
  headeEAdditionalIncomeCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEAdditionalIncomeCol2', { static: true })
  headeEAdditionalIncomeCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEAdditionalIncomeCol3', { static: true })
  headeEAdditionalIncomeCol3: TemplateRef<any> | undefined;
  @ViewChild('headeEAdditionalIncomeCol4', { static: true })
  headeEAdditionalIncomeCol4: TemplateRef<any> | undefined;


  eDeductionColumnGrid!: any[];

  @ViewChild('templateDeductionCol1', { static: true })
  templateDeductionCol1: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionCol2', { static: true })
  templateDeductionCol2: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionCol3', { static: true })
  templateDeductionCol3: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionCol4', { static: true })
  templateDeductionCol4: TemplateRef<any> | undefined;
  @ViewChild('templateDeductionCol5', { static: true })
  templateDeductionCol5: TemplateRef<any> | undefined;

  @ViewChild('headeEDeductionCol1', { static: true })
  headeEDeductionCol1: TemplateRef<any> | undefined;
  @ViewChild('headeEDeductionCol2', { static: true })
  headeEDeductionCol2: TemplateRef<any> | undefined;
  @ViewChild('headeEDeductionCol3', { static: true })
  headeEDeductionCol3: TemplateRef<any> | undefined;
  @ViewChild('headeEDeductionCol4', { static: true })
  headeEDeductionCol4: TemplateRef<any> | undefined;
  @ViewChild('headeEDeductionCol5', { static: true })
  headeEDeductionCol5: TemplateRef<any> | undefined;

  //--------------------------------------------------------NHTRUNG END-----------------------------------

  // eBasicSalary
  @ViewChild('basicSalaryCol1', { static: true })
  basicSalaryCol1: TemplateRef<any>;
  @ViewChild('basicSalaryCol2', { static: true })
  basicSalaryCol2: TemplateRef<any>;
  @ViewChild('basicSalaryCol3', { static: true })
  basicSalaryCol3: TemplateRef<any>;
  @ViewChild('basicSalaryCol4', { static: true })
  basicSalaryCol4: TemplateRef<any>;

  // eAppointion - Bổ nhiệm điều chuyển
  @ViewChild('templateAppointionGridCol1', { static: true })
  templateAppointionGridCol1: TemplateRef<any>;
  @ViewChild('templateAppointionGridCol2', { static: true })
  templateAppointionGridCol2: TemplateRef<any>;
  @ViewChild('templateAppointionGridCol3', { static: true })
  templateAppointionGridCol3: TemplateRef<any>;
  @ViewChild('headTempAppointion1', { static: true })
  headTempAppointion1: TemplateRef<any>;
  @ViewChild('headTempAppointion2', { static: true })
  headTempAppointion2: TemplateRef<any>;
  @ViewChild('headTempAppointion3', { static: true })
  headTempAppointion3: TemplateRef<any>;

  //#endregion

  //eDayoff
  @ViewChild('templateDayOffGridCol1', { static: true })
  templateDayOffGridCol1: TemplateRef<any>;
  @ViewChild('templateDayOffGridCol2', { static: true })
  templateDayOffGridCol2: TemplateRef<any>;
  @ViewChild('templateDayOffGridCol3', { static: true })
  templateDayOffGridCol3: TemplateRef<any>;
  @ViewChild('headTempDayOff1', { static: true })
  headTempDayOff1: TemplateRef<any>;
  @ViewChild('headTempDayOff2', { static: true })
  headTempDayOff2: TemplateRef<any>;
  @ViewChild('headTempDayOff3', { static: true })
  headTempDayOff3: TemplateRef<any>;

  // Lương chức danh
  @ViewChild('jobSalaryCol1', { static: true })
  jobSalaryCol1: TemplateRef<any>;
  @ViewChild('jobSalaryCol2', { static: true })
  jobSalaryCol2: TemplateRef<any>;
  @ViewChild('jobSalaryCol3', { static: true })
  jobSalaryCol3: TemplateRef<any>;
  @ViewChild('jobSalaryCol4', { static: true })
  jobSalaryCol4: TemplateRef<any>;

  // Hợp đồng lao động
  @ViewChild('eContractCol1', { static: true })
  eContractCol1: TemplateRef<any>;
  @ViewChild('eContractCol2', { static: true })
  eContractCol2: TemplateRef<any>;
  @ViewChild('eContractCol3', { static: true })
  eContractCol3: TemplateRef<any>;

  //Tai nạn lao động

  @ViewChild('templateEAccidentCol1', { static: true })
  templateEAccidentCol1: TemplateRef<any>;
  @ViewChild('templateEAccidentCol2', { static: true })
  templateEAccidentCol2: TemplateRef<any>;
  @ViewChild('templateEAccidentCol3', { static: true })
  templateEAccidentCol3: TemplateRef<any>;
  @ViewChild('headTempAccident1', { static: true })
  headTempAccident1: TemplateRef<any>;
  @ViewChild('headTempAccident2', { static: true })
  headTempAccident2: TemplateRef<any>;
  @ViewChild('headTempAccident3', { static: true })
  headTempAccident3: TemplateRef<any>;

  //#endregion

  

  //#region gridView viewChild
  @ViewChild('passportGridview', { static: true })
  passportGridview: CodxGridviewV2Component;
  @ViewChild('visaGridview') visaGridview: CodxGridviewV2Component;
  @ViewChild('workPermitGridview') workPermitGridview: CodxGridviewV2Component;
  @ViewChild('basicSalaryGridview')
  basicSalaryGridview: CodxGridviewV2Component;
  @ViewChild('appointionGridView') appointionGridView: CodxGridviewV2Component;
  @ViewChild('jobSalaryGridview') jobSalaryGridview: CodxGridviewV2Component;
  @ViewChild('eContractGridview') eContractGridview: CodxGridviewV2Component;
  @ViewChild('eAccidentGridView') eAccidentGridView: CodxGridviewV2Component;

  //#endregion

  @ViewChild('tmpTemp', { static: true })
  tmpTemp: TemplateRef<any>;
  @ViewChild('tmpViewAllPassport', { static: true })
  tmpViewAllPassport: TemplateRef<any>;
  @ViewChild('tmpViewAllVisa', { static: true })
  tmpViewAllVisa: TemplateRef<any>;
  @ViewChild('tmpViewAllWorkpermit', { static: true })
  tmpViewAllWorkpermit: TemplateRef<any>;
  @ViewChild('tmpViewAllContract', { static: true })
  tmpViewAllContract: TemplateRef<any>;

  //Declare model ViewAll Salary
  @ViewChild('templateViewSalary', { static: true })
  templateViewSalary: TemplateRef<any>;
  dialogViewSalary: any;

  //Declare model ViewAll Benefit
  @ViewChild('templateViewBenefit', { static: true })
  templateViewBenefit: TemplateRef<any>;
  dialogViewBenefit: any;

  listEmp: any = [];
  request: DataRequest;

  lstTab: any;
  isHiddenCbxDocument = true;
  lstCurrentDocumentTypeID: any = [];
  strCurrentDocuments: any;

  //#region functions list
  lstFuncCurriculumVitae: any = [];
  lstWorkingProcess: any = [];
  lstRewardCatalog: any = [];
  lstBenefit: any = [];
  lstlegalInfo: any = [];
  lstFuncEducationInfo: any =[];

  lstFuncJobInfo: any = [];
  lstFuncSalaryBenefit: any = [];
  lstFuncHRProcess: any = [];
  lstFuncKnowledge: any = [];
  lstFuncHealth: any = [];
  lstFuncQuitJob: any = [];
  lstFuncArchiveRecords: any = [];
  lstFuncSeverance: any = [];
  lstFuncID: any = [];

  //father funcID
  lstFuncLegalInfo: any = [];
  lstFuncForeignWorkerInfo: any = [];

  //#endregion

  //#region RowCount
  eDegreeRowCount: number = 0;
  passportRowCount: number = 0;
  visaRowCount: number = 0;
  workPermitRowCount: number = 0;
  //eExperienceRowCount = 0;
  eCertificateRowCount = 0;
  eBenefitRowCount: number = 0;
  // eBusinessTravelRowCount = 0;
  eSkillRowCount = 0;
  // dayoffRowCount: number = 0;
  eAssetRowCount = 0;
  eBasicSalaryRowCount = 0;
  eTrainCourseRowCount = 0;
  eHealthRowCount = 0;
  eVaccineRowCount = 0;
  //appointionRowCount = 0;
  eJobSalaryRowCount = 0;
  //awardRowCount = 0;
  //eContractRowCount = 0;
  //eDisciplineRowCount = 0;
  eDiseasesRowCount = 0;
  eAccidentsRowCount = 0;
  // eHealthRowCount = 0;
  // eVaccineRowCount = 0;
  appointionRowCount = 0;
  awardRowCount = 0;
  eContractRowCount = 0;
  eDisciplineRowCount = 0;
  // eDiseasesRowCount = 0;
  // eAccidentsRowCount = 0;
  //#endregion

  //#region var functionID

  // jobInfoPer = {
  //   jobGeneralFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //   },
  //   eTimeCardFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //   },
  //   eCalSalaryFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //   },
  //   eNeedToSubmitProfileFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  // };

  // salaryBenefitInfoPer = {
  //   eBasicSalaryFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   benefitFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  // };

  // workingProcessInfoPer = {
  //   eContractFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   appointionFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   dayoffFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eBusinessTravelFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   awardFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eDisciplineFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  // };

  // knowledgeInfoPer = {
  //   eDegreeFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eCertificateFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eSkillFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eTrainCourseFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  // };

  // healthInfoPer = {
  //   eHealthFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eDiseasesFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eVaccinesFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   eAccidentsFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  // };

  // quitjobInfoPer = {
  //   eQuitJobFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //   },
  // };

  // curriculumVitaePermission = {
  //   eInfoFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //   },
  //   ePartyFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //   },
  //   eFamiliesFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  //   foreignWorkerFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     workPermitFuncID: {
  //       view: false,
  //       write: false,
  //       delete: false,
  //       isPortal: false,
  //     },
  //   },
  //   legalInfoFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     passportFuncID: {
  //       view: false,
  //       write: false,
  //       delete: false,
  //       isPortal: false,
  //     },
  //     visaFuncID: {
  //       view: false,
  //       write: false,
  //       delete: false,
  //       isPortal: false,
  //     },
  //   },
  //   eExperienceFuncID: {
  //     view: false,
  //     write: false,
  //     delete: false,
  //     isPortal: false,
  //   },
  // };

  REFERTYPE = {
    IMAGE: 'image',
    VIDEO: 'video',
    APPLICATION: 'application',
  };

  curriculumVitaeFuncID: string = '';
  dashBoardID: string = '';
  JobProcessID: string = '';
  rewardCatalogID: string = '';
  benefitInfoID: string = '';
  EducationID: string = '';
  legalInfoFuncID: string = '';

  eGroupSalaryFuncID: string;
  eBasicSalaryFuncID = null;
  eJWSalaryFuncID: string;
  eAllowanceFuncID: string;
  eDeductionFuncID: string;
  eAdditionalIncomeFuncID: string;

  eAwardFuncID: string;
  eDisciplinaryFuncID: string;

  eCertificateFuncID: string;
  eSpecializationFuncID: string
  eTrainFuncID: string;
  eEvaluationFuncID: string;

  eFamilyFuncID: string;
  eContactFuncID;
  eWorkedInfoFuncID;
  eDepartInfoFuncID;

  eWorkingFuncID: string;
  eDayOffFuncID: string;

  eBankFuncID: string;
  eContractFuncID = null;
  eGroupInfoFuncID = null;
  eInsuranceFuncID = null;









  eGroupSalaryFunc = null;
  eBasicSalaryFunc = null;
  eJWSalaryFunc = null;
  eAllowanceFunc = null;
  eDeductionFunc = null;
  eAdditionalIncomeFunc = null;

  eSpecializationFunc = null;


  eAwardFunc = null;
  eDisciplinaryFunc = null;

  eCertificateFunc = null;
  eTrainFunc = null;
  eEvaluationFunc = null;

  eFamilyFunc = null;
  eContactFunc = null;
  eWorkedInfoFunc = null;
  eDepartInfoFunc = null;

  eWorkingFunc = null;
  eDayOffFunc = null;

  eBankFunc = null
  eContractFunc = null
  eGroupInfoFunc = null;
  eInsuranceFunc = null;

  //Gridview
  gridViewSetupWorking: any;


  foreignWorkerFuncID: string = '';
  jobInfoFuncID: string = '';
  salaryBenefitInfoFuncID: string = '';
  workingProcessInfoFuncID: string = '';
  knowledgeInfoFuncID: string = '';
  healthInfoFuncID: string = '';
  quitJobInfoFuncID: string = '';

  curriculumVitaeFunc = null;
  legalInfoFunc = null;
  foreignWorkerFunc = null;
  jobInfoFunc = null;
  salaryBenefitInfoFunc = null;
  workingProcessInfoFunc = null;
  knowledgeInfoFunc = null;
  healthInfoFunc = null;
  quitJobInfoFunc = null;
  eInfoFuncID = null;
  ePartyFuncID = null;
  eFamiliesFuncID = null;
  eAssurFuncID = null;
  ePassportFuncID = null;
  eDegreeFuncID = null;
  eVisaFuncID = null;
  eWorkPermitFuncID = null;
  // eCertificateFuncID = null;
  eSkillFuncID = null;
  eExperienceFuncID = null; // Kinh nghiệm trước đây
  eAssetFuncID = null; // Tài sản cấp phát
  eTimeCardFuncID = null;
  eCalSalaryFuncID = null;
  jobGeneralFuncID = null;
  // eBasicSalaryFuncID = null;
  eJobSalFuncID = null; //Lương chức danh
  eTrainCourseFuncID = null;
  eBusinessTravelFuncID = null;
  eHealthFuncID = null; // Khám sức khỏe
  eVaccinesFuncID = null; // Tiêm vắc xin
  benefitFuncID = null;
  dayoffFuncID = null;
  appointionFuncID = null;
  awardFuncID = null;
  // eContractFuncID = null;
  eDisciplineFuncID = null;
  eDiseasesFuncID = null;
  eQuitJobFuncID = null;
  eAccidentsFuncID = null;
  eNeedToSubmitProfileFuncID = null;

  eInfoFunc = null;
  ePartyFunc = null;
  eFamiliesFunc = null;
  eAssurFunc = null;
  ePassportFunc = null;
  eDegreeFunc = null;
  eVisaFunc = null;
  eWorkPermitFunc = null;
  // eCertificateFunc = null;
  eSkillFunc = null;
  eExperienceFunc = null; // Kinh nghiệm trước đây
  eAssetFunc = null; // Tài sản cấp phát
  eTimeCardFunc = null;
  eCalSalaryFunc = null;
  jobGeneralFunc = null;
  // eBasicSalaryFunc = null;
  eJobSalFunc = null; //Lương chức danh
  eTrainCourseFunc = null;
  eBusinessTravelFunc = null;
  eHealthFunc = null; // Khám sức khỏe
  eVaccinesFunc = null; // Tiêm vắc xin
  benefitFunc = null;
  dayoffFunc = null;
  appointionFunc = null;
  awardFunc = null;
  // eContractFunc = null;
  eDisciplineFunc = null;
  eDiseasesFunc = null;
  eQuitJobFunc = null;
  eAccidentsFunc = null;
  eNeedToSubmitProfileFunc = null;
  //#endregion

  //#region urls
  dashBoardURL: string = 'ws/emplistportal/WSHREM01'; //Thống kê tổng quan dashBoardID
  curriculumVitaeURL: string = 'ws/emplistportal/WSHREM02'; //SYLL curriculumVitaeFuncID
  JobProcessURL: string = 'ws/empworkingportal/WSHREM04'; //Qúa trình làm việc JobProcessID
  rewardCatalogURL: string = 'ws/empawardportal/WSHREM07'; //Khen thưởng kỷ luật;
  benefitInfoURL: string = 'ws/emplistportal/WSHREM03'; //Thông tin phúc lợi;
  EducationURL: string = 'ws/emptrainbgrdportal/WSHREM06'; // Hồ sơ năng lực
  legalInfoURL: string = 'ws/emplistportal/WSHREM05'; //Pháp lý legalInfoFuncID

  //treelevel3 - benefitInfoURL
  eGroupSalaryURL: string = 'ws/emplistportal/WSHREM0301'; //Nhóm lương - 
  eBasicSalaryURL: string = 'ws/empbasicsalaryportal/WSHREM0302'; // Lương cơ bản
  eJWSalaryURL: string = 'ws/empjwsalaryportal/WSHREM0303'; //Lương chức danh
  eAllowanceURL: string = 'ws/empallowanceportal/WSHREM0304'; //Phụ cấp
  ePayTExceptURL: string = 'ws/paytexceptportal/WSHREM0305';
  eDeductionURL: string = 'ws/paytexceptportal/WSHREM0306'; //Khấu trừ khác
  eAdditionalIncomeURL: string = 'ws/paytexceptportal/WSHREM0305'; //Thu nhập khác

  //treelevel3 - aWardURL
  eAwardURL: string = 'ws/empawardportal/WSHREM0701';
  eDisciplinaryURL: string = 'ws/empdisciplineportal/WSHREM0702';

  //treeviewlevel3  - eEducation
  eSpecializationURL: string = 'ws/emptrainbgrdportal/WSHREM0601';
  eCertificateURL: string = 'ws/empcertificateportal/WSHREM0602';
  eTrainURL: string = 'ws/emptraincourseportal/WSHREM0603';
  eEvaluationURL: string = 'ws/aprperiodicportal/WSHREM0604';

  //treeviewlevel 3 - Personal Info
  // eFamilyFuncID:string = 'ws/empfamilyportal/WSHREM0201'

  //treeviewlevel 3 - Qúa trình làm việc
  eWorkingURL: string = 'ws/empworkingportal/WSHREM0401';
  eDayOffURL: string = 'ws/empdayoffportal/WSHREM0402';

  //treeViewLevel 3 - Qúa trình pháp lý
  eBankURL: string = 'ws/empbankportal/WSHREM0501';
  eContractURL: string = 'ws/empcontractportal/WSHREM0502';
  eGroupInfoURL: string = 'ws/emplistportal/WSHREM0503';
  eInsuranceURL: string = 'ws/emplistportal/WSHREM0504';







  foreignWorkerURL: string = 'hreprofile01cv-foreigner'; //foreignWorkerFuncID
  jobInfoURL: string = 'hreprofile02job'; //thông tin nhân viên, jobInfoFuncID
  salaryBenefitInfoURL: string = 'hreprofile03salary'; //Lương phúc lợi salaryBenefitInfoFuncID
  workingProcessInfoURL: string = 'hreprofile04process'; //Quá trình NS workingProcessInfoFuncID
  knowledgeInfoURL: string = 'hreprofile05knowledge'; //Kiến thức knowledgeInfoFuncID
  healthInfoURL: string = 'hreprofile06health'; //sức khỏe healthInfoFuncID
  quitJobInfoURL: string = 'hreprofile07quit'; //thôi việc quitJobInfoFuncID

  eFamilyInfoURL = 'ws/empfamilyportal/WSHREM0201'; //Thông tin thân nhân 
  eInfoURL = 'ws/emplistportal/WSHREM0202'; //Thông tin bản thân eInfoFuncID
  eContactURL = 'ws/emplistportal/WSHREM0203'; // Thông tin liên hệ
  eWorkedInfoURL = 'ws/emplistportal/WSHREM0204'; //Thông tin công việc
  eDepartInfoURL = 'ws/emplistportal/WSHREM0205'; //Thông tin bộ phận chức danh

  ePartyURL = 'hreprofile01cv-party'; // Đảng đoàn ePartyFuncID
  eFamiliesURL = 'ws/empfamilyportal/WSHREM0201'; // Quan hệ gia đình eFamiliesFuncID
  eAssurURL = 'hreprofile01cv-insurance'; // Bảo hiểm - MS thuế - Tài khoản eAssurFuncID
  ePassportURL = 'hreprofile01cv-passport'; //Hộ chiếu ePassportFuncID
  eDegreeURL = 'hreprofile05knowledge-edegree'; // Bằng cấp eDegreeFuncID
  eVisaURL = 'hreprofile01cv-visa'; //Thị thực eVisaFuncID
  eWorkPermitURL = 'hreprofile01cv-workpermit'; // Giấy phép lao động eWorkPermitFuncID
  // eCertificateURL = 'hreprofile05knowledge-ecertificate'; // Chứng chỉ eCertificateFuncID
  eSkillURL = 'hreprofile05knowledge-eskill'; // Kỹ năng eSkillFuncID
  eExperienceURL = 'hreprofile01cv-eexperience'; // Kinh nghiệm trước đây eExperienceFuncID
  // eAssetURL = 'HRTEM0406'; // Tài sản cấp phát eAssetFuncID
  eTimeCardURL = 'hreprofile02job-time'; // Chấm công eTimeCardFuncID
  eCalSalaryURL = 'hreprofile02job-payroll'; // Tính lương eCalSalaryFuncID
  jobGeneralURL = 'hreprofile02job-info'; // Thông tin chung jobGeneralFuncID
  // eBasicSalaryURL = 'hreprofile03salary-esalary'; // Mức lương eBasicSalaryFuncID
  // eJobSalURL = 'HRTEM0402'; //Lương chức danh eJobSalFuncID
  eTrainCourseURL = 'hreprofile05knowledge-etraincourse'; //Đào tạo eTrainCourseFuncID
  eBusinessTravelURL = 'hreprofile04process-ebusinesstravel'; // Công tác eBusinessTravelFuncID
  eHealthURL = 'hreprofile06health-ehealth'; // Khám sức khỏe eHealthFuncID
  eVaccinesURL = 'hreprofile06health-evaccine'; // Tiêm vắc xin eVaccinesFuncID
  benefitURL = 'hreprofile03salary-ebenefit'; // Phụ cấp benefitFuncID
  dayoffURL = 'hreprofile04process-edayoff'; // Nghỉ phép dayoffFuncID
  appointionURL = 'hreprofile04process-eappointion'; // Bổ nhiệm - Điều chuyển appointionFuncID
  awardURL = 'hreprofile04process-eaward'; // Khen thưởng awardFuncID
  // eContractURL = 'hreprofile04process-econtract'; // Hợp đồng lao động eContractFuncID
  eDisciplineURL = 'hreprofile04process-ediscipline'; // Kỷ luật eDisciplineFuncID
  eDiseasesURL = 'hreprofile06health-edisease'; // Bệnh nghề nghiệp eDiseasesFuncID
  eQuitJobURL = 'hreprofile07quit-info'; // Thông tin thôi việc eQuitJobFuncID
  eAccidentsURL = 'hreprofile06health-eaccident'; // Tai nạn lao động eAccidentsFuncID
  eNeedToSubmitProfileURL = 'hreprofile02job-edocument'; // Hồ sơ cần nộp eNeedToSubmitProfileFuncID

  //#endregion

  //#region Vll colors
  AssetColorValArr: any = [];
  BeneFitColorValArr: any = [];
  VaccineColorValArr: any = [];
  //#endregion
  crrFuncTab: string = '1';

  //Check loaded ESalary
  loadedESalary: boolean;
  loadEBenefit: boolean;

  //#region var formModel

  eInfoFormModel: FormModel;
  eFamilyInfoFormModel: FormModel;
  eFamilyInfoGroupFormModel: FormGroup;
  eContactFormModel: FormModel;
  eWorkedInfoFormModel: FormModel;
  eDepartInfoFormModel: FormModel;

  //Thông tin phúc lợi
  eGroupSalaryFormModel: FormModel;
  eBasicSalaryFormModel: FormModel;
  eJWSalaryFormModel: FormModel;
  eAllowanceFormModel: FormModel;
  eDeductionFormModel: FormModel; // Khấu trừ khác
  eAdditionalIncomeFormModel: FormModel; // Thu nhập khác

  //THông tin khen thưởng
  eAwardFormModel: FormModel;
  eDisciplinaryFormModel: FormModel;

  //Thông tin quá trình làm việc
  eWorkingFormModel: FormModel;
  eDayOffFormModel: FormModel;

  //Chứng chỉ
  eSpecializationFormModel: FormModel;
  eCertificateFormModel: FormModel;
  eTrainFormModel: FormModel;
  eEvaluationFormModel: FormModel;

  //Qúa trình pháp lý
  eBankFormModel: FormModel;
  eContractFormModel: FormModel; //Hợp đồng lao động
  eGroupInfoFormModel: FormModel;
  eInsuranceFormModel: FormModel;




  benefitFormodel: FormModel;
  edocumentFormModel: FormModel;
  EBusinessTravelFormodel: FormModel;
  // eInfoFormModel: FormModel; // Thông tin bản thân/ Bảo hiểm
  eInfoFormGroup: FormGroup;
  eFamilyFormModel: FormModel; //Quan hệ gia đình
  ePassportFormModel: FormModel; //Hộ chiếu
  eQuitJobFormModel: FormModel; //Nghỉ việc
  eVisaFormModel: FormModel;
  eWorkPermitFormModel: FormModel; //Giay phep lao dong
  // eCertificateFormModel: FormModel; // Chứng chỉ
  eDegreeFormModel: FormModel; // Bằng cấp
  eSkillFormmodel: FormModel; // Kỹ năng
  eExperienceFormModel: FormModel; //Kinh nghiệm trước đây
  eAssetFormModel: FormModel; //Tài sản cấp phát
  eBasicSalaryFormmodel: FormModel; //Lương cơ bản
  eTrainCourseFormModel: FormModel; // Đào tạo
  eHealthFormModel: FormModel; //Khám sức khỏe
  eVaccineFormModel: FormModel; //Tiêm vắc xin
  appointionFormModel: FormModel;
  dayoffFormModel: FormModel;
  eJobSalaryFormModel: FormModel; // Lương chức danh
  awardFormModel: FormModel; // Khen thưởng
  // eContractFormModel: FormModel; // Hợp đồng lao động
  eDisciplineFormModel: FormModel; // Kỷ luật
  eDiseasesFormModel: FormModel; // Bệnh nghề nghiệp
  eAccidentsFormModel: FormModel;
  //#endregion

  //#region headerText

  //Thông tin phúc lợi
  eInfoHeaderText: any;
  eGroupSalaryHeaderTexts: any;
  eBasicSalaryHeaderTexts: any;
  eJWSalaryHeaderTexts: any;
  eAllowanceHeaderTexts: any;
  eDeductionHeaderTexts: any; // Khấu trừ khác
  eAdditionalIncomeHeaderTexts: any; // Thu nhập khác


  //Thông tin khen thưởng - kỷ luật
  eAwardHeaderTexts: any;
  eDisciplinaryHeaderTexts: any;


  //Thông tin kiến thức
  eCertificateHeaderTexts: any;
  eSpecializationHeaderTexts: any;
  eTrainHeaderTexts: any;
  eEvaluationHeaderTexts: any;

  //Thân nhân
  eFamilyHeaderTexts: any;

  //Quá trình làm việc
  eWorkingHeaderTexts: any;
  eDayOffHeaderTexts: any;

  //Hợp đồng lao động
  eBankHeaderTexts: any;
  eContractHeaderTexts: any;
  eGroupInfoHeaderTexts: any;
  eInsuranceHeaderTexts: any;


  eBusinessTravelHeaderTexts;
  benefitHeaderTexts;
  dayoffHeaderTexts;
  eDegreeHeaderText;
  eExperienceHeaderText;
  eAssetHeaderText;
  eCertificateHeaderText;
  eSkillHeaderText;
  eTrainCourseHeaderText;
  eHealthHeaderText;
  eVaccineHeaderText;
  appointionHeaderTexts;
  eJobSalaryHeaderText;
  awardHeaderText;
  eContractHeaderText;
  eDisciplineHeaderText;
  eDiseasesHeaderText;
  eAccidentHeaderText;
  eFamilyHeaderText;
  //#endregion

  //biến cờ hiệu thể hiện nguồn tới trang này là từ WS không phải DSNV
  fromWS = false;

  pageNum: number = 0;
  maxPageNum: number = 0;
  crrIndex: number = 0;
  totalCount: number = 0;
  fromView: string = '';

  currentDate = new Date();
  passPortIsExpired = false;
  visaIsExpired = false;
  workpermitIsExpired = false;

  currentYear = new Date().getFullYear();
  firstDay = new Date(this.currentYear, 0, 1);
  lastDay = new Date(this.currentYear, 11, 31);
  dayOffInitPredicate = `(EmployeeID=@0 and (BeginDate>="${this.firstDay.toISOString()}" and EndDate<="${this.lastDay.toISOString()}"))`;

  //#region headerTextString
  addHeaderText;
  editHeaderText;
  //#endregion

  loadedLineManager = false;
  loadedIndirectManager = false;

  //#region filter variables of form main eDayoffs
  filterByKowIDArr: any = [];
  yearFilterValueDayOffs;
  startDateEDayoffFilterValue;
  endDateEDayoffFilterValue;
  filterEDayoffPredicates: string;
  filterEDayoffDatavalues;
  //#endregion

  reRender = false;

  //#region filter variables of form main EBusinessTravel
  yearFilterValueBusinessTravel;
  startDateBusinessTravelFilterValue;
  endDateBusinessTravelFilterValue;
  filterBusinessTravelPredicates: string;
  LoadedEInfo = false;
  //#endregion


  @ViewChild('eFamilyGridViewID') eFamilyGridViewID: CodxGridviewV2Component;

  @ViewChild('eBasicSalaryGridViewID') eBasicSalaryGridViewID: CodxGridviewV2Component;
  @ViewChild('eJobSalaryGridViewID') eJobSalaryGridViewID: CodxGridviewV2Component;
  @ViewChild('eAllowanceGridViewID') eAllowanceGridViewID: CodxGridviewV2Component;
  @ViewChild('eAdditionalEarningsGridViewID') eAdditionalEarningsGridViewID: CodxGridviewV2Component;
  @ViewChild('eEductionGridViewID') eEductionGridViewID: CodxGridviewV2Component;

  @ViewChild('ePromoGridViewID') ePromoGridViewID: CodxGridviewV2Component;
  @ViewChild('eLeaveGridViewID') eLeaveGridViewID: CodxGridviewV2Component;

  @ViewChild('eSpecializationGridViewID') eSpecializationGridViewID: CodxGridviewV2Component;
  @ViewChild('eCertificateGridViewID') eCertificateGridViewID: CodxGridviewV2Component;
  @ViewChild('eTrainGridViewID') eTrainGridViewID: CodxGridviewV2Component;
  @ViewChild('eEvaluationGridViewID') eEvaluationGridViewID: CodxGridviewV2Component;

  @ViewChild('eAwardGridViewID') eAwardGridViewID: CodxGridviewV2Component;
  @ViewChild('eDisciplinaryGridViewID') eDisciplinaryGridViewID: CodxGridviewV2Component;




  @ViewChild('eDiseasesGridView') eDiseasesGrid: CodxGridviewV2Component;
  @ViewChild('eAwardGridView') AwardGrid: CodxGridviewV2Component;
  @ViewChild('eDisciplineGridView') eDisciplineGrid: CodxGridviewV2Component;
  @ViewChild('businessTravelGrid') businessTravelGrid: CodxGridviewV2Component;
  @ViewChild('eTrainCourseGridView') eTrainCourseGrid: CodxGridviewV2Component;
  @ViewChild('eSkillGridViewID') skillGrid: CodxGridviewV2Component;
  @ViewChild('eCertificateGridView') eCertificateGrid: CodxGridviewV2Component;
  @ViewChild('eExperienceGridView') eExperienceGrid: CodxGridviewV2Component;
  @ViewChild('eAssetGridView') eAssetGrid: CodxGridviewV2Component;
  @ViewChild('eHealthsGridView') eHealthsGrid: CodxGridviewV2Component;
  @ViewChild('eVaccinesGridView') eVaccinesGrid: CodxGridviewV2Component;
  @ViewChild('gridView') eBenefitGrid: CodxGridviewV2Component;
  @ViewChild('eDegreeGridView') eDegreeGrid: CodxGridviewV2Component;
  @ViewChild('dayoffGridView') dayoffGrid: CodxGridviewV2Component;
  @ViewChild('templateBenefitID', { static: true })
  templateBenefitID: TemplateRef<any>;
  @ViewChild('templateBenefitAmt', { static: true })
  templateBenefitAmt: TemplateRef<any>;
  @ViewChild('templateBenefitEffected', { static: true })
  templateBenefitEffected: TemplateRef<any>;
  @ViewChild('filterTemplateBenefit', { static: true })
  filterTemplateBenefit: TemplateRef<any>;

  @ViewChild('templateEDegreeGridCol1', { static: true })
  templateEDegreeGridCol1: TemplateRef<any>;
  @ViewChild('templateEDegreeGridCol2', { static: true })
  templateEDegreeGridCol2: TemplateRef<any>;
  @ViewChild('templateEDegreeGridCol3', { static: true })
  templateEDegreeGridCol3: TemplateRef<any>;
  @ViewChild('templateEDegreeGridMoreFunc', { static: true })
  templateEDegreeGridMoreFunc: TemplateRef<any>;
  @ViewChild('headTempDegree1', { static: true })
  headTempDegree1: TemplateRef<any>;
  @ViewChild('headTempDegree2', { static: true })
  headTempDegree2: TemplateRef<any>;
  @ViewChild('headTempDegree3', { static: true })
  headTempDegree3: TemplateRef<any>;

  @ViewChild('tempCol1EHealthGrid', { static: true })
  tempCol1EHealthGrid: TemplateRef<any>;
  @ViewChild('tempCol2EHealthGrid', { static: true })
  tempCol2EHealthGrid: TemplateRef<any>;
  @ViewChild('tempCol3EHealthGrid', { static: true })
  tempCol3EHealthGrid: TemplateRef<any>;
  @ViewChild('headTempHealth1', { static: true })
  headTempHealth1: TemplateRef<any>;
  @ViewChild('headTempHealth2', { static: true })
  headTempHealth2: TemplateRef<any>;
  @ViewChild('headTempHealth3', { static: true })
  headTempHealth3: TemplateRef<any>;

  @ViewChild('tempEVaccineGridCol1', { static: true })
  tempEVaccineGridCol1: TemplateRef<any>;
  @ViewChild('tempEVaccineGridCol2', { static: true })
  tempEVaccineGridCol2: TemplateRef<any>;
  @ViewChild('tempEVaccineGridCol3', { static: true })
  tempEVaccineGridCol3: TemplateRef<any>;
  @ViewChild('headTempVaccine1', { static: true })
  headTempVaccine1: TemplateRef<any>;
  @ViewChild('headTempVaccine2', { static: true })
  headTempVaccine2: TemplateRef<any>;
  @ViewChild('headTempVaccine3', { static: true })
  headTempVaccine3: TemplateRef<any>;

  @ViewChild('templateECertificateGridCol1', { static: true })
  templateECertificateGridCol1: TemplateRef<any>;
  @ViewChild('templateECertificateGridCol2', { static: true })
  templateECertificateGridCol2: TemplateRef<any>;
  @ViewChild('templateECertificateGridCol3', { static: true })
  templateECertificateGridCol3: TemplateRef<any>;
  @ViewChild('headTempCertificate1', { static: true })
  headTempCertificate1: TemplateRef<any>;
  @ViewChild('headTempCertificate2', { static: true })
  headTempCertificate2: TemplateRef<any>;
  @ViewChild('headTempCertificate3', { static: true })
  headTempCertificate3: TemplateRef<any>;

  @ViewChild('templateESkillGridCol1', { static: true })
  templateESkillGridCol1: TemplateRef<any>;
  @ViewChild('templateESkillGridCol2', { static: true })
  templateESkillGridCol2: TemplateRef<any>;
  @ViewChild('templateESkillGridCol3', { static: true })
  templateESkillGridCol3: TemplateRef<any>;
  @ViewChild('headTempSkill1', { static: true })
  headTempSkill1: TemplateRef<any>;
  @ViewChild('headTempSkill2', { static: true })
  headTempSkill2: TemplateRef<any>;
  @ViewChild('headTempSkill3', { static: true })
  headTempSkill3: TemplateRef<any>;

  @ViewChild('templateEAssetCol1', { static: true })
  templateEAssetCol1: TemplateRef<any>;
  @ViewChild('templateEAssetCol2', { static: true })
  templateEAssetCol2: TemplateRef<any>;
  @ViewChild('templateEAssetCol3', { static: true })
  templateEAssetCol3: TemplateRef<any>;

  @ViewChild('templateEExperienceGridCol4', { static: true })
  templateEExperienceGridCol4: TemplateRef<any>;

  @ViewChild('templateTrainCourseGridCol1', { static: true })
  templateTrainCourseGridCol1: TemplateRef<any>;
  @ViewChild('templateTrainCourseGridCol2', { static: true })
  templateTrainCourseGridCol2: TemplateRef<any>;
  @ViewChild('templateTrainCourseGridCol3', { static: true })
  templateTrainCourseGridCol3: TemplateRef<any>;
  @ViewChild('headTempTrainCourse1', { static: true })
  headTempTrainCourse1: TemplateRef<any>;
  @ViewChild('headTempTrainCourse2', { static: true })
  headTempTrainCourse2: TemplateRef<any>;
  @ViewChild('headTempTrainCourse3', { static: true })
  headTempTrainCourse3: TemplateRef<any>;

  @ViewChild('templateBusinessTravelGridCol1', { static: true })
  templateBusinessTravelGridCol1: TemplateRef<any>;
  @ViewChild('templateBusinessTravelGridCol2', { static: true })
  templateBusinessTravelGridCol2: TemplateRef<any>;
  @ViewChild('templateBusinessTravelGridCol3', { static: true })
  templateBusinessTravelGridCol3: TemplateRef<any>;
  @ViewChild('headTempBusinessTravel1', { static: true })
  headTempBusinessTravel1: TemplateRef<any>;
  @ViewChild('headTempBusinessTravel2', { static: true })
  headTempBusinessTravel2: TemplateRef<any>;
  @ViewChild('headTempBusinessTravel3', { static: true })
  headTempBusinessTravel3: TemplateRef<any>;

  @ViewChild('templateAwardGridCol1', { static: true })
  templateAwardGridCol1: TemplateRef<any>;
  @ViewChild('templateAwardGridCol2', { static: true })
  templateAwardGridCol2: TemplateRef<any>;
  @ViewChild('templateAwardGridCol3', { static: true })
  templateAwardGridCol3: TemplateRef<any>;
  @ViewChild('headTempAwards1', { static: true })
  headTempAwards1: TemplateRef<any>;
  @ViewChild('headTempAwards2', { static: true })
  headTempAwards2: TemplateRef<any>;
  @ViewChild('headTempAwards3', { static: true })
  headTempAwards3: TemplateRef<any>;

  @ViewChild('templateDisciplineGridCol1', { static: true })
  templateDisciplineGridCol1: TemplateRef<any>;
  @ViewChild('templateDisciplineGridCol2', { static: true })
  templateDisciplineGridCol2: TemplateRef<any>;
  @ViewChild('templateDisciplineGridCol3', { static: true })
  templateDisciplineGridCol3: TemplateRef<any>;
  @ViewChild('headTempDisciplines1', { static: true })
  headTempDisciplines1: TemplateRef<any>;
  @ViewChild('headTempDisciplines2', { static: true })
  headTempDisciplines2: TemplateRef<any>;
  @ViewChild('headTempDisciplines3', { static: true })
  headTempDisciplines3: TemplateRef<any>;

  @ViewChild('templateDiseasesGridCol1', { static: true })
  templateDiseasesGridCol1: TemplateRef<any>;
  @ViewChild('templateDiseasesGridCol2', { static: true })
  templateDiseasesGridCol2: TemplateRef<any>;
  @ViewChild('templateDiseasesGridCol3', { static: true })
  templateDiseasesGridCol3: TemplateRef<any>;
  @ViewChild('headTempDiseases1', { static: true })
  headTempDiseases1: TemplateRef<any>;
  @ViewChild('headTempDiseases2', { static: true })
  headTempDiseases2: TemplateRef<any>;
  @ViewChild('headTempDiseases3', { static: true })
  headTempDiseases3: TemplateRef<any>;

  // hãy code vào đây nếu bạn là người fix bug - chứ ở trên tui không biết họ đang code cái gì
  payrollFM: FormModel = null; // THÔNG TIN TÍNH LƯƠNG

  constructor(
    private inject: Injector,
    private routeActive: ActivatedRoute,
    private hrService: CodxHrService,
    private share: CodxShareService,
    private auth: AuthStore,
    private df: ChangeDetectorRef,
    private layout: LayoutService,
    private pageTitle: PageTitleService,
    private callfunc: CallFuncService,
    private notify: NotificationsService,
    public override api: ApiHttpService,
    private notifySvr: NotificationsService
  ) {
    super(inject);
    this.funcID = 'WSHREM'
    this.user = this.auth.get();
    console.log('this.auth.get();',this.user);

  }

  //#region Create dataservice
  edocumentCRUD: CRUDService = null;
  eFamilyCRUD: CRUDService = null;
  eExperiencesCRUD: CRUDService = null;
  //#endregion


  TESTMODEL: FormModel;
  // formModel:FormModel;


  onInit(): void {
    //ẩn logo
    this.layout.setLogo(null);
    //ẩn số đếm tổng nhân viên
    this.pageTitle.setBreadcrumbs([]);
    if (this.funcID) {
      this.hrService.getFunctionList(this.funcID).subscribe((res) => {
        this.lstTab = res;
        for (let i = 0; i < res.length; i++) {
          switch (res[i].url) {
            case this.dashBoardURL:
              this.dashBoardID = res[i].functionID;
              this.dashBoardURL = res[i];
              break;

            case this.curriculumVitaeURL:
              this.curriculumVitaeFuncID = res[i].functionID;
              this.curriculumVitaeFunc = res[i];
              break;

            case this.JobProcessURL:
              this.JobProcessID = res[i].functionID;
              this.JobProcessURL = res[i];
              break;


            case this.rewardCatalogURL:
              this.rewardCatalogID = res[i].functionID;
              this.rewardCatalogURL = res[i];
              break;

            case this.benefitInfoURL:
              this.benefitInfoID = res[i].functionID;
              this.benefitInfoURL = res[i];
              break;

            case this.EducationURL:
              this.EducationID = res[i].functionID;
              this.EducationURL = res[i];
              break;

            //5 Thông tin pháp lý
            case this.legalInfoURL:
              this.legalInfoFuncID = res[i].functionID;
              this.legalInfoFunc = res[i];
              break;

            // case this.jobInfoURL:
            //   this.jobInfoFuncID = res[i].functionID;
            //   this.jobInfoFunc = res[i];
            //   break;
            // case this.salaryBenefitInfoURL:
            //   this.salaryBenefitInfoFuncID = res[i].functionID;
            //   this.salaryBenefitInfoFunc = res[i];
            //   break;




            // case this.workingProcessInfoURL:
            //   this.workingProcessInfoFuncID = res[i].functionID;
            //   this.workingProcessInfoFunc = res[i];
            //   break;
            // case this.knowledgeInfoURL:
            //   this.knowledgeInfoFuncID = res[i].functionID;
            //   this.knowledgeInfoFunc = res[i];
            //   break;
            // case this.healthInfoURL:
            //   this.healthInfoFuncID = res[i].functionID;
            //   this.healthInfoFunc = res[i];
            //   break;
            // case this.quitJobInfoURL:
            //   this.quitJobInfoFuncID = res[i].functionID;
            //   this.quitJobInfoFunc = res[i];
            //   break;
          }
        }
        this.clickTab(this.lstTab[0]);
      });
    }
    this.routeActive.queryParams.subscribe((params) => {
      if (this.crrFuncTab) {
        this.clickTab({ functionID: this.crrFuncTab });
      }

      this.myEmployeeID = this.user['employee'].employeeID;
      this.loadEmpFullInfo(this.myEmployeeID).subscribe((res) => {
        if (res) {
          this.myInfoPersonal = res[0];
          this.getManagerEmployeeInfoById();
          this.myInfoPersonal.PositionName = res[1];
          // this.lstOrg = res[2]
          this.orgUnitStr = res[2];
          this.DepartmentStr = res[3];
          this.LoadedEInfo = true;
          this.df.detectChanges();
        }
      })
      this.pageNum = params['page'];
      if (!!params['employeeID2']) {
        this.employeeID = params['employeeID2'];
        this.loadEmpFullInfo(this.employeeID).subscribe((res) => {
          if (res) {
            this.infoPersonal = res[0];
            this.getManagerEmployeeInfoById();
            this.infoPersonal.PositionName = res[1];
            // this.lstOrg = res[2]
            this.orgUnitStr = res[2];
            this.DepartmentStr = res[3];
            this.LoadedEInfo = true;
            this.df.detectChanges();
          }
        });
      }
      else {
        this.employeeID = this.user['employee'].employeeID
        this.employeeID2 = params['employeeID2'];

        this.loadEmpFullInfo(this.employeeID).subscribe((res) => {
          if (res) {
            this.infoPersonal = res[0];
            this.getManagerEmployeeInfoById();
            this.infoPersonal.PositionName = res[1];
            this.orgUnitStr = res[2];
            this.DepartmentStr = res[3];
            this.LoadedEInfo = true;
            this.df.detectChanges();
          }
        });
      }
    });
    // this.initFormModel();
    this.initSortModel();
    this.initHeaderText();

  }

  ngAfterViewInit(): void {

    this.views = [
      {
        type: ViewType.content,
        active: true,
        model: {
          panelRightRef: this.panelContent,
        },
      },
    ];
    this.formModel = this.view.formModel;
  }

  // handleShowHideMfWs(evt, func) {
  //   if (func.isPortal == false) {
  //     //Được add/edit, ko delete
  //     for (let i = 0; i < evt.length; i++) {
  //       if (evt[i].functionID == 'SYS02') {
  //         evt[i].disabled = true;
  //       }
  //     }
  //   }

  //   if (func.isPortal == true || this.infoPersonal.status == '90') {
  //     //Hide edit/copy/delete more func
  //     for (let i = 0; i < evt.length; i++) {
  //       if (
  //         evt[i].functionID == 'SYS02' ||
  //         evt[i].functionID == 'SYS03' ||
  //         evt[i].functionID == 'SYS01' ||
  //         evt[i].functionID == 'SYS04'
  //       ) {
  //         evt[i].disabled = true;
  //       }
  //     }
  //   }
  // }

  // eInfoHeaderText: any = null;
  // initFormModel() {
  //   this.hrService.getFormModel(this.eAssetFuncID).then((res) => {
  //     this.eAssetFormModel = res;
  //     this.cache
  //       .gridViewSetup(
  //         this.eAssetFormModel.formName,
  //         this.eAssetFormModel.gridViewName
  //       )
  //       .subscribe((res) => {
  //         this.eAssetGrvSetup = res;
  //         let dataRequest = new DataRequest();
  //         dataRequest.comboboxName = res.AssetCategory.referedValue;
  //         dataRequest.pageLoading = false;

  //         this.hrService.loadDataCbx('HR', dataRequest).subscribe((data) => {
  //           this.AssetColorValArr = JSON.parse(data[0]);
  //         });
  //       });
  //   });
  // }

  // handleShowHideMF(evt, func?) {
  //   for (let i = 0; i < evt.length; i++) {
  //     if (evt[i].functionID == 'SYS04') {
  //       evt[i].disabled = true;
  //       break;
  //     }
  //   }
  //   if (
  //     (func == this.eNeedToSubmitProfileFunc && this.fromWS == true) ||
  //     this.infoPersonal.status == '90'
  //   ) {
  //     this.handleShowHideMfWs(evt, func);
  //   }
  // }

  // viewGridDetail(data, funcID) {
  //   switch (funcID) {
  //     case this.appointionFuncID:
  //       // Phải gán cứng vì hệ thống không có morefunc xem chi tiết nên không lấy action text như add và edit được
  //       this.HandleEmployeeAppointionInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.dayoffFuncID:
  //       this.HandleEmployeeDayOffInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eBusinessTravelFuncID:
  //       this.HandleEBusinessTravel('Xem chi tiết', 'view', data);
  //       break;
  //     case this.awardFuncID:
  //       this.HandleEmployeeEAwardsInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eDisciplineFuncID:
  //       this.HandleEmployeeEDisciplinesInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eDegreeFuncID:
  //       this.HandleEmployeeEDegreeInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eCertificateFuncID:
  //       this.HandleEmployeeECertificateInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eSkillFuncID:
  //       this.HandleEmployeeESkillsInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eTrainCourseFuncID:
  //       this.HandleEmployeeTrainCourseInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eAccidentsFuncID:
  //       this.HandleEmployeeAccidentInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eDiseasesFuncID:
  //       this.HandleEmployeeEDiseasesInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eHealthFuncID:
  //       this.HandleEmployeeEHealths('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eVaccinesFuncID:
  //       this.HandleEVaccinesInfo('Xem chi tiết', 'view', data);
  //       break;
  //   }
  // }

  //New nhtrung update here

  //Khen thưởng - kỷ luật grid
  initEmpAward() {
    if (!this.eAwardColumnGrid) {
      this.eAwardColumnGrid = [
        {
          // headerText: this.eAwardHeaderTexts['DecisionNo'],
          headerTemplate: this.headeEAwardsCol1,
          template: this.templateEAwardGridCol1,
          width: '25%',
        },
        {
          // headerText: this.eAwardHeaderTexts['AwardDate'],
          headerTemplate: this.headeEAwardsCol2,
          template: this.templateEAwardGridCol2,
          width: '25%',
        },
        {
          // headerText: this.eAwardHeaderTexts['AwardCode'],
          headerTemplate: this.headeEAwardsCol3,
          template: this.templateEAwardGridCol3,
          width: '25%',
        },
        {
          // headerText: this.eAwardHeaderTexts['Amount'],
          headerTemplate: this.headeEAwardsCol4,
          template: this.templateEAwardGridCol4,
          width: '25%',
        }
      ];

      this.df.detectChanges();

      // });



    }
    this.df.detectChanges();

    if (!this.eDisciplinaryColumnGrid) {
      this.eDisciplinaryColumnGrid = [
        {
          // headerText: this.eDisciplinaryHeaderTexts['DecisionNo'],
          headerTemplate: this.headeEDisciplinaryCol1,
          template: this.templateEDisciplinaryCol1,
          width: '25%',
        },
        {
          // headerText: this.eDisciplinaryHeaderTexts['DisciplinaryDate'],
          headerTemplate: this.headeEDisciplinaryCol2,
          template: this.templateEDisciplinaryCol2,
          width: '25%',
        },
        {
          // headerText: this.eDisciplinaryHeaderTexts['DisciplinaryCode'],
          headerTemplate: this.headeEDisciplinaryCol3,
          template: this.templateEDisciplinaryCol3,
          width: '25%',
        },
        {
          // headerText: this.eDisciplinaryHeaderTexts['Amount'],
          headerTemplate: this.headeEDisciplinaryCol4,
          template: this.templateEDisciplinaryCol4,
          width: '25%',
        }
      ];

      //   this.df.detectChanges();

      // });



    }
    this.df.detectChanges();


  };


  //Hồ sơ năng lực
  initEmpEducation() {
    if (!this.eSpecializationColumnGrid) {
      this.hrService.getHeaderText('WSHREM0601').then((res) => {
        this.eSpecializationHeaderTexts = res;
        this.eSpecializationColumnGrid = [
          {
            headerText: 'Tên chuyên nghành',
            template: this.templateESpecializationCol1,
            width: '25%',
          },
          {
            headerText: this.eSpecializationHeaderTexts['TrSupplierCode'],
            template: this.templateESpecializationCol2,
            width: '25%',
          },
          {
            headerText: 'Thời gian đào tạo',
            template: this.templateESpecializationCol3,
            width: '25%',
          },
          {
            headerText: this.eSpecializationHeaderTexts['YearGraduated'],
            template: this.templateESpecializationCol4,
            width: '25%',
          }
        ];

      });
      // this.df.detectChanges();

    }

    if (!this.eCertificateColumnGrid) {
      this.hrService.getHeaderText(this.eCertificateFuncID).then((res) => {
        this.eCertificateHeaderTexts = res;
        console.log('this.eCertificateHeaderText', this.eCertificateHeaderTexts)
        this.eCertificateColumnGrid = [
          {
            headerText: 'Tên chứng chỉ',
            template: this.templateECertificateCol1,
            width: '25%',
          },
          {
            headerText: this.eCertificateHeaderTexts['TrSupplierCode'] + '|' + this.eCertificateHeaderTexts['Rank'],
            template: this.templateECertificateCol2,
            width: '25%',
          },
          {
            headerText: 'Thời gian đào tạo',
            template: this.templateECertificateCol3,
            width: '25%',
          },
          {
            headerText: this.eCertificateHeaderTexts['CerIssuedDate'],
            template: this.templateECertificateCol4,
            width: '25%',
          }
        ];
        this.df.detectChanges();


      });
      // this.df.detectChanges();

    }

    if (!this.eTrainColumnGrid) {
      this.hrService.getHeaderText(this.eTrainFuncID).then((res) => {
        this.eTrainHeaderTexts = res;
        console.log('this.eTrainHeaderTexts', this.eTrainHeaderTexts)
        this.eTrainColumnGrid = [
          {
            headerText: 'Tên chứng chỉ',
            template: this.templateETrainCol1,
            width: '25%',
          },
          {
            headerText: 'Nơi đào tạo | Xếp hạng',
            template: this.templateETrainCol2,
            width: '25%',
          },
          {
            headerText: 'Thời gian đào tạo',
            template: this.templateETrainCol3,
            width: '25%',
          },
          {
            headerText: 'Ngày hiệu lực',
            template: this.templateETrainCol4,
            width: '25%',
          }
        ];

      });
      // this.df.detectChanges();

    }

    if (!this.eEvaluationColumnGrid) {
      this.hrService.getHeaderText(this.eEvaluationFuncID).then((res) => {
        this.eEvaluationHeaderTexts = res;
        this.eEvaluationColumnGrid = [
          {
            headerText: 'Năm đánh giá',
            template: this.templateEEvaluationCol1,
            width: '25%',
          },
          {
            headerText: 'Kỳ',
            template: this.templateEEvaluationCol2,
            width: '25%',
          },
          {
            headerText: 'Điểm | Xếp loại',
            template: this.templateEEvaluationCol3,
            width: '25%',
          },
          {
            headerText: 'Nhận xét',
            template: this.templateEEvaluationCol4,
            width: '25%',
          }
        ];

      });
      // this.df.detectChanges();

    }

  };

  //Qúa trình làm việc
  initEmpJobProcess() {
    if (!this.ePromoColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.ePromoColumnGrid = [
        {
          // headerText: 'Loại quyết định',
          headerTemplate: this.headeEPromoCol1,
          template: this.templateEPromoCol1,
          width: '15%',
        },
        {
          // headerText: 'Số quyết định',
          headerTemplate: this.headeEPromoCol2,
          template: this.templateEPromoCol2,
          width: '20%',
        },
        {
          // headerText: 'Ngày hiệu lực',
          headerTemplate: this.headeEPromoCol3,
          template: this.templateEPromoCol3,
          width: '15%',
        },
        {
          // headerText: 'Đến Ngày',
          headerTemplate: this.headeEPromoCol4,
          template: this.templateEPromoCol4,
          width: '15%',
        },
        {
          // headerText: 'Bộ phận',
          headerTemplate: this.headeEPromoCol5,
          template: this.templateEPromoCol5,
          width: '15%',
        },
        {
          // headerText: 'Chức danh',
          headerTemplate: this.headeEPromoCol6,
          template: this.templateEPromoCol6,
          width: '20%',
        }
      ];

      // });
      // this.df.detectChanges();

    }

    if (!this.eLeaveColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.eLeaveColumnGrid = [
        {
          // headerText: 'Loại nghỉ',
          headerTemplate: this.headeELeaveCol1,
          template: this.templateELeaveCol1,
          width: '10%',
        },
        {
          // headerText: 'Từ ngày',
          headerTemplate: this.headeELeaveCol2,
          template: this.templateELeaveCol2,
          width: '10%',
        },
        {
          // headerText: 'Đến ngày'
          headerTemplate: this.headeELeaveCol3,
          template: this.templateELeaveCol3,
          width: '10%',
        },
        {
          // headerText: 'Số ngày nghỉ',
          headerTemplate: this.headeELeaveCol4,
          template: this.templateELeaveCol4,
          width: '15%',
        },
        {
          // headerText: 'Tổng ngày trừ',
          headerTemplate: this.headeELeaveCol5,
          template: this.templateELeaveCol5,
          width: '15%',
        },
        {
          // headerText: 'Lý do',
          headerTemplate: this.headeELeaveCol6,
          template: this.templateELeaveCol6,
          width: '25%',
        }
        ,
        {
          // headerText: 'Năm trừ phép',
          headerTemplate: this.headeELeaveCol7,
          template: this.templateELeaveCol7,
          width: '15%',
        }
      ];

      // });
      this.df.detectChanges();

    }
  };

  //Thân nhân
  initEmpFamily() {
    console.log('check in here');
    if (!this.eFamilyColumnGrid) {
      // this.hrService.getHeaderText(this.eInfoFuncID).then((res) => {
      // this.eSkillHeaderText = res;
      this.eFamilyColumnGrid = [
        {
          // headerText: 'Họ và tên',
          // headerText: this.eFamilyHeaderTexts['LastName'] + this.eFamilyHeaderTexts['FirstName'],
          headerTemplate: this.headeEFamilyCol1,
          template: this.templateEFamilyCol1,
          width: '30%',
        },
        {
          // headerText: 'Giới tính',
          // headerText: this.eFamilyHeaderTexts['Gender'],
          headerTemplate: this.headeEFamilyCol2,
          template: this.templateEFamilyCol2,
          width: '10%',
        },
        {
          // headerText: 'Ngày sinh',
          // headerText: this.eFamilyHeaderTexts['Birthday'],
          template: this.templateEFamilyCol3,
          headerTemplate: this.headeEFamilyCol3,
          width: '20%',
        },
        {
          // headerText: 'Quan hệ với chủ hộ',
          // headerText: this.eFamilyHeaderTexts['HouseHolderRelCode'],
          template: this.templateEFamilyCol4,
          headerTemplate: this.headeEFamilyCol4,
          width: '20%',
        },
        {
          // headerText: 'Giảm trừ gia cảnh',
          // headerText: this.eFamilyHeaderTexts['IsReduceTax'],
          template: this.templateEFamilyCol5,
          headerTemplate: this.headeEFamilyCol5,
          width: '20%',
        }
      ];

      // });
      this.df.detectChanges();

    }


  };

  //Phúc lợi
  initEmpBenefit() {
    if (!this.eBasicSalaryColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.eBasicSalaryColumnGrid = [
        {
          // headerText: 'Ngày hiệu lực',
          headerTemplate: this.headeEBasicSalaryCol1,
          template: this.templateEBasicSalaryCol1,
          width: '32%',
        },
        {
          // headerText: 'Mức lương',
          headerTemplate: this.headeEBasicSalaryCol2,
          template: this.templateEBasicSalaryCol2,
          width: '32%',
        },
        {
          // headerText: 'Đang hiệu lực',
          headerTemplate: this.headeEBasicSalaryCol3,
          template: this.templateEBasicSalaryCol3,
          width: '32%',
        }
      ];

      // });
      this.df.detectChanges();

    }

    if (!this.eJobSalaryColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.eJobSalaryColumnGrid = [
        {
          headerTemplate: this.headeEJobSalaryCol1,
          template: this.templateEJobSalaryCol1,
          width: '32%',
        },
        {
          // headerText: 'Mức lương',
          headerTemplate: this.headeEJobSalaryCol2,
          template: this.templateEJobSalaryCol2,
          width: '32%',
        },
        {
          // headerText: 'Đang hiệu lực',
          headerTemplate: this.headeEJobSalaryCol3,
          template: this.templateEJobSalaryCol3,
          width: '32%',
        }
      ];

      // });
      this.df.detectChanges();

    }

    if (!this.eAdditionalIncomeColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.eAdditionalIncomeColumnGrid = [
        {
          // headerText: 'Ngày phát sinh',
          headerTemplate: this.headeEAdditionalIncomeCol1,
          template: this.templateEAdditionalIncomeCol1,
          width: '20%',
        },
        {
          // headerText: 'Loại thu nhập',
          headerTemplate: this.headeEAdditionalIncomeCol2,
          template: this.templateEAdditionalIncomeCol2,
          width: '20%',
        },
        {
          // headerText: 'Số tiền',
          headerTemplate: this.headeEAdditionalIncomeCol3,
          template: this.templateEAdditionalIncomeCol3,
          width: '20%',
        },
        {
          // headerText: 'Thuế TNCN',
          headerTemplate: this.headeEAdditionalIncomeCol4,
          template: this.templateEAdditionalIncomeCol4,
          width: '20%',
        }
      ];

      // });
      this.df.detectChanges();

    }

    if (!this.eDeductionColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.eDeductionColumnGrid = [
        {
          // headerText: 'Ngày phát sinh',
          headerTemplate: this.headeEDeductionCol1,
          template: this.templateDeductionCol1,
          width: '20%',
        },
        {
          // headerText: 'Loại thu nhập',
          headerTemplate: this.headeEDeductionCol2,
          template: this.templateDeductionCol2,
          width: '20%',
        },
        {
          // headerText: 'Số tiền',
          headerTemplate: this.headeEDeductionCol3,
          template: this.templateDeductionCol3,
          width: '20%',
        },
        {
          // headerText: 'Tính vào tháng',
          headerTemplate: this.headeEDeductionCol4,
          template: this.templateDeductionCol4,
          width: '20%',
        },
        {
          // headerText: 'Tạm ứng',
          headerTemplate: this.headeEDeductionCol5,
          template: this.templateDeductionCol5,
          width: '20%',
        }
      ];

      // });
      this.df.detectChanges();

    }

    if (!this.eAllowanceColumnGrid) {
      // this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
      //   this.eSkillHeaderText = res;
      this.eAllowanceColumnGrid = [
        {
          // headerText: 'Ngày Hiệu lực',
          headerTemplate: this.headeEAllowanceCol1,
          template: this.templateEAllowanceCol1,
          width: '33%',
        },
        {
          // headerText: 'Số tiền',
          headerTemplate: this.headeEAllowanceCol2,
          template: this.templateEAllowanceCol2,
          width: '33%',
        },
        {
          // headerText: 'Đang hiệu lực',
          headerTemplate: this.headeEAllowanceCol3,
          template: this.templateEAllowanceCol3,
          width: '33%',
        }

      ];

      // });
      this.df.detectChanges();

    }
  }

  //---------------------------------------------NHTRUNG END HERE-----------

  initSortModel() {
    this.dayOffSortModel = new SortModel();
    this.dayOffSortModel.field = 'BeginDate';
    this.dayOffSortModel.dir = 'desc';

    this.assetSortModel = new SortModel();
    this.assetSortModel.field = 'IssuedDate';
    this.assetSortModel.dir = 'desc';

    this.experienceSortModel = new SortModel();
    this.experienceSortModel.field = 'FromDate';
    this.experienceSortModel.dir = 'asc';

    this.businessTravelSortModel = new SortModel();
    this.businessTravelSortModel.field = 'BeginDate';
    this.businessTravelSortModel.dir = 'desc';

    this.benefitSortModel = new SortModel();
    this.benefitSortModel.field = 'EffectedDate';
    this.benefitSortModel.dir = 'desc';

    this.visaSortModel = new SortModel();
    this.visaSortModel.field = 'IssuedDate';
    this.visaSortModel.dir = 'desc';

    this.workPermitSortModel = new SortModel();
    this.workPermitSortModel.field = 'IssuedDate';
    this.workPermitSortModel.dir = 'desc';

    this.passportSortModel = new SortModel();
    this.passportSortModel.field = 'IssuedDate';
    this.passportSortModel.dir = 'desc';

    this.skillIDSortModel = new SortModel();
    this.skillIDSortModel.field = 'SkillID';
    this.skillIDSortModel.dir = 'asc';

    this.skillGradeSortModel = new SortModel();
    this.skillGradeSortModel.field = 'SkillGradeID';
    this.skillGradeSortModel.dir = 'desc';

    this.bSalarySortModel = new SortModel();
    this.bSalarySortModel.field = 'EffectedDate';
    this.bSalarySortModel.dir = 'desc';

    this.issuedDateSortModel = new SortModel();
    this.issuedDateSortModel.field = 'issuedDate';
    this.issuedDateSortModel.dir = 'desc';

    this.TrainFromDateSortModel = new SortModel();
    this.TrainFromDateSortModel.field = 'TrainFromDate';
    this.TrainFromDateSortModel.dir = 'desc';

    this.appointionSortModel = new SortModel();
    this.appointionSortModel.field = 'EffectedDate';
    this.appointionSortModel.dir = 'desc';

    this.eContractSortModel = new SortModel();
    this.eContractSortModel.field = 'EffectedDate';
    this.eContractSortModel.dir = 'desc';

    this.disciplinesSortModel = new SortModel();
    this.disciplinesSortModel.field = 'DisciplineDate';
    this.disciplinesSortModel.dir = 'desc';

    this.injectDateSortModel = new SortModel();
    this.injectDateSortModel.field = '(InjectDate)';
    this.injectDateSortModel.dir = 'desc';

    this.accidentDateSortModel = new SortModel();
    this.accidentDateSortModel.field = '(AccidentDate)';
    this.accidentDateSortModel.dir = 'desc';

    this.diseasesFromDateSortModel = new SortModel();
    this.diseasesFromDateSortModel.field = '(FromDate)';
    this.diseasesFromDateSortModel.dir = 'desc';

    this.healthDateSortModel = new SortModel();
    this.healthDateSortModel.field = '(HealthDate)';
    this.healthDateSortModel.dir = 'desc';

    this.eAwardsSortModel1 = new SortModel();
    this.eAwardsSortModel1.field = 'InYear';
    this.eAwardsSortModel1.dir = 'desc';

    this.eAwardsSortModel2 = new SortModel();
    this.eAwardsSortModel2.field = 'AwardDate';
    this.eAwardsSortModel2.dir = 'desc';
  }

  initHeaderText() {
    this.cache.moreFunction('CoDXSystem', '').subscribe((res) => {
      if (res) {
        if (res[0]) {
          this.addHeaderText = res[0].customName;
        }
        if (res[2]) {
          this.editHeaderText = res[2].customName;
        }
      }
    });
  }

  // clickViewDetail(data, funcID) {
  //   switch (funcID) {
  //     case this.ePassportFuncID:
  //       // Phải gán cứng vì hệ thống không có morefunc xem chi tiết nên không lấy action text như add và edit được
  //       this.handleEmployeePassportInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eVisaFuncID:
  //       this.handleEmployeeVisaInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eWorkPermitFuncID:
  //       this.handleEmployeeWorkingPermitInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eContractFuncID:
  //       this.HandleEContractInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eBasicSalaryFuncID:
  //       this.handleEBasicSalaries('Xem chi tiết', 'view', data);
  //       break;
  //     case this.benefitFuncID:
  //       this.handlEmployeeBenefit('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eFamiliesFuncID:
  //       this.handleEFamilyInfo('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eExperienceFuncID:
  //       this.handlEmployeeExperiences('Xem chi tiết', 'view', data);
  //       break;
  //     case this.eNeedToSubmitProfileFuncID:
  //       this.HandleEDocumentInfo('Xem chi tiết', 'view', data);
  //       break;
  //   }
  // }

  // navChange(evt: any, index: number = -1, btnClick) {
  //   let containerList = document.querySelectorAll('.pw-content');
  //   let lastDivList = document.querySelectorAll('.div_final');
  //   let lastDiv = lastDivList[index];
  //   let container = containerList[index];
  //   let containerHeight = (container as any).offsetHeight;
  //   let contentHeight = 0;
  //   for (let i = 0; i < container.children.length; i++) {
  //     contentHeight += (container.children[i] as any).offsetHeight;
  //   }

  //   if (!evt) return;
  //   let element = document.getElementById(evt);
  //   let distanceToBottom = contentHeight - element.offsetTop;

  //   if (distanceToBottom < containerHeight) {
  //     (lastDiv as any).style.width = '200px';
  //     (lastDiv as any).style.height = `${
  //       containerHeight - distanceToBottom + 50
  //     }px`;
  //   }

  //   if (index > -1) {
  //     this.active[index] = evt;
  //     this.detectorRef.detectChanges();
  //   }
  //   element.scrollIntoView({
  //     behavior: 'smooth',
  //     block: 'start',
  //     inline: 'nearest',
  //   });
  //   this.isClick = true;
  //   this.detectorRef.detectChanges();
  //   setTimeout(() => {
  //     this.isClick = false;
  //     return;
  //   }, 500);
  // }

  // onSectionChange(data: any, index: number = -1) {
  //   if (index > -1 && this.isClick == false) {
  //     this.active[index] = data;
  //     this.detectorRef.detectChanges();
  //   }
  // }

  getEmpCurrentData() {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmployeesBusiness_Old',
      'GetEmpCurrentInfoAsync',
      this.employeeID
    );
  }

  // loadEmpFullInfo(empID) {
  //   return this.api.execSv<any>(
  //     'HR',
  //     'HR',
  //     'EmployeesBusiness_Old',
  //     'GetEmpFullInfoAsync',
  //     empID
  //   );
  // }

  loadEmpFullInfo(empID) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EmployeesBusiness_Old',
      'GetEmpFullInfoAsync',
      empID
    );
  }



  empContact: any;
  getContactCurrentUser() {
    // if (this.infoPersonal?.lineManager) {
    let empRequest = new DataRequest();
    empRequest.entityName = 'HR_EmpContract';
    empRequest.dataValues = this.employeeID2 != undefined ? this.employeeID2 : this.employeeID;
    empRequest.predicates = 'EmployeeID=@0';
    empRequest.pageLoading = false;
    this.hrService.loadData('HR', empRequest).subscribe((res: any) => {
      // if (Array.isArray(res) && res[1] > 0) {
      //   this.lineManager = res[0][0];
      //   this.loadedLineManager = true;
      //   this.df.detectChanges();
      // }


    });
  }
  // else {
  //   this.loadedLineManager = true;
  //   this.df.detectChanges();
  // }
  // if (this.infoPersonal?.indirectManager) {
  //   let empRequest = new DataRequest();
  //   empRequest.entityName = 'HR_Employees';
  //   empRequest.dataValues = this.infoPersonal.indirectManager;
  //   empRequest.predicates = 'EmployeeID=@0';
  //   empRequest.pageLoading = false;
  //   this.hrService.loadData('HR', empRequest).subscribe((emp) => {
  //     if (emp[1] > 0) {
  //       this.indirectManager = emp[0][0];
  //       this.loadedIndirectManager = true;
  //       this.df.detectChanges();
  //     }
  //   });
  // } else {
  //   this.loadedIndirectManager = true;
  //   this.df.detectChanges();
  // }
  // }

  initEmpSalary() {
    if (this.employeeID) {
    }
  }



  initEmpKnowledge() {
    if (!this.eDegreeColumnsGrid) {
      this.hrService.getHeaderText(this.eDegreeFuncID).then((res) => {
        this.eDegreeHeaderText = res;
        this.eDegreeColumnsGrid = [
          {
            headerTemplate: this.headTempDegree1,
            template: this.templateEDegreeGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempDegree2,
            template: this.templateEDegreeGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempDegree3,
            template: this.templateEDegreeGridCol3,
            width: '150',
          },
        ];

      });

      console.log('grid', this.eDegreeColumnsGrid)


      this.df.detectChanges();
    }

    if (!this.eCertificateColumnGrid) {
      this.hrService.getHeaderText(this.eCertificateFuncID).then((res) => {
        this.eCertificateHeaderText = res;
        this.eCertificateColumnGrid = [
          {
            headerTemplate: this.headTempCertificate1,
            template: this.templateECertificateGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempCertificate2,
            template: this.templateECertificateGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempCertificate3,
            template: this.templateECertificateGridCol3,
            width: '150',
          },
        ];
      });
    }

    if (!this.eSkillColumnGrid) {
      this.hrService.getHeaderText(this.eSkillFuncID).then((res) => {
        this.eSkillHeaderText = res;
        this.eSkillColumnGrid = [
          {
            headerTemplate: this.headTempSkill1,
            template: this.templateESkillGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempSkill2,
            template: this.templateESkillGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempSkill3,
            template: this.templateESkillGridCol3,
            width: '150',
          },
        ];
      });
      this.df.detectChanges();
    }

    if (!this.eTrainCourseColumnGrid) {
      if (!this.eTrainCourseColumnGrid) {
        this.hrService.getHeaderText(this.eTrainCourseFuncID).then((res) => {
          this.eTrainCourseHeaderText = res;
          this.eTrainCourseColumnGrid = [
            {
              headerTemplate: this.headTempTrainCourse1,
              template: this.templateTrainCourseGridCol1,
              width: '150',
            },
            {
              headerTemplate: this.headTempTrainCourse2,
              template: this.templateTrainCourseGridCol2,
              width: '150',
            },
            {
              headerTemplate: this.headTempTrainCourse3,
              template: this.templateTrainCourseGridCol3,
              width: '150',
            },
          ];
        });
      }
    }
  }

  initEmpHealth() {
    if (!this.eAccidentsColumnsGrid) {
      this.hrService.getHeaderText(this.eAccidentsFuncID).then((res) => {
        this.eAccidentHeaderText = res;
        this.eAccidentsColumnsGrid = [
          {
            headerTemplate: this.headTempAccident1,
            template: this.templateEAccidentCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempAccident2,
            template: this.templateEAccidentCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempAccident3,
            template: this.templateEAccidentCol3,
            width: '150',
          },
        ];
      });
      //#endregion
    }

    if (!this.eDiseasesColumnsGrid) {
      this.hrService.getHeaderText(this.eDiseasesFuncID).then((res) => {
        this.eDiseasesHeaderText = res;
        this.eDiseasesColumnsGrid = [
          {
            headerTemplate: this.headTempDiseases1,
            template: this.templateDiseasesGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempDiseases2,
            template: this.templateDiseasesGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempDiseases3,
            template: this.templateDiseasesGridCol3,
            width: '150',
          },
        ];
      });
    }

    if (!this.eHealthColumnGrid) {
      this.hrService.getHeaderText(this.eHealthFuncID).then((res) => {
        this.eHealthHeaderText = res;
        this.eHealthColumnGrid = [
          {
            headerTemplate: this.headTempHealth1,
            template: this.tempCol1EHealthGrid,
            width: '150',
          },

          {
            headerTemplate: this.headTempHealth2,
            template: this.tempCol2EHealthGrid,
            width: '150',
          },

          {
            headerTemplate: this.headTempHealth3,
            template: this.tempCol3EHealthGrid,
            width: '150',
          },
        ];
      });
    }

    if (!this.eVaccineColumnGrid) {
      this.hrService.getHeaderText(this.eVaccinesFuncID).then((res) => {
        this.eVaccineHeaderText = res;
        this.eVaccineColumnGrid = [
          {
            headerTemplate: this.headTempVaccine1,
            template: this.tempEVaccineGridCol1,
            width: '150',
          },

          {
            headerTemplate: this.headTempVaccine2,
            template: this.tempEVaccineGridCol2,
            width: '150',
          },

          {
            headerTemplate: this.headTempVaccine3,
            template: this.tempEVaccineGridCol3,
            width: '150',
          },
        ];
      });
    }
  }

  //xem lai
  getECurrentContract() {
    let date = new Date();
    let rqContract = new DataRequest();
    rqContract.entityName = 'HR_EContracts';
    rqContract.dataValues =
      this.employeeID + ';false;' + `${date.toISOString()}`;
    rqContract.predicates =
      'EmployeeID=@0 and IsAppendix=@1 and EffectedDate<=@2 and ExpiredDate>=@2';
    rqContract.page = 1;
    rqContract.pageSize = 1;

    this.hrService.loadData('HR', rqContract).subscribe((res) => {
      if (res && res[0]) {
        this.crrEContract = res[0][0];
      } else {
        this.crrEContract = null;
      }
      this.df.detectChanges();
    });
  }

  deleteFile(data, formModel) {
    return this.api.execSv(
      'DM',
      'ERM.Business.DM',
      'FileBussiness',
      'DeleteByObjectIDAsync',
      [data.recID, formModel.entityName, true]
    );
  }

  initEmpProcess() {
    if (!this.appointionColumnGrid) {
      this.hrService.getHeaderText(this.appointionFuncID).then((res) => {
        this.appointionHeaderTexts = res;
        this.appointionColumnGrid = [
          {
            headerTemplate: this.headTempAppointion1,
            template: this.templateAppointionGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempAppointion2,
            template: this.templateAppointionGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempAppointion3,
            template: this.templateAppointionGridCol3,
            width: '150',
          },
        ];
      });
    }

    if (!this.dayoffColumnGrid) {
      this.hrService.getHeaderText(this.dayoffFuncID).then((res) => {
        this.dayoffHeaderTexts = res;
        this.dayoffColumnGrid = [
          {
            headerTemplate: this.headTempDayOff1,
            template: this.templateDayOffGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempDayOff2,
            template: this.templateDayOffGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempDayOff3,
            template: this.templateDayOffGridCol3,
            width: '150',
          },
        ];
      });
    }

    if (!this.businessTravelColumnGrid) {
      this.hrService.getHeaderText(this.eBusinessTravelFuncID).then((res) => {
        this.eBusinessTravelHeaderTexts = res;
        this.businessTravelColumnGrid = [
          {
            headerTemplate: this.headTempBusinessTravel1,
            template: this.templateBusinessTravelGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempBusinessTravel2,
            template: this.templateBusinessTravelGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempBusinessTravel3,
            template: this.templateBusinessTravelGridCol3,
            width: '150',
          },
        ];
      });
    }

    if (!this.awardColumnsGrid) {
      this.hrService.getHeaderText(this.awardFuncID).then((res) => {
        this.awardHeaderText = res;
        this.awardColumnsGrid = [
          {
            headerTemplate: this.headTempAwards1,
            template: this.templateAwardGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempAwards2,

            template: this.templateAwardGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempAwards3,
            template: this.templateAwardGridCol3,
            width: '150',
          },
        ];
      });
    }

    if (!this.eDisciplineColumnsGrid) {
      this.hrService.getHeaderText(this.eDisciplineFuncID).then((res) => {
        this.eDisciplineHeaderText = res;
        this.eDisciplineColumnsGrid = [
          {
            headerTemplate: this.headTempDisciplines1,

            template: this.templateDisciplineGridCol1,
            width: '150',
          },
          {
            headerTemplate: this.headTempDisciplines2,

            template: this.templateDisciplineGridCol2,
            width: '150',
          },
          {
            headerTemplate: this.headTempDisciplines3,
            template: this.templateDisciplineGridCol3,
            width: '150',
          },
        ];
      });
    }
  }

  UpdateDataOnGrid(gridView: CodxGridviewV2Component, lst, prdc, dtvl) {
    (gridView.predicates = prdc),
      (gridView.dataValues = dtvl),
      (gridView.dataSource = lst);
  }

  checkIsNewestDate(effectedDate, expiredDate) {
    if (effectedDate) {
      let eff = new Date(effectedDate).toLocaleDateString();
      let date = new Date().toLocaleDateString();
      if (expiredDate) {
        let expire = new Date(expiredDate).toLocaleDateString();
        if (
          new Date(date) >= new Date(eff) &&
          new Date(date) <= new Date(expire)
        ) {
          return true;
        }
        return false;
      } else {
        if (new Date(date) >= new Date(eff)) {
          return true;
        }
        return false;
      }
    }
    return true;
  }

  
  

  popupViewAllContract() {
    debugger;
    let opt = new DialogModel();
    opt.zIndex = 999;
    let popup = this.callfunc.openForm(
      PopupViewAllComponent,
      null,
      850,
      550,
      this.eContractFuncID,
      {
        quitjobStatus: this.infoPersonal.status,
        func: this.eContractFunc,
        funcUrl: this.eContractURL,
        fromWS: this.fromWS,
        funcID: this.eContractFuncID,
        employeeId: this.employeeID,
        headerText: this.transText(this.eContractFuncID, this.lstFuncHRProcess),
        sortModel: this.eContractSortModel,
        formModel: this.eContractFormModel,
        hasFilter: false,
      },
      null,
      opt
    );
    popup.closed.subscribe((res) => {
      if (res?.event) {
        if (res?.event == 'none') {
          this.crrEContract = null;
        } else {
          this.crrEContract = res.event;
        }
        this.df.detectChanges();
      }
    });
  }

  popupViewAllWorkPermit() {
    let opt = new DialogModel();
    opt.zIndex = 999;
    let popup = this.callfunc.openForm(
      PopupViewAllComponent,
      null,
      850,
      550,
      this.eWorkPermitFuncID,
      {
        quitjobStatus: this.infoPersonal.status,
        func: this.eWorkPermitFunc,
        funcUrl: this.eWorkPermitURL,
        fromWS: this.fromWS,
        funcID: this.eWorkPermitFuncID,
        employeeId: this.employeeID,
        headerText: this.transText(
          this.eWorkPermitFuncID,
          this.lstFuncForeignWorkerInfo
        ),
        sortModel: this.workPermitSortModel,
        formModel: this.eWorkPermitFormModel,
        hasFilter: false,
      },
      null,
      opt
    );
    popup.closed.subscribe((res) => {
      if (res?.event) {
        if (res?.event == 'none') {
          this.crrWorkpermit = null;
          this.workpermitIsExpired =
            this.currentDate.toISOString() >
            new Date(this.crrWorkpermit?.toDate).toISOString();
        } else {
          this.crrWorkpermit = res.event;
          this.workpermitIsExpired =
            this.currentDate.toISOString() >
            new Date(this.crrWorkpermit?.toDate).toISOString();
        }
        this.df.detectChanges();
      }
    });
  }

  popupViewAllVisa() {
    let opt = new DialogModel();
    opt.zIndex = 999;
    let popup = this.callfunc.openForm(
      PopupViewAllComponent,
      null,
      850,
      550,
      this.eVisaFuncID,
      {
        quitjobStatus: this.infoPersonal.status,
        func: this.eVisaFunc,
        funcUrl: this.eVisaURL,
        fromWS: this.fromWS,
        funcID: this.eVisaFuncID,
        employeeId: this.employeeID,
        headerText: this.transText(this.eVisaFuncID, this.lstFuncLegalInfo),
        sortModel: this.visaSortModel,
        formModel: this.eVisaFormModel,
        hasFilter: false,
      },
      null,
      opt
    );
    popup.closed.subscribe((res) => {
      if (res?.event) {
        if (res?.event == 'none') {
          this.crrVisa = null;
          this.visaIsExpired =
            this.currentDate.toISOString() >
            new Date(this.crrVisa.expiredDate).toISOString();
        } else {
          this.crrVisa = res.event;
          this.visaIsExpired =
            this.currentDate.toISOString() >
            new Date(this.crrVisa.expiredDate).toISOString();
        }
        this.df.detectChanges();
      }
    });
  }

  popupViewAllPassport() {
    let opt = new DialogModel();
    opt.zIndex = 999;
    let popup = this.callfunc.openForm(
      PopupViewAllComponent,
      null,
      850,
      550,
      this.ePassportFuncID,
      {
        quitjobStatus: this.infoPersonal.status,
        func: this.ePassportFunc,
        funcUrl: this.ePassportURL,
        fromWS: this.fromWS,
        funcID: this.ePassportFuncID,
        employeeId: this.employeeID,
        headerText: this.transText(this.ePassportFuncID, this.lstFuncLegalInfo),
        sortModel: this.passportSortModel,
        formModel: this.ePassportFormModel,
        hasFilter: false,
      },
      null,
      opt
    );
    popup.closed.subscribe((res) => {
      if (res?.event) {
        if (res?.event == 'none') {
          this.crrPassport = null;
          this.passPortIsExpired =
            this.currentDate.toISOString() >
            new Date(this.crrPassport?.expiredDate).toISOString();
        } else {
          this.crrPassport = res.event;
          this.passPortIsExpired =
            this.currentDate.toISOString() >
            new Date(this.crrPassport?.expiredDate).toISOString();
        }
        this.df.detectChanges();
      }
    });
  }

  clickTab(funcList: any) {
    this.crrFuncTab = funcList.functionID;
    this.hrService.getFunctionList(this.crrFuncTab).subscribe((res) => {
      switch (this.crrFuncTab) {
        case this.dashBoardID:
          break;
        case this.legalInfoFuncID:
          for (let i = 0; i < res.length; i++) {
            if (res[i].url == this.eBankURL) {
              this.eBankFuncID = res[i].functionID;
              this.eBankFunc = res[i];

              if (!this.eInfoFormModel) {
                this.hrService.getFormModel('WSHREM').then((res) => {
                  this.eInfoFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eInfoFormModel.formName,
                      this.eInfoFormModel.gridViewName,
                      this.eInfoFormModel
                    )
                    .then((fg) => {
                      this.eInfoFormGroup = fg;
                      this.eInfoFormGroup.patchValue(this.infoPersonal);
                      this.eInfoFormModel.currentData = this.infoPersonal;
                    });
                });
              }

              if (!this.eBankHeaderTexts || !this.eBankFormModel) {
                this.hrService
                  .getFormModel(this.eBankFuncID)
                  .then((res) => {
                    this.eBankFormModel = res;
                    console.log('this.eBankFormModel', this.eBankFormModel)
                  });

                this.hrService
                  .getHeaderText(this.eBankFuncID)
                  .then((res) => {
                    this.eBankHeaderTexts = res;
                  });


              }
            }
            else if (res[i].url == this.eContractURL) {
              this.eContractFuncID = res[i].functionID;
              this.eContractFunc = res[i];

              if (!this.eContractHeaderTexts || !this.eContractFormModel) {
                this.hrService
                  .getFormModel(this.eContractFuncID)
                  .then((res) => {
                    this.eContractFormModel = res;
                  });

                this.hrService
                  .getHeaderText(this.eContractFuncID)
                  .then((res) => {
                    this.eContractHeaderTexts = res;
                  });


              }
            }
            else if (res[i].url == this.eGroupInfoURL) {
              this.eGroupInfoFuncID = res[i].functionID;
              this.eGroupInfoFunc = res[i];

              // if (!this.eContractHeaderTexts || !this.eContractFormModel) {
              //   this.hrService
              //     .getFormModel(this.eContractFuncID)
              //     .then((res) => {
              //       this.eContractFormModel = res;
              //     });

              //   this.hrService
              //     .getHeaderText(this.eContractFuncID)
              //     .then((res) => {
              //       this.eContractHeaderTexts = res;
              //     });


              // }
            }
            else if (res[i].url == this.eInsuranceURL) {
              this.eInsuranceFuncID = res[i].functionID;
              this.eInsuranceFunc = res[i];

              // if (!this.eContractHeaderTexts || !this.eContractFormModel) {
              //   this.hrService
              //     .getFormModel(this.eContractFuncID)
              //     .then((res) => {
              //       this.eContractFormModel = res;
              //     });

              //   this.hrService
              //     .getHeaderText(this.eContractFuncID)
              //     .then((res) => {
              //       this.eContractHeaderTexts = res;
              //     });


              // }
            }
          }
          this.lstlegalInfo = res;

          this.getContactCurrentUser()

          break;
        case this.JobProcessID:
          for (let i = 0; i < res.length; i++) {
            if (res[i].url == this.eWorkingURL) {
              this.eWorkingFuncID = res[i].functionID;
              this.eWorkingFunc = res[i];

              if (!this.eWorkingHeaderTexts || !this.eWorkingFormModel) {
                this.hrService
                  .getFormModel(this.eWorkingFuncID)
                  .then((res) => {
                    this.eWorkingFormModel = res;

                    this.cache
                      .gridViewSetup(
                        this.eWorkingFormModel.formName,
                        this.eWorkingFormModel.gridViewName
                      )
                      .subscribe((res) => {
                        this.eWorkingGrvSetUp = res;
                        console.log('this.eWorkingGrvSetUp', this.eWorkingGrvSetUp)
                      })

                  });

                this.hrService
                  .getHeaderText(this.eWorkingFuncID)
                  .then((res) => {
                    this.eWorkingHeaderTexts = res;
                  });


              }

              // if (!this.gridViewSetupWorking) {
              //   this.cache
              //     .gridViewSetup(this.eWorkingFormModel.formName, this.eWorkingFormModel.gridViewName)
              //     .subscribe((res) => {
              //       if (res) {
              //         // this.gridViewSetup = res;
              //         this.gridViewSetupWorking = res;
              //         console.log('this.gridViewSetupWorking', this.gridViewSetupWorking)
              //       }
              //     });
              // }

            }
            else if (res[i].url == this.eDayOffURL) {
              this.eDayOffFuncID = res[i].functionID;
              this.eDayOffFunc = res[i];

              if (!this.eDayOffHeaderTexts || !this.eDayOffFormModel) {
                this.hrService
                  .getFormModel(this.eDayOffFuncID)
                  .then((res) => {
                    this.eDayOffFormModel = res;
                  });

                this.hrService
                  .getHeaderText(this.eDayOffFuncID)
                  .then((res) => {
                    this.eDayOffHeaderTexts = res;
                  });


              }
            }


          }

          // if (!this.active[3]) {
          //   this.active[3] = this.eContractFuncID;
          // }
          this.lstBtnAdd = [];
          this.lstWorkingProcess = res;



          this.initEmpJobProcess();
          break;
        case this.rewardCatalogID:
          for (let i = 0; i < res.length; i++) {

            if (res[i].url == this.eAwardURL) {
              this.eAwardFuncID = res[i].functionID;
              this.eAwardFunc = res[i];

              if (!this.eAwardHeaderTexts || !this.eAwardFormModel) {
                this.hrService
                  .getFormModel(this.eAwardFuncID)
                  .then((res) => {
                    this.eAwardFormModel = res;

                    this.cache
                      .gridViewSetup(
                        this.eAwardFormModel.formName,
                        this.eAwardFormModel.gridViewName
                      )
                      .subscribe((res) => {
                        this.eAwardGrvSetup = res;
                        // console.log('this.eAwardGrvSetup',this.eAwardGrvSetup['AwardCode'])

                        // console.log('this.eAwardGrvSetup',this.eAwardGrvSetup['AwardCode'].acceptReturn)
                      })

                  });

                this.hrService
                  .getHeaderText(this.eAwardFuncID)
                  .then((res) => {
                    this.eAwardHeaderTexts = res;
                  });


              }
            }
            else if (res[i].url == this.eDisciplinaryURL) {
              this.eDisciplinaryFuncID = res[i].functionID;
              this.eDisciplinaryFunc = res[i];

              if (!this.eDisciplinaryHeaderTexts || !this.eDisciplinaryFormModel) {
                this.hrService
                  .getFormModel(this.eDisciplinaryFuncID)
                  .then((res) => {
                    this.eDisciplinaryFormModel = res;

                    this.cache
                      .gridViewSetup(
                        this.eDisciplinaryFormModel.formName,
                        this.eDisciplinaryFormModel.gridViewName
                      )
                      .subscribe((res) => {
                        this.eDisciplinaryGrvSetup = res;
                        console.log('this.eAwardGrvSetup', this.eDisciplinaryGrvSetup)

                        // console.log('this.eAwardGrvSetup',this.eAwardGrvSetup['AwardCode'].acceptReturn)
                      })
                  });

                this.hrService
                  .getHeaderText(this.eDisciplinaryFuncID)
                  .then((res) => {
                    this.eDisciplinaryHeaderTexts = res;
                  });
              }


            }
          }

          // if (!this.active[3]) {
          //   this.active[3] = this.eContractFuncID;
          // }
          this.lstBtnAdd = [];
          this.lstRewardCatalog = res;

          this.initEmpAward();
          break;
        case this.benefitInfoID:
          for (let i = 0; i < res.length; i++) {
            if (res[i].url == this.eGroupSalaryURL) {
              this.eGroupSalaryFuncID = res[i].functionID;;
              this.eGroupSalaryFunc = res[i];
              if (!this.eGroupSalaryHeaderTexts || !this.eGroupSalaryFormModel) {
                this.hrService
                  .getHeaderText(this.eGroupSalaryFuncID)
                  .then((headerText) => {
                    this.eGroupSalaryHeaderTexts = headerText;
                  });
                this.hrService.getFormModel(this.eGroupSalaryFuncID).then((res) => {
                  this.eGroupSalaryFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eGroupSalaryFormModel.formName,
                      this.eGroupSalaryFormModel.gridViewName,
                      this.eGroupSalaryFormModel,

                    )
                    .then((fg) => {
                      //check lại sau - later check
                      // this.eGroupSalaryFormModel = fg;
                      // this.eGroupSalaryFormModel.patchValue(this.infoPersonal);
                      // this.eGroupSalaryFormModel.currentData = this.infoPersonal;
                    });

                });

              }
            } else if (res[i].url == this.eBasicSalaryURL) {
              this.eBasicSalaryFuncID = res[i].functionID;;
              this.eBasicSalaryFunc = res[i];
              if (!this.eBasicSalaryHeaderTexts || !this.eBasicSalaryFormModel) {
                this.hrService
                  .getHeaderText(this.eBasicSalaryFuncID)
                  .then((headerText) => {
                    this.eBasicSalaryHeaderTexts = headerText;
                  });
                this.hrService.getFormModel(this.eBasicSalaryFuncID).then((res) => {
                  this.eBasicSalaryFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eBasicSalaryFormModel.formName,
                      this.eBasicSalaryFormModel.gridViewName,
                      this.eBasicSalaryFormModel
                    )
                    .then((fg) => {
                      //check lại sau - later check
                      // this.eGroupSalaryFormModel = fg;
                      // this.eGroupSalaryFormModel.patchValue(this.infoPersonal);
                      // this.eGroupSalaryFormModel.currentData = this.infoPersonal;
                    });

                  console.log('this.eBasicSalaryFormmodel', this.eBasicSalaryFormModel)
                });
              }

              // this.legalInfoFuncID = res[i].functionID;
              // this.legalInfoFunc = res[i];
            }
            else if (res[i].url == this.eDeductionURL) {
              this.eDeductionFuncID = res[i].functionID;
              this.eDeductionFunc = res[i];

              if (!this.eDeductionHeaderTexts || !this.eDeductionFormModel) {
                this.hrService
                  .getHeaderText(this.eDeductionFuncID)
                  .then((headerText) => {
                    this.eDeductionHeaderTexts = headerText;
                  });
                this.hrService.getFormModel(this.eDeductionFuncID).then((res) => {
                  this.eDeductionFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eDeductionFormModel.formName,
                      this.eDeductionFormModel.gridViewName,
                      this.eDeductionFormModel
                    )
                    .then((fg) => {
                      //check lại sau - later check
                      // this.eGroupSalaryFormModel = fg;
                      // this.eGroupSalaryFormModel.patchValue(this.infoPersonal);
                      // this.eGroupSalaryFormModel.currentData = this.infoPersonal;
                    });

                  console.log('this.eDeductionFormModel', this.eDeductionFormModel)
                });
              }
            }
            else if (res[i].url == this.eAdditionalIncomeURL) {
              this.eAdditionalIncomeFuncID = res[i].functionID;
              this.eAdditionalIncomeFunc = res[i];

              if (!this.eAdditionalIncomeHeaderTexts || !this.eAdditionalIncomeFormModel) {
                this.hrService
                  .getHeaderText(this.eAdditionalIncomeFuncID)
                  .then((headerText) => {
                    this.eAdditionalIncomeHeaderTexts = headerText;
                  });
                this.hrService.getFormModel(this.eAdditionalIncomeFuncID).then((res) => {
                  this.eAdditionalIncomeFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eAdditionalIncomeFormModel.formName,
                      this.eAdditionalIncomeFormModel.gridViewName,
                      this.eAdditionalIncomeFormModel
                    )
                    .then((fg) => {
                      //check lại sau - later check
                      // this.eGroupSalaryFormModel = fg;
                      // this.eGroupSalaryFormModel.patchValue(this.infoPersonal);
                      // this.eGroupSalaryFormModel.currentData = this.infoPersonal;
                    });
                });
              }
            }
            else if (res[i].url == this.eAllowanceURL) {
              this.eAllowanceFuncID = res[i].functionID;
              this.eAllowanceFunc = res[i];

              if (!this.eAllowanceHeaderTexts || !this.eAllowanceFormModel) {
                this.hrService
                  .getHeaderText(this.eAllowanceFuncID)
                  .then((headerText) => {
                    this.eAllowanceFormModel = headerText;
                  });
                this.hrService.getFormModel(this.eAllowanceFuncID).then((res) => {
                  this.eAllowanceFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eAllowanceFormModel.formName,
                      this.eAllowanceFormModel.gridViewName,
                      this.eAllowanceFormModel
                    )
                    .then((fg) => {
                      //check lại sau - later check
                      // this.eGroupSalaryFormModel = fg;
                      // this.eGroupSalaryFormModel.patchValue(this.infoPersonal);
                      // this.eGroupSalaryFormModel.currentData = this.infoPersonal;
                    });
                });
              }
            }
            else if (res[i].url == this.eJWSalaryURL) {
              this.eJWSalaryFuncID = res[i].functionID;
              this.eJWSalaryFunc = res[i];

              if (!this.eJWSalaryHeaderTexts || !this.eJWSalaryFormModel) {
                this.hrService
                  .getHeaderText(this.eAllowanceFuncID)
                  .then((headerText) => {
                    this.eJWSalaryHeaderTexts = headerText;
                  });
                this.hrService.getFormModel(this.eJWSalaryFuncID).then((res) => {
                  this.eJWSalaryFormModel = res;
                  this.hrService
                    .getFormGroup(
                      this.eJWSalaryFormModel.formName,
                      this.eJWSalaryFormModel.gridViewName,
                      this.eJWSalaryFormModel
                    )
                    .then((fg) => {
                      //check lại sau - later check
                      // this.eGroupSalaryFormModel = fg;
                      // this.eGroupSalaryFormModel.patchValue(this.infoPersonal);
                      // this.eGroupSalaryFormModel.currentData = this.infoPersonal;
                    });
                });
              }
            }
          }

          // if (!this.active[3]) {
          //   this.active[3] = this.eContractFuncID;
          // }
          this.lstBtnAdd = [];
          this.lstBenefit = res;

          this.initEmpBenefit()
          break;
        case this.curriculumVitaeFuncID:
          for (let i = 0; i < res.length; i++) {

            if (res[i].url == this.eInfoURL) {
              this.eInfoFuncID = res[i].functionID;;
              this.eInfoFunc = res[i];

              if (!this.eInfoHeaderText || !this.eInfoFormModel) {
                this.hrService.getFormModel(this.eInfoFuncID).then((res) => {
                  this.eInfoFormModel = res;


                  this.hrService
                    .getFormGroup(
                      this.eInfoFormModel.formName,
                      this.eInfoFormModel.gridViewName,
                      this.eInfoFormModel
                    )
                    .then((fg) => {
                      this.eInfoFormGroup = fg;
                      this.eInfoFormGroup.patchValue(this.infoPersonal);
                      this.eInfoFormModel.currentData = this.infoPersonal;
                    });

                  console.log('this.eInfoFormModel', this.eInfoFormModel);

                  console.log('this.eInfoHeaderText', this.eInfoHeaderText);
                });

                // this.hrService.getFormModel(this.eInfoFuncID).then((res) => {
                //   this.eFamilyInfoFormModel = res;
                //   this.hrService
                //     .getFormGroup(
                //       this.eFamilyInfoFormModel.formName,
                //       this.eFamilyInfoFormModel.gridViewName,
                //       this.eFamilyInfoFormModel
                //     )
                //     .then((fg) => {
                //       this.eFamilyInfoGroupFormModel = fg;
                //       this.eFamilyInfoGroupFormModel.patchValue(this.infoPersonal);
                //       this.eFamilyInfoFormModel.currentData = this.infoPersonal;
                //     });



                // });

                this.hrService.getHeaderText(this.eInfoFuncID).then((res) => {
                  console.log(this.eInfoFuncID)
                  this.eFamilyHeaderText = res;

                });
              }


            } else if (res[i].url == this.eFamilyInfoURL) {
              this.eFamilyFuncID = res[i].functionID;
              this.eFamilyFunc = res[i];

              if (!this.eFamilyInfoFormModel) {
                this.hrService
                  .getFormModel(this.eFamilyFuncID)
                  .then((res) => {
                    this.eFamilyInfoFormModel = res;
                  });
              }

              if (!this.eFamilyHeaderText) {
                this.hrService
                  .getHeaderText(this.eFamilyFuncID)
                  .then((res) => {
                    this.eFamilyHeaderText = res;
                  });
              }

            } else if (res[i].url == this.eWorkedInfoURL) {
              this.eWorkedInfoFuncID = res[i].functionID;
              this.eWorkedInfoFunc = res[i];
            } else if (res[i].url == this.eContactURL) {
              this.eContactFuncID = res[i].functionID;
              this.eContactFunc = res[i];
            } else if (res[i].url == this.eDepartInfoURL) {
              this.eDepartInfoFuncID = res[i].functionID;
              this.eDepartInfoFunc = res[i];
            }
          }
          // if (!this.active[0]) {
            this.active[0] = res[0].functionID;
          // }

          console.log(this.active[0]);
          this.lstFuncCurriculumVitae = res;
          console.log('lstFuncCurriculumVitae', this.lstFuncCurriculumVitae)
          this.lstBtnAdd = [];
          // for (let i = 0; i < res.length; i++) {
          //   switch (res[i].functionID) {
          //     case this.eInfoFuncID:
          //       this.curriculumVitaePermission.eInfoFuncID.view = true;
          //       this.curriculumVitaePermission.eInfoFuncID.write = res[i].write;
          //       this.curriculumVitaePermission.eInfoFuncID.delete =
          //         res[i].delete;
          //       break;

          //     case this.legalInfoFuncID:
          //       this.curriculumVitaePermission.legalInfoFuncID.view = true;
          //       this.curriculumVitaePermission.legalInfoFuncID.write =
          //         res[i].write;
          //       this.curriculumVitaePermission.legalInfoFuncID.delete =
          //         res[i].delete;
          //       this.hrService
          //         .getFunctionList(this.legalInfoFuncID)
          //         .subscribe((res) => {
          //           this.lstFuncLegalInfo = res;
          //           for (let i = 0; i < res.length; i++) {
          //             if (res[i].url == this.eAssurURL) {
          //               this.eAssurFuncID = res[i].functionID;
          //               this.eAssurFunc = res[i];
          //             } else if (res[i].url == this.ePassportURL) {
          //               this.ePassportFuncID = res[i].functionID;
          //               this.ePassportFunc = res[i];

          //               if (!this.ePassportFormModel) {
          //                 this.hrService
          //                   .getFormModel(this.ePassportFuncID)
          //                   .then((res) => {
          //                     this.ePassportFormModel = res;
          //                   });
          //               }
          //             } else if (res[i].url == this.eVisaURL) {
          //               this.eVisaFuncID = res[i].functionID;
          //               this.eVisaFunc = res[i];

          //               if (!this.eVisaFormModel) {
          //                 this.hrService
          //                   .getFormModel(this.eVisaFuncID)
          //                   .then((res) => {
          //                     this.eVisaFormModel = res;
          //                   });
          //               }
          //             }
          //           }

          //           for (let i = 0; i < res.length; i++) {
          //             if (res[i].functionID == this.ePassportFuncID) {
          //               this.curriculumVitaePermission.legalInfoFuncID.passportFuncID.view =
          //                 true;
          //               this.curriculumVitaePermission.legalInfoFuncID.passportFuncID.write =
          //                 res[i].write;
          //               this.curriculumVitaePermission.legalInfoFuncID.passportFuncID.delete =
          //                 res[i].delete;
          //               this.curriculumVitaePermission.legalInfoFuncID.passportFuncID.isPortal =
          //                 res[i].isPortal;
          //               if (
          //                 res[i].write == true &&
          //                 (this.fromWS == false || res[i].isPortal == false)
          //               ) {
          //                 this.lstBtnAdd.push(res[i]);
          //               }
          //             } else if (res[i].functionID == this.eVisaFuncID) {
          //               this.curriculumVitaePermission.legalInfoFuncID.visaFuncID.view =
          //                 true;
          //               this.curriculumVitaePermission.legalInfoFuncID.visaFuncID.write =
          //                 res[i].write;
          //               this.curriculumVitaePermission.legalInfoFuncID.visaFuncID.delete =
          //                 res[i].delete;
          //               this.curriculumVitaePermission.legalInfoFuncID.visaFuncID.isPortal =
          //                 res[i].isPortal;
          //               if (
          //                 res[i].write == true &&
          //                 (this.fromWS == false || res[i].isPortal == false)
          //               ) {
          //                 this.lstBtnAdd.push(res[i]);
          //               }
          //             }
          //           }
          //         });
          //       break;

          //     case this.foreignWorkerFuncID:
          //       this.curriculumVitaePermission.foreignWorkerFuncID.view = true;
          //       this.curriculumVitaePermission.foreignWorkerFuncID.write =
          //         res[i].write;
          //       this.curriculumVitaePermission.foreignWorkerFuncID.delete =
          //         res[i].delete;
          //       this.hrService
          //         .getFunctionList(this.foreignWorkerFuncID)
          //         .subscribe((res) => {
          //           this.lstFuncForeignWorkerInfo = res;
          //           for (let i = 0; i < res.length; i++) {
          //             if (res[i].url == this.eWorkPermitURL) {
          //               this.eWorkPermitFuncID = res[i].functionID;
          //               this.eWorkPermitFunc = res[i];

              //           if (!this.eWorkPermitFormModel) {
              //             this.hrService
              //               .getFormModel(this.eWorkPermitFuncID)
              //               .then((res) => {
              //                 this.eWorkPermitFormModel = res;
              //               });
              //           }
              //         }
              //       }
              //       for (let i = 0; i < res.length; i++) {
              //         if (res[i].functionID == this.eWorkPermitFuncID) {
              //           this.curriculumVitaePermission.foreignWorkerFuncID.workPermitFuncID.view =
              //             true;
              //           this.curriculumVitaePermission.foreignWorkerFuncID.workPermitFuncID.write =
              //             res[i].write;
              //           this.curriculumVitaePermission.foreignWorkerFuncID.workPermitFuncID.delete =
              //             res[i].delete;
              //           this.curriculumVitaePermission.foreignWorkerFuncID.workPermitFuncID.isPortal =
              //             res[i].isPortal;
              //           if (
              //             res[i].write == true &&
              //             (this.fromWS == false || res[i].isPortal == false)
              //           ) {
              //             this.lstBtnAdd.push(res[i]);
              //           }
              //         }
              //       }
              //     });
              //   this.initEmpFamily()
              //   break;

              // case this.ePartyFuncID:
              //   this.curriculumVitaePermission.ePartyFuncID.view = true;
              //   this.curriculumVitaePermission.ePartyFuncID.write =
              //     res[i].write;
              //   this.curriculumVitaePermission.ePartyFuncID.delete =
              //     res[i].delete;
                // break;

          //     case this.eFamiliesFuncID:
          //       this.curriculumVitaePermission.eFamiliesFuncID.view = true;
          //       this.curriculumVitaePermission.eFamiliesFuncID.write =
          //         res[i].write;
          //       this.curriculumVitaePermission.eFamiliesFuncID.delete =
          //         res[i].delete;
          //       this.curriculumVitaePermission.eFamiliesFuncID.isPortal =
          //         res[i].isPortal;
          //       if (
          //         res[i].write == true &&
          //         (this.fromWS == false || res[i].isPortal == false)
          //       ) {
          //         this.lstBtnAdd.push(res[i]);
          //       }
          //       break;

          //     case this.eExperienceFuncID:
          //       this.curriculumVitaePermission.eExperienceFuncID.view = true;
          //       this.curriculumVitaePermission.eExperienceFuncID.write =
          //         res[i].write;
          //       this.curriculumVitaePermission.eExperienceFuncID.delete =
          //         res[i].delete;
          //       this.curriculumVitaePermission.eExperienceFuncID.isPortal =
          //         res[i].isPortal;
          //       if (
          //         res[i].write == true &&
          //         (this.fromWS == false || res[i].isPortal == false)
          //       ) {
          //         this.lstBtnAdd.push(res[i]);
          //       }
          //       break;
          //   }
          // }

          this.initEmpFamily()

          break;
        //case this.jobInfoFuncID:
        
        
        case this.EducationID:
          for (let i = 0; i < res.length; i++) {
            if (res[i].url == this.eCertificateURL) {
              this.eCertificateFuncID = res[i].functionID;
              this.eCertificateFunc = res[i];
              if (!this.eCertificateFormModel || !this.eCertificateHeaderTexts) {
                this.hrService.getFormModel(this.eSpecializationFuncID).then((res) => {
                  this.eCertificateFormModel = res;
                  // this.cache
                  //   .gridViewSetup(
                  //     this.eCertificateFormModel.formName,
                  //     this.eCertificateFormModel.gridViewName
                  //   )
                  //   .subscribe((res) => {
                  //     this.eSkillgrvSetup = res;
                  //   });
                });
              }
            } else if (res[i].url == this.eSpecializationURL) {
              this.eSpecializationFuncID = res[i].functionID;
              this.eSpecializationFunc = res[i];
              if (!this.eSpecializationHeaderTexts || !this.eSpecializationFormModel) {
                this.hrService.getFormModel(this.eSpecializationFuncID).then((res) => {
                  this.eSpecializationFormModel = res;
                  // this.cache
                  //   .gridViewSetup(
                  //     this.eSpecializationFormModel.formName,
                  //     this.eSpecializationFormModel.gridViewName
                  //   )
                  //   .subscribe((res) => {
                  //     this.eSkillgrvSetup = res;
                  //   });
                });
              }
            } else if (res[i].url == this.eTrainURL) {
              this.eTrainFuncID = res[i].functionID;
              this.eTrainFunc = res[i];
              if (!this.eTrainFormModel) {
                this.hrService
                  .getFormModel(this.eTrainFuncID)
                  .then((res) => {
                    this.eTrainFormModel = res;
                    // this.cache
                    //   .gridViewSetup(
                    //     this.eTrainFormModel.formName,
                    //     this.eTrainFormModel.gridViewName
                    //   )
                    //   .subscribe((res) => {
                    //     this.eTrainCourseGrvSetup = res;
                    //   });
                  });
              }
            } else if (res[i].url == this.eEvaluationURL) {
              this.eEvaluationFuncID = res[i].functionID;
              this.eEvaluationFunc = res[i];
              if (!this.eEvaluationFormModel) {
                this.hrService
                  .getFormModel(this.eEvaluationFuncID)
                  .then((res) => {
                    this.eEvaluationFormModel = res;
                    // this.cache
                    //   .gridViewSetup(
                    //     this.eEvaluationFormModel.formName,
                    //     this.eEvaluationFormModel.gridViewName
                    //   )
                    //   .subscribe((res) => {
                    //     this.eEvaluationGrvSetup = res;
                    //   });
                  });
              }
            }

          }
          if (!this.active[4]) {
            this.active[4] = this.eDegreeFuncID;
          }
          this.lstBtnAdd = [];
          this.lstFuncEducationInfo = res;
          
          this.initEmpEducation()

          break;
        //case this.jobInfoFuncID:
      }
    });


  }


  addSkill() {
    this.hrService.addSkill(null).subscribe();
  }

  addSkillGrade() {
    this.hrService.addSkillGrade(null).subscribe();
  }

  refreshGridViews() {

    let ins = setInterval(() => {
      if (this.eFamilyGridViewID) {
        clearInterval(ins);
        this.eFamilyGridViewID.refresh();
      }
    }, 100);

    let ins1 = setInterval(() => {
      if (this.eBasicSalaryGridViewID) {
        clearInterval(ins1);
        this.eBasicSalaryGridViewID.refresh();
      }
    }, 100);

    let ins2 = setInterval(() => {
      if (this.eJobSalaryGridViewID) {
        clearInterval(ins2);
        this.eJobSalaryGridViewID.refresh();
      }
    }, 100);

    let ins3 = setInterval(() => {
      if (this.eAllowanceGridViewID) {
        clearInterval(ins3);
        this.eAllowanceGridViewID.refresh();
      }
    }, 100);

    let ins4 = setInterval(() => {
      if (this.eAdditionalEarningsGridViewID) {
        clearInterval(ins4);
        this.eAdditionalEarningsGridViewID.refresh();
      }
    }, 100);

    let ins5 = setInterval(() => {
      if (this.eEductionGridViewID) {
        clearInterval(ins5);
        this.eEductionGridViewID.refresh();
      }
    }, 100);

    let ins6 = setInterval(() => {
      if (this.ePromoGridViewID) {
        clearInterval(ins6);
        this.ePromoGridViewID.refresh();
      }
    }, 100);

    let ins7 = setInterval(() => {
      if (this.eLeaveGridViewID) {
        clearInterval(ins7);
        this.eLeaveGridViewID.refresh();
      }
    }, 100);

    let ins8 = setInterval(() => {
      if (this.eSpecializationGridViewID) {
        clearInterval(ins8);
        this.eSpecializationGridViewID.refresh();
      }
    }, 100);

    let ins9 = setInterval(() => {
      if (this.eCertificateGridViewID) {
        clearInterval(ins9);
        this.eCertificateGridViewID.refresh();
      }
    }, 100);

    let ins10 = setInterval(() => {
      if (this.eTrainGridViewID) {
        clearInterval(ins10);
        this.eTrainGridViewID.refresh();
      }
    }, 100);

    let ins11 = setInterval(() => {
      if (this.eEvaluationGridViewID) {
        clearInterval(ins11);
        this.eEvaluationGridViewID.refresh();
      }
    }, 100);

    let ins12 = setInterval(() => {
      if (this.eAwardGridViewID) {
        clearInterval(ins12);
        this.eAwardGridViewID.refresh();
      }
    }, 100);

    let ins13 = setInterval(() => {
      if (this.eDisciplinaryGridViewID) {
        clearInterval(ins13);
        this.eDisciplinaryGridViewID.refresh();
      }
    }, 100);













    // Anh Trầm chỉ, setInterval đợi nó load cái grid xong mới gọi refresh
    // let ins = setInterval(() => {
    //   if (this.eDisciplineGrid) {
    //     clearInterval(ins);
    //     this.eDisciplineGrid.refresh();
    //   }
    // }, 100);

    // let ins2 = setInterval(() => {
    //   if (this.appointionGridView) {
    //     clearInterval(ins2);
    //     this.appointionGridView.refresh();
    //   }
    // }, 100);

    // let ins3 = setInterval(() => {
    //   if (this.dayoffGrid) {
    //     clearInterval(ins3);
    //     this.dayoffGrid.refresh();
    //   }
    // }, 100);

    // let ins4 = setInterval(() => {
    //   if (this.businessTravelGrid) {
    //     clearInterval(ins4);
    //     this.businessTravelGrid.refresh();
    //   }
    // }, 100);

    // let ins5 = setInterval(() => {
    //   if (this.AwardGrid) {
    //     clearInterval(ins5);
    //     this.AwardGrid.refresh();
    //   }
    // }, 100);

    // let ins6 = setInterval(() => {
    //   if (this.eDegreeGrid) {
    //     clearInterval(ins6);
    //     this.eDegreeGrid.refresh();
    //   }
    // }, 100);

    // let ins7 = setInterval(() => {
    //   if (this.eCertificateGrid) {
    //     clearInterval(ins7);
    //     this.eCertificateGrid.refresh();
    //   }
    // }, 100);

    // let ins8 = setInterval(() => {
    //   if (this.skillGrid) {
    //     clearInterval(ins8);
    //     this.skillGrid.refresh();
    //   }
    // }, 100);

    // let ins9 = setInterval(() => {
    //   if (this.eTrainCourseGrid) {
    //     clearInterval(ins9);
    //     this.eTrainCourseGrid.refresh();
    //   }
    // }, 100);

    // let ins10 = setInterval(() => {
    //   if (this.eAccidentGridView) {
    //     clearInterval(ins10);
    //     this.eAccidentGridView.refresh();
    //   }
    // }, 100);

    // let ins11 = setInterval(() => {
    //   if (this.eDiseasesGrid) {
    //     clearInterval(ins11);
    //     this.eDiseasesGrid.refresh();
    //   }
    // }, 100);

    // let ins12 = setInterval(() => {
    //   if (this.eHealthsGrid) {
    //     clearInterval(ins12);
    //     this.eHealthsGrid.refresh();
    //   }
    // }, 100);

    // let ins13 = setInterval(() => {
    //   if (this.eVaccinesGrid) {
    //     clearInterval(ins13);
    //     this.eVaccinesGrid.refresh();
    //   }
    // }, 100);
  }

  // loadDataWhenChangeEmp() {
  //   switch (this.crrFuncTab) {
  //     case this.curriculumVitaeFuncID:
  //       break;
  //     case this.jobInfoFuncID:
  //       break;
  //     case this.salaryBenefitInfoFuncID:
  //       this.initEmpSalary();
  //       break;
  //     case this.workingProcessInfoFuncID:
  //       this.initEmpProcess();
  //       break;
  //     case this.knowledgeInfoFuncID:
  //       this.initEmpKnowledge();
  //       break;
  //     case this.healthInfoFuncID:
  //       break;
  //   }
  // }

  loadDataWhenChangeEmp() {
    switch (this.crrFuncTab) {
      case this.curriculumVitaeFuncID:
        this.initEmpFamily();
        break;
      case this.legalInfoFuncID:
        break;
      case this.benefitFuncID:
        this.initEmpSalary();
        break;
      case this.JobProcessID:
        this.initEmpJobProcess();
        break;
      // case this.edu
      // this.initEmpKnowledge();
      // this.initEmpEducation();
      // break;
      case this.rewardCatalogID:
        this.initEmpAward;
        break;
    }
  }

  nextEmp() {
    if (this.listEmp.length <= this.totalCount) {
      this.crrIndex += 1;
      if (this.fromView == 'listView') {
        if (
          this.crrIndex == this.listEmp.length - 1 ||
          (this.crrIndex == this.listEmp.length &&
            this.crrIndex < this.totalCount - 1)
        ) {
          if (
            this.crrIndex == this.listEmp.length &&
            this.crrIndex < this.totalCount - 1
          ) {
            this.request.page = this.request.page;
          } else {
            this.request.page += 1;
          }

          this.hrService.loadData('HR', this.request).subscribe((res) => {
            if (res && res[0].length > 0) {
              this.listEmp.push(...res[0]);
              this.navigateEmp(0, true);
            } else {
              this.navigateEmp(0);
            }
          });
        } else {
          this.navigateEmp(0);
        }
      } else if (this.fromView == 'gridView') {
        if (this.crrIndex == this.listEmp.length) {
          this.request.page += 1;
          this.hrService.loadData('HR', this.request).subscribe((res) => {
            if (res && res[0].length > 0) {
              this.listEmp.push(...res[0]);
              this.navigateEmp(0, true);
            } else {
              this.navigateEmp(0);
            }
          });
        }
        if (this.crrIndex > -1 && this.crrIndex != this.listEmp.length) {
          this.navigateEmp(0);
        }
      }
      this.loadDataWhenChangeEmp();
      this.refreshGridViews();
    }
  }

  navigateEmp(isNextEmp, isNextPage?) {
    if (isNextPage == true) {
      let newPageNum = Number(this.pageNum) + 1;
      this.pageNum = newPageNum;
    }
    if (this.crrIndex > -1) {
      this.LoadedEInfo = false;
      this.infoPersonal = null;
      let urlView = `/hr/employeedetail/${this.funcID}`;
      this.codxService.replaceNavigate(
        urlView,
        {
          employeeID: this.listEmp[this.crrIndex + isNextEmp]?.EmployeeID,
          page: this.pageNum.toString(),
          // totalPage: this.maxPageNum,
          // totalCount: this.totalCount,
          // from: this.fromView
        },
        {
          data: this.listEmp,
          request: this.request,
          totalPage: this.maxPageNum,
          totalCount: this.totalCount,
          from: this.fromView,
        }
      );
    }
  }

  previousEmp() {
    if (this.listEmp) {
      if (this.crrIndex > -1) {
        this.navigateEmp(-1);
      }
      this.loadDataWhenChangeEmp();
      this.refreshGridViews();
    }
  }

  valueChangeFilterBenefit(evt) {
    this.filterByBenefitIDArr = evt.data;
    this.UpdateEBenefitPredicate();
  }

  UpdateEBenefitPredicate() {
    this.filterEBenefitPredicates = '';
    if (
      this.filterByBenefitIDArr?.length > 0 &&
      this.startDateEBenefitFilterValue != null
    ) {
      this.filterEBenefitPredicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.filterByBenefitIDArr?.length; i++) {
        if (i > 0) {
          this.filterEBenefitPredicates += ' or ';
        }
        this.filterEBenefitPredicates += `BenefitID==@${i}`;
      }
      this.filterEBenefitPredicates += ') ';
      this.filterEBenefitPredicates += `and (EffectedDate>="${this.startDateEBenefitFilterValue}" and EffectedDate<="${this.endDateEBenefitFilterValue}")`;
      this.filterEBenefitPredicates += ') ';
      (this.eBenefitGrid.dataService as CRUDService).setPredicates(
        [this.filterEBenefitPredicates],
        [this.filterByBenefitIDArr.join(';')]
      );
    } else if (
      this.filterByBenefitIDArr?.length > 0 &&
      (this.startDateEBenefitFilterValue == undefined ||
        this.startDateEBenefitFilterValue == null)
    ) {
      this.filterEBenefitPredicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.filterByBenefitIDArr?.length; i++) {
        if (i > 0) {
          this.filterEBenefitPredicates += ' or ';
        }
        this.filterEBenefitPredicates += `BenefitID==@${i}`;
      }
      this.filterEBenefitPredicates += ') ';
      this.filterEBenefitPredicates += ') ';
      (this.eBenefitGrid.dataService as CRUDService).setPredicates(
        [this.filterEBenefitPredicates],
        [this.filterByBenefitIDArr.join(';')]
      );
    } else if (
      this.filterByBenefitIDArr?.length <= 0 &&
      this.startDateEBenefitFilterValue != null
    ) {
      this.filterEBenefitPredicates = `(EmployeeID=="${this.employeeID}" and EffectedDate>="${this.startDateEBenefitFilterValue}" and EffectedDate<="${this.endDateEBenefitFilterValue}")`;
      (this.eBenefitGrid.dataService as CRUDService).setPredicates(
        [this.filterEBenefitPredicates],
        []
      );
    } else if (
      this.filterByBenefitIDArr?.length <= 0 &&
      (this.startDateEBenefitFilterValue == undefined ||
        this.startDateEBenefitFilterValue == null)
    ) {
      this.filterEBenefitPredicates = `(EmployeeID=="${this.employeeID}")`;
      (this.eBenefitGrid.dataService as CRUDService).setPredicates(
        [this.filterEBenefitPredicates],
        ['']
      );
    }
  }

  logDataDegree(data) {
    console.log('data degree load len', data);
  }

  valueChangeYearFilterBenefit(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.startDateEBenefitFilterValue = null;
      this.endDateEBenefitFilterValue = null;
    } else {
      this.startDateEBenefitFilterValue = evt.fromDate.toJSON();
      this.endDateEBenefitFilterValue = evt.toDate.toJSON();
    }
    this.UpdateEBenefitPredicate();
  }

  popupViewBenefit() {
    let opt = new DialogModel();
    opt.zIndex = 999;
    let popup = this.callfunc.openForm(
      PopupViewAllComponent,
      null,
      850,
      550,
      this.benefitFuncID,
      {
        quitjobStatus: this.infoPersonal.status,
        func: this.benefitFunc,
        funcUrl: this.benefitURL,
        fromWS: this.fromWS,
        funcID: this.benefitFuncID,
        employeeId: this.employeeID,
        headerText: this.transText(
          this.benefitFuncID,
          this.lstFuncSalaryBenefit
        ),
        sortModel: this.benefitSortModel,
        formModel: this.benefitFormodel,
        hasFilter: false,
      },
      null,
      opt
    );
    popup.closed.subscribe((res) => {
      // Thay vào đó gọi api lấy lại tất cả benefit mới nhất luôn
      this.hrService.GetCurrentBenefit(this.employeeID).subscribe((res) => {
        if (res) {
          this.listCrrBenefit = res;
          this.df.detectChanges();
        }
      });
    });
  }

  valueChangeViewAllEBenefit(evt) {
    this.popupViewBenefit();
  }

  closeModelSalary(dialog: DialogRef) {
    dialog.close();
  }

  popupUpdateEBasicSalaryStatus() {
    console.log('hihi');
    let opt = new DialogModel();
    opt.zIndex = 999;
    let popup = this.callfunc.openForm(
      PopupViewAllComponent,
      null,
      850,
      550,
      this.eBasicSalaryFuncID,
      {
        quitjobStatus: this.infoPersonal.status,
        func: this.eBasicSalaryFunc,
        funcUrl: this.eBasicSalaryURL,
        fromWS: this.fromWS,
        funcID: this.eBasicSalaryFuncID,
        employeeId: this.employeeID,
        headerText: this.transText(
          this.eBasicSalaryFuncID,
          this.lstFuncSalaryBenefit
        ),
        sortModel: this.bSalarySortModel,
        formModel: this.eBasicSalaryFormmodel,
        hasFilter: false,
      },
      null,
      opt
    );
    popup.closed.subscribe((res) => {
      if (res?.event) {
        if (res?.event == 'none') {
          this.crrEBSalary = null;
        } else {
          this.crrEBSalary = res.event;
        }
        this.df.detectChanges();
      }
    });
  }

  valueChangeViewAllEBasicSalary() {
    this.popupUpdateEBasicSalaryStatus();
  }
  valueChangeViewAllEJobSalary(evt) {
    this.ViewAllEJobSalaryFlag = evt.data;
    let ins = setInterval(() => {
      if (this.jobSalaryGridview) {
        clearInterval(ins);
        let t = this;
        this.jobSalaryGridview.dataService.onAction.subscribe((res) => {
          if (res?.type == 'loaded') {
            t.eJobSalaryRowCount = res['data']?.length;
          }
        });
        this.eJobSalaryRowCount = this.jobSalaryGridview.dataService.rowCount;
      }
    }, 100);
  }

  

  updateGridView(
    gridView: CodxGridviewV2Component,
    actionType: string,
    newData: any,
    oldData?: any
  ) {
    let returnVal = 0;
    let index = 0;
    if (oldData) {
      index = gridView.dataService.data.findIndex(
        (p) => p.recID == oldData.recID
      );
    }
    if (
      actionType == 'add' ||
      actionType == 'copy' ||
      actionType == 'copyMulti'
    ) {
      // (gridView?.dataService as CRUDService)?.add(newData, 0).subscribe();
      // gridView.addRow(newData, 0, true);

      //Gọi refresh luôn để dữ liệu hiển thị đúng theo sort
      gridView.refresh();
      returnVal = 1;
    } else if (actionType == 'edit') {
      // (gridView?.dataService as CRUDService)?.update(newData).subscribe();
      // gridView.updateRow(index, newData, false);

      //Gọi refresh luôn để dữ liệu hiển thị đúng theo sort
      gridView.refresh();
    } else if ((actionType = 'delete')) {
      (gridView?.dataService as CRUDService)?.remove(oldData).subscribe();
      gridView.deleteRow(oldData, true);
      returnVal = -1;
    }
    this.df.detectChanges();
    // if (gridView.formModel.entityName == this.ePassportFormModel.entityName) {
    //   this.crrPassport = gridView.dataService.data[0];
    // } else if (
    //   gridView.formModel.entityName == this.eVisaFormModel.entityName
    // ) {
    //   this.crrVisa = gridView.dataService.data[0];
    // } else if (
    //   gridView.formModel.entityName == this.eWorkPermitFormModel.entityName
    // ) {
    //   this.crrWorkpermit = gridView.dataService.data[0];
    // }
    // this.df.detectChanges();
    return returnVal;
  }

  valueChangeFilterAssetCategory(evt) {
    this.filterByAssetCatIDArr = evt.data;
    this.UpdateEAssetPredicate();
  }

  UpdateEAssetPredicate() {
    this.filterEAssetPredicates = '';
    if (
      this.filterByAssetCatIDArr?.length > 0 &&
      this.startDateEAssetFilterValue != null
    ) {
      this.filterEAssetPredicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.filterByAssetCatIDArr?.length; i++) {
        if (i > 0) {
          this.filterEAssetPredicates += ' or ';
        }
        this.filterEAssetPredicates += `AssetCategory==@${i}`;
      }
      this.filterEAssetPredicates += ') ';
      this.filterEAssetPredicates += `and (IssuedDate>="${this.startDateEAssetFilterValue}" and IssuedDate<="${this.endDateEAssetFilterValue}")`;
      this.filterEAssetPredicates += ') ';
      (this.eAssetGrid.dataService as CRUDService).setPredicates(
        [this.filterEAssetPredicates],
        [this.filterByAssetCatIDArr.join(';')]
      );
    } else if (
      this.filterByAssetCatIDArr?.length > 0 &&
      (this.startDateEAssetFilterValue == undefined ||
        this.startDateEAssetFilterValue == null)
    ) {
      this.filterEAssetPredicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.filterByAssetCatIDArr?.length; i++) {
        if (i > 0) {
          this.filterEAssetPredicates += ' or ';
        }
        this.filterEAssetPredicates += `AssetCategory==@${i}`;
      }
      this.filterEAssetPredicates += ') ';
      this.filterEAssetPredicates += ') ';
      (this.eAssetGrid.dataService as CRUDService).setPredicates(
        [this.filterEAssetPredicates],
        [this.filterByAssetCatIDArr]
      );
    } else if (
      this.filterByAssetCatIDArr?.length <= 0 &&
      this.startDateEAssetFilterValue != null
    ) {
      this.filterEAssetPredicates = `(EmployeeID=="${this.employeeID}" and IssuedDate>="${this.startDateEAssetFilterValue}" and IssuedDate<="${this.endDateEAssetFilterValue}")`;
      (this.eAssetGrid.dataService as CRUDService).setPredicates(
        ['time'],
        [
          this.employeeID,
          this.startDateEAssetFilterValue,
          this.endDateEAssetFilterValue,
        ]
      );
    } else if (
      this.filterByAssetCatIDArr?.length <= 0 &&
      (this.startDateEAssetFilterValue == undefined ||
        this.startDateEAssetFilterValue == null)
    ) {
      this.filterEAssetPredicates = `(EmployeeID=="${this.employeeID}")`;
      (this.eAssetGrid.dataService as CRUDService).setPredicates(
        [this.filterEAssetPredicates],
        [this.employeeID]
      );
    }
  }

  valueChangeYearFilterAward(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.Start_Date_Award_Filter_Value = null;
      this.End_Date_Award_Filter_Value = null;
      this.Filter_Award_Predicates = `(EmployeeID=="${this.employeeID}")`;
      (this.AwardGrid.dataService as CRUDService).setPredicates(
        [this.Filter_Award_Predicates],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.AwardGrid,
            res,
            this.Filter_Award_Predicates,
            null
          );
        }
      );
    } else {
      this.Start_Date_Award_Filter_Value = evt.fromDate.toJSON();
      this.End_Date_Award_Filter_Value = evt.toDate.toJSON();
      let inYear = new Date(this.End_Date_Award_Filter_Value).getFullYear();
      this.Filter_Award_Predicates = `(EmployeeID=="${this.employeeID}" and InYear=="${inYear}")`;

      (this.AwardGrid.dataService as CRUDService).setPredicates(
        [this.Filter_Award_Predicates],
        [],
        (res) => {
          this.UpdateDataOnGrid(
            this.AwardGrid,
            res,
            this.Filter_Award_Predicates,
            null
          );
        }
      );
    }
  }

  valueChangeYearFilterEAsset(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.startDateEAssetFilterValue = null;
      this.endDateEAssetFilterValue = null;
    } else {
      this.startDateEAssetFilterValue = evt.fromDate.toJSON();
      this.endDateEAssetFilterValue = evt.toDate.toJSON();
    }
    this.UpdateEAssetPredicate();
  }

  UpdateEVaccinePredicate() {
    this.filterEVaccinePredicates = '';
    if (
      this.filterByVaccineTypeIDArr?.length > 0 &&
      this.startDateEVaccineFilterValue != null
    ) {
      this.filterEVaccinePredicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.filterByVaccineTypeIDArr?.length; i++) {
        if (i > 0) {
          this.filterEVaccinePredicates += ' or ';
        }
        this.filterEVaccinePredicates += `VaccineTypeID==@${i}`;
      }
      this.filterEVaccinePredicates += ') ';
      this.filterEVaccinePredicates += `and (InjectDate>="${this.startDateEVaccineFilterValue}" and InjectDate<="${this.endDateEVaccineFilterValue}")`;
      this.filterEVaccinePredicates += ') ';
      (this.eVaccinesGrid.dataService as CRUDService).setPredicates(
        [this.filterEVaccinePredicates],
        [this.filterByVaccineTypeIDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.eVaccinesGrid,
            res,
            this.filterEVaccinePredicates,
            this.filterByVaccineTypeIDArr.join(';')
          );
        }
      );
    } else if (
      this.filterByVaccineTypeIDArr?.length > 0 &&
      (this.startDateEVaccineFilterValue == undefined ||
        this.startDateEVaccineFilterValue == null)
    ) {
      this.filterEVaccinePredicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.filterByVaccineTypeIDArr?.length; i++) {
        if (i > 0) {
          this.filterEVaccinePredicates += ' or ';
        }
        this.filterEVaccinePredicates += `VaccineTypeID==@${i}`;
      }
      this.filterEVaccinePredicates += ') ';
      this.filterEVaccinePredicates += ') ';
      (this.eVaccinesGrid.dataService as CRUDService).setPredicates(
        [this.filterEVaccinePredicates],
        [this.filterByVaccineTypeIDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.eVaccinesGrid,
            res,
            this.filterEVaccinePredicates,
            this.filterByVaccineTypeIDArr.join(';')
          );
        }
      );
    } else if (
      this.filterByVaccineTypeIDArr?.length <= 0 &&
      this.startDateEVaccineFilterValue != null
    ) {
      this.filterEVaccinePredicates = `(EmployeeID=="${this.employeeID}" and InjectDate>="${this.startDateEVaccineFilterValue}" and InjectDate<="${this.endDateEVaccineFilterValue}")`;
      (this.eVaccinesGrid.dataService as CRUDService).setPredicates(
        [this.filterEVaccinePredicates],
        [],
        (res) => {
          this.UpdateDataOnGrid(
            this.eVaccinesGrid,
            res,
            this.filterEVaccinePredicates,
            null
          );
        }
      );
    } else if (
      this.filterByVaccineTypeIDArr?.length <= 0 &&
      (this.startDateEVaccineFilterValue == undefined ||
        this.startDateEVaccineFilterValue == null)
    ) {
      this.filterEVaccinePredicates = `(EmployeeID=="${this.employeeID}")`;
      (this.eVaccinesGrid.dataService as CRUDService).setPredicates(
        [this.filterEVaccinePredicates],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.eVaccinesGrid,
            res,
            this.filterEVaccinePredicates,
            null
          );
        }
      );
    }
  }

  UpdateESkillPredicate(evt) {
    this.filterByESkillIDArr = evt.data;
    let lengthArr = this.filterByESkillIDArr?.length;

    if (lengthArr <= 0) {
      this.filterESkillPredicates = `(EmployeeID=="${this.employeeID}")`;
      (this.skillGrid.dataService as CRUDService).setPredicates(
        [this.filterESkillPredicates],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.skillGrid,
            res,
            this.filterESkillPredicates,
            null
          );
        }
      );
    } else {
      this.filterESkillPredicates = `(EmployeeID=="${this.employeeID}" and (`;
      for (let i = 0; i < lengthArr; i++) {
        if (i > 0) {
          this.filterESkillPredicates += ' or ';
        }
        this.filterESkillPredicates += `SkillID==@${i}`;
      }
      this.filterESkillPredicates += ') ';
      this.filterESkillPredicates += ') ';
      (this.skillGrid.dataService as CRUDService).setPredicates(
        [this.filterESkillPredicates],
        [this.filterByESkillIDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.skillGrid,
            res,
            this.filterESkillPredicates,
            this.filterByESkillIDArr.join(';')
          );
        }
      );
    }
  }

  UpdateTrainCoursePredicate() {
    this.Filter_ETrainCourse_Predicates = '';
    if (
      this.Filter_By_ETrainCourse_IDArr?.length > 0 &&
      this.Start_Date_ETrainCourse_Filter_Value != null
    ) {
      this.Filter_ETrainCourse_Predicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.Filter_By_ETrainCourse_IDArr?.length; i++) {
        if (i > 0) {
          this.Filter_ETrainCourse_Predicates += ' or ';
        }
        this.Filter_ETrainCourse_Predicates += `TrainForm==@${i}`;
      }
      this.Filter_ETrainCourse_Predicates += ') ';
      this.Filter_ETrainCourse_Predicates += `and (TrainFromDate>="${this.Start_Date_ETrainCourse_Filter_Value}" and TrainFromDate<="${this.End_Date_ETrainCourse_Filter_Value}")`;
      this.Filter_ETrainCourse_Predicates += ') ';
      (this.eTrainCourseGrid.dataService as CRUDService).setPredicates(
        [this.Filter_ETrainCourse_Predicates],
        [this.Filter_By_ETrainCourse_IDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.eTrainCourseGrid,
            res,
            this.Filter_ETrainCourse_Predicates,
            this.Filter_By_ETrainCourse_IDArr.join(';')
          );
        }
      );
    } else if (
      this.Filter_By_ETrainCourse_IDArr?.length > 0 &&
      (this.Start_Date_ETrainCourse_Filter_Value == undefined ||
        this.Start_Date_ETrainCourse_Filter_Value == null)
    ) {
      this.Filter_ETrainCourse_Predicates = `(EmployeeID=="${this.employeeID}" and (`;
      let i = 0;
      for (i; i < this.Filter_By_ETrainCourse_IDArr?.length; i++) {
        if (i > 0) {
          this.Filter_ETrainCourse_Predicates += ' or ';
        }
        this.Filter_ETrainCourse_Predicates += `TrainForm==@${i}`;
      }
      this.Filter_ETrainCourse_Predicates += ') ';
      this.Filter_ETrainCourse_Predicates += ') ';
      (this.eTrainCourseGrid.dataService as CRUDService).setPredicates(
        [this.Filter_ETrainCourse_Predicates],
        [this.Filter_By_ETrainCourse_IDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.eTrainCourseGrid,
            res,
            this.Filter_ETrainCourse_Predicates,
            this.Filter_By_ETrainCourse_IDArr.join(';')
          );
        }
      );
    } else if (
      this.Filter_By_ETrainCourse_IDArr?.length <= 0 &&
      this.Start_Date_ETrainCourse_Filter_Value != null
    ) {
      this.Filter_ETrainCourse_Predicates = `(EmployeeID=="${this.employeeID}" and TrainFromDate>="${this.Start_Date_ETrainCourse_Filter_Value}" and TrainFromDate<="${this.End_Date_ETrainCourse_Filter_Value}")`;
      (this.eTrainCourseGrid.dataService as CRUDService).setPredicates(
        [this.Filter_ETrainCourse_Predicates],
        [],
        (res) => {
          this.UpdateDataOnGrid(
            this.eTrainCourseGrid,
            res,
            this.Filter_ETrainCourse_Predicates,
            null
          );
        }
      );
    } else if (
      this.Filter_By_ETrainCourse_IDArr?.length <= 0 &&
      (this.Start_Date_ETrainCourse_Filter_Value == undefined ||
        this.Start_Date_ETrainCourse_Filter_Value == null)
    ) {
      this.Filter_ETrainCourse_Predicates = `(EmployeeID=="${this.employeeID}")`;
      (this.eTrainCourseGrid.dataService as CRUDService).setPredicates(
        [this.Filter_ETrainCourse_Predicates],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.eTrainCourseGrid,
            res,
            this.Filter_ETrainCourse_Predicates,
            null
          );
        }
      );
    }
  }

  valueChangeFilterDiseasesTypeID(evt) {
    this.Filter_By_EDiseases_IDArr = evt.data;
    let lengthArr = this.Filter_By_EDiseases_IDArr?.length;
    if (lengthArr <= 0) {
      this.Filter_EDiseases_Predicates = `(EmployeeID=="${this.employeeID}")`;
      (this.eDiseasesGrid.dataService as CRUDService).setPredicates(
        [this.Filter_EDiseases_Predicates],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.eDiseasesGrid,
            res,
            this.Filter_EDiseases_Predicates,
            null
          );
        }
      );
    } else {
      this.Filter_EDiseases_Predicates = `(EmployeeID=="${this.employeeID}" and (`;
      for (let i = 0; i < lengthArr; i++) {
        if (i > 0) {
          this.Filter_EDiseases_Predicates += ' or ';
        }
        this.Filter_EDiseases_Predicates += `DiseaseID==@${i}`;
      }
      this.Filter_EDiseases_Predicates += ') ';
      this.Filter_EDiseases_Predicates += ') ';
      (this.eDiseasesGrid.dataService as CRUDService).setPredicates(
        [this.Filter_EDiseases_Predicates],
        [this.Filter_By_EDiseases_IDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.eDiseasesGrid,
            res,
            this.Filter_EDiseases_Predicates,
            this.Filter_By_EDiseases_IDArr.join(';')
          );
        }
      );
    }
  }

  valueChangeFilterTrainCourse(evt) {
    this.Filter_By_ETrainCourse_IDArr = evt.data;
    this.UpdateTrainCoursePredicate();
  }

  valueChangeFilterSkillID(evt) {
    this.filterByESkillIDArr = evt.data;
    this.UpdateESkillPredicate(evt);
  }

  valueChangeFilterVaccineTypeID(evt) {
    this.filterByVaccineTypeIDArr = evt.data;
    this.UpdateEVaccinePredicate();
  }

  valueChangeYearFilterEVaccine(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.startDateEVaccineFilterValue = null;
      this.endDateEVaccineFilterValue = null;
    } else {
      this.startDateEVaccineFilterValue = evt.fromDate.toJSON();
      this.endDateEVaccineFilterValue = evt.toDate.toJSON();
    }
    this.UpdateEVaccinePredicate();
  }

  valueChangeYearFilterETrainCourse(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.Start_Date_ETrainCourse_Filter_Value = null;
      this.End_Date_ETrainCourse_Filter_Value = null;
    } else {
      this.Start_Date_ETrainCourse_Filter_Value = evt.fromDate.toJSON();
      this.End_Date_ETrainCourse_Filter_Value = evt.toDate.toJSON();
    }
    this.UpdateTrainCoursePredicate();
  }

  valueChangeYearFilterBusinessTravel(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.startDateBusinessTravelFilterValue = null;
      this.endDateBusinessTravelFilterValue = null;
      this.filterBusinessTravelPredicates = `(EmployeeID=="${this.employeeID}")`;
      (this.businessTravelGrid.dataService as CRUDService).setPredicates(
        [this.filterBusinessTravelPredicates],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.businessTravelGrid,
            res,
            this.filterBusinessTravelPredicates,
            null
          );
        }
      );
    } else {
      this.startDateBusinessTravelFilterValue = evt.fromDate.toJSON();
      this.endDateBusinessTravelFilterValue = evt.toDate.toJSON();
      this.filterBusinessTravelPredicates = `(EmployeeID=="${this.employeeID}" and BeginDate>="${this.startDateBusinessTravelFilterValue}" and EndDate<="${this.endDateBusinessTravelFilterValue}")`;
      (this.businessTravelGrid.dataService as CRUDService).setPredicates(
        [this.filterBusinessTravelPredicates],
        [],
        (res) => {
          this.UpdateDataOnGrid(
            this.businessTravelGrid,
            res,
            this.filterBusinessTravelPredicates,
            null
          );
        }
      );
    }
  }

  UpdateEDayOffsPredicate() {
    if (this.dayoffGrid) {
      this.filterEDayoffPredicates = '';
      if (
        this.filterByKowIDArr?.length > 0 &&
        this.startDateEDayoffFilterValue != null
      ) {
        this.filterEDayoffPredicates = `(EmployeeID=="${this.employeeID}" and (`;
        let i = 0;
        for (i; i < this.filterByKowIDArr?.length; i++) {
          if (i > 0) {
            this.filterEDayoffPredicates += ' or ';
          }
          this.filterEDayoffPredicates += `KowID==@${i}`;
        }
        this.filterEDayoffPredicates += ') ';
        this.filterEDayoffPredicates += `and (BeginDate>="${this.startDateEDayoffFilterValue}" and EndDate<="${this.endDateEDayoffFilterValue}")`;
        this.filterEDayoffPredicates += ') ';
        (this.dayoffGrid?.dataService as CRUDService).setPredicates(
          [this.filterEDayoffPredicates],
          [this.filterByKowIDArr.join(';')],
          (res) => {
            this.UpdateDataOnGrid(
              this.dayoffGrid,
              res,
              this.filterEDayoffPredicates,
              this.filterByKowIDArr.join(';')
            );
          }
        );
      } else if (
        this.filterByKowIDArr?.length > 0 &&
        (this.startDateEDayoffFilterValue == undefined ||
          this.startDateEDayoffFilterValue == null)
      ) {
        this.filterEDayoffPredicates = `(EmployeeID=="${this.employeeID}" and (`;
        let i = 0;
        for (i; i < this.filterByKowIDArr?.length; i++) {
          if (i > 0) {
            this.filterEDayoffPredicates += ' or ';
          }
          this.filterEDayoffPredicates += `KowID==@${i}`;
        }
        this.filterEDayoffPredicates += ') ';
        this.filterEDayoffPredicates += ') ';
        (this.dayoffGrid?.dataService as CRUDService).setPredicates(
          [this.filterEDayoffPredicates],
          [this.filterByKowIDArr.join(';')],
          (res) => {
            this.UpdateDataOnGrid(
              this.dayoffGrid,
              res,
              this.filterEDayoffPredicates,
              this.filterByKowIDArr.join(';')
            );
          }
        );
      } else if (
        this.filterByKowIDArr?.length <= 0 &&
        this.startDateEDayoffFilterValue != null
      ) {
        this.filterEDayoffPredicates = `(EmployeeID=="${this.employeeID}" and BeginDate>="${this.startDateEDayoffFilterValue}" and EndDate<="${this.endDateEDayoffFilterValue}")`;
        (this.dayoffGrid?.dataService as CRUDService).setPredicates(
          [this.filterEDayoffPredicates],
          [],
          (res) => {
            this.UpdateDataOnGrid(
              this.dayoffGrid,
              res,
              this.filterEDayoffPredicates,
              null
            );
          }
        );
      } else if (
        this.filterByKowIDArr?.length <= 0 &&
        (this.startDateEDayoffFilterValue == undefined ||
          this.startDateEDayoffFilterValue == null)
      ) {
        this.filterEDayoffPredicates = `(EmployeeID=="${this.employeeID}")`;
        (this.dayoffGrid?.dataService as CRUDService).setPredicates(
          [this.filterEDayoffPredicates],
          [''],
          (res) => {
            this.UpdateDataOnGrid(
              this.dayoffGrid,
              res,
              this.filterEDayoffPredicates,
              null
            );
          }
        );
      }
    }
  }

  valueChangeFilterDayOff(evt) {
    this.filterByKowIDArr = evt.data;
    this.UpdateEDayOffsPredicate();
  }

  valueChangeYearFilterDayOff(evt) {
    if (evt.formatDate == undefined && evt.toDate == undefined) {
      this.startDateEDayoffFilterValue = null;
      this.endDateEDayoffFilterValue = null;
    } else {
      this.startDateEDayoffFilterValue = evt.fromDate.toJSON();
      this.endDateEDayoffFilterValue = evt.toDate.toJSON();
    }
    this.UpdateEDayOffsPredicate();
  }

  valueChangeFilterAccidentID(evt) {
    this.filterByAccidentIDArr = evt.data;
    let lengthArr = this.filterByAccidentIDArr?.length;

    if (lengthArr <= 0) {
      this.filterAccidentIdPredicate = `(EmployeeID=="${this.employeeID}")`;
      (this.eAccidentGridView.dataService as CRUDService).setPredicates(
        [this.filterAccidentIdPredicate],
        [''],
        (res) => {
          this.UpdateDataOnGrid(
            this.eAccidentGridView,
            res,
            this.filterAccidentIdPredicate,
            null
          );
        }
      );
    } else {
      this.filterAccidentIdPredicate = `(EmployeeID=="${this.employeeID}" and (`;
      for (let i = 0; i < lengthArr; i++) {
        if (i > 0) {
          this.filterAccidentIdPredicate += ' or ';
        }
        this.filterAccidentIdPredicate += `AccidentID==@${i}`;
      }
      this.filterAccidentIdPredicate += ') ';
      this.filterAccidentIdPredicate += ') ';
      (this.eAccidentGridView.dataService as CRUDService).setPredicates(
        [this.filterAccidentIdPredicate],
        [this.filterByAccidentIDArr.join(';')],
        (res) => {
          this.UpdateDataOnGrid(
            this.eAccidentGridView,
            res,
            this.filterAccidentIdPredicate,
            this.filterByAccidentIDArr.join(';')
          );
        }
      );
    }
  }

  isMaxGrade(eSkill: any) {
    let item = this.lstESkill?.filter((p) => p.skillID == eSkill.skillID);
    if (item) {
      let lstSkill = item[0].listSkill;
      if (lstSkill && eSkill.recID == lstSkill[0].recID) {
        return true;
      }
    }
    return false;
  }

  getAssetBackgroundColor(asset) {
    for (let i = 0; i < this.AssetColorValArr?.length; i++) {
      if (this.AssetColorValArr[i].CategoryID == asset) {
        return this.AssetColorValArr[i].Background;
      }
    }
    // return 'badge-primary';
  }

  getAssetFontColor(asset) {
    for (let i = 0; i < this.AssetColorValArr?.length; i++) {
      if (this.AssetColorValArr[i].CategoryID == asset) {
        return this.AssetColorValArr[i].FontColor;
      }
    }
    // return 'badge-primary';
  }

  getBenefitBackgroundColor(benefit) {
    for (let i = 0; i < this.BeneFitColorValArr?.length; i++) {
      if (this.BeneFitColorValArr[i].CategoryID == benefit.benefitID) {
        return this.BeneFitColorValArr[i].Background;
      }
    }
    // return 'badge-primary';
  }

  getBenefitFontColor(benefit) {
    for (let i = 0; i < this.BeneFitColorValArr?.length; i++) {
      if (this.BeneFitColorValArr[i].AllowanceID == benefit.benefitID) {
        return this.BeneFitColorValArr[i].FontColor;
      }
    }
    return '#000205';
  }

  getBenefitIcon(benefit) {
    for (let i = 0; i < this.BeneFitColorValArr?.length; i++) {
      if (this.BeneFitColorValArr[i].AllowanceID == benefit.benefitID) {
        return this.BeneFitColorValArr[i].Icon;
      }
    }
  }

  getVaccineBackgroundColor(vaccine) {
    for (let i = 0; i < this.VaccineColorValArr?.length; i++) {
      if (this.VaccineColorValArr[i].VaccineTypeID == vaccine.vaccineTypeID) {
        return this.VaccineColorValArr[i].Background;
      }
    }
    // return 'badge-primary';
  }

  getVaccineFontColor(vaccine) {
    for (let i = 0; i < this.VaccineColorValArr?.length; i++) {
      if (this.VaccineColorValArr[i].VaccineTypeID == vaccine.vaccineTypeID) {
        return this.VaccineColorValArr[i].FontColor;
      }
    }
    return '#000205';
  }

  calculateEFamilyAge() {
    for (let i = 0; i < this.lstFamily.length; i++) {
      if (this.lstFamily[i].birthday) {
        let birth = new Date(this.lstFamily[i].birthday);
        let birthYear = birth.getFullYear();

        let currentDay = new Date();
        let currentYear = currentDay.getFullYear();

        if (birthYear < currentYear) {
          this.lstFamily[i].age = `${currentYear - birthYear}`;
        } else {
          let birthMonth = birth.getMonth();
          let currentMonth = currentDay.getMonth();
          this.lstFamily[i].age = `${currentMonth - birthMonth} tháng`;
        }
      } else {
        this.lstFamily[i].age = '';
      }
    }
  }

  close2(dialog: DialogRef) {
    dialog.close();
  }

  getManagerEmployeeInfoById() {
    if (this.infoPersonal?.lineManager) {
      let empRequest = new DataRequest();
      empRequest.entityName = 'HR_Employees';
      empRequest.dataValues = this.infoPersonal.lineManager;
      empRequest.predicates = 'EmployeeID=@0';
      empRequest.pageLoading = false;
      this.hrService.loadData('HR', empRequest).subscribe((res: any) => {
        if (Array.isArray(res) && res[1] > 0) {
          this.lineManager = res[0][0];
          this.loadedLineManager = true;
          this.df.detectChanges();
        }
      });
    } else {
      this.loadedLineManager = true;
      this.df.detectChanges();
    }
    if (this.infoPersonal?.indirectManager) {
      let empRequest = new DataRequest();
      empRequest.entityName = 'HR_Employees';
      empRequest.dataValues = this.infoPersonal.indirectManager;
      empRequest.predicates = 'EmployeeID=@0';
      empRequest.pageLoading = false;
      this.hrService.loadData('HR', empRequest).subscribe((emp) => {
        if (emp[1] > 0) {
          this.indirectManager = emp[0][0];
          this.loadedIndirectManager = true;
          this.df.detectChanges();
        }
      });
    } else {
      this.loadedIndirectManager = true;
      this.df.detectChanges();
    }
  }

  HandleEmployeeDocument() {
    this.isHiddenCbxDocument = false;
    this.lstCurrentDocumentTypeID = this.lstEmpDocument.map((e) => {
      return e.documentTypeID;
    });
    this.strCurrentDocuments = this.lstCurrentDocumentTypeID.join(';');
  }

  onClickHideComboboxPopup(evt) {
    this.isHiddenCbxDocument = true;
    let lstIdReturn = evt.id.split(';');
    let lstIdAdd = [];
    let lstIdAlreadyHave = this.lstEmpDocument.map((x: any) => {
      return x.documentTypeID;
    });

    for (let i = 0; i < lstIdReturn.length; i++) {
      let index = lstIdAlreadyHave.indexOf(lstIdReturn[i]);

      if (index < 0) {
        lstIdAdd.push(lstIdReturn[i]);
      }
    }

    let addedSucess = false;
    for (let i = 0; i < lstIdAdd.length; i++) {
      this.GetDocumentByDocumentTypeID(lstIdAdd[i]).subscribe((res) => {
        console.log(lstIdAdd[i], res);
        if (res) {
          res.employeeId = this.employeeID;
          res.recID = Util.uid();
          // this.lstEmpDocument.push(res);
          this.AddEDocument(res).subscribe((res2) => {
            if (res2) {
              if (addedSucess == false) {
                addedSucess = true;
                this.notify.notifyCode('SYS006');
              }
              this.GetEmpDocument(this.infoPersonal.employeeID).subscribe(
                (res) => {
                  this.lstEmpDocument = res;
                  for (let i = 0; i < this.lstEmpDocument.length; i++) {
                    this.getFileDataAsync(
                      this.lstEmpDocument[i].recID
                    ).subscribe((res) => {
                      this.lstEmpDocument[i].lstFile = res;
                    });
                  }
                }
              );
            }
          });
        }
      });
    }
    this.df.detectChanges();
  }

  transText(value: string, lstFuncID: any): string {
    console.log(value);
    let funcObj = lstFuncID.filter((x) => x.functionID == value);
    let headerText = '';
    if (funcObj && funcObj?.length > 0) {
      headerText = funcObj[0].description;
    }
    return headerText;
  }
  //#region APIs
  GetEmpDocument(empID) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EDocumentsBusiness_Old',
      'GetDocumentByEmployeeIdAsync',
      [empID]
    );
  }

  GetDocumentByDocumentTypeID(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EDocumentsBusiness_Old',
      'GetDocumentByDocumentTypeIDAsync',
      [data]
    );
  }

  getFileDataAsync(pObjectID: string) {
    return this.api.execSv<any>(
      'DM',
      'ERM.Business.DM',
      'FileBussiness',
      'GetFilesByIbjectIDAsync',
      [pObjectID]
    );
  }

  AddEDocument(data) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EDocumentsBusiness_Old',
      'AddEDocumentsAsync',
      data
    );
  }

  DeleteEDocument(recId) {
    return this.api.execSv<any>(
      'HR',
      'HR',
      'EDocumentsBusiness_Old',
      'DeleteEDocumentsAsync',
      recId
    );
  }
  //#endregion

  //#region Init CRUD
  eDocument() {
    if (!this.edocumentCRUD)
      this.edocumentCRUD = this.hrService.createCRUDService(
        this.inject,
        this.edocumentFormModel,
        'HR'
      );
    return this.edocumentCRUD;
  }

  eFamily() {
    if (!this.eFamilyCRUD)
      this.eFamilyCRUD = this.hrService.createCRUDService(
        this.inject,
        this.eFamilyFormModel,
        'HR'
      );
    return this.eFamilyCRUD;
  }

  eExperiences() {
    if (!this.eExperiencesCRUD)
      this.eExperiencesCRUD = this.hrService.createCRUDService(
        this.inject,
        this.eExperienceFormModel,
        'HR'
      );
    return this.eExperiencesCRUD;
  }
  //#endregion

  // get formModel
  getFormModelByFuncID(funcID: string) {
    if (funcID) {
      switch (funcID) {
        case '': //TAB SƠ YẾU LÍ LỊCH
          break;
        case '': //TAB THÔNG TIN NHÂN VIÊN
          break;
        case '': //TAB LƯƠNG PHÚC LỢI
          break;
        case '': //TAB QUÁ TRÌNH NHÂN SỰ
          break;
        case '': //TAB KIẾN THỨC
          break;
        case '': //TAB SỨC KHỎE
          break;
        case '': //TAB THÔI VIỆC
          break;
      }
    }
  }

  //get child function by parent functionID
  getChildFunction(parentFuncID: string) {
    if (parentFuncID) {
      this.api
        .execSv('SYS', 'SYS', 'FunctionListBusiness', 'GetByParentAsync', [
          parentFuncID,
          true,
        ])
        .subscribe((res: any) => {
          if (res && res.length > 0) {
          }
        });
    }
  }

  navChange(evt: any, index: number = -1, functionID: number = -1, btnClick: any) {
    let containerList = document.querySelectorAll('.pw-content');
    let lastDivList = document.querySelectorAll('.div_final');
    console.log(containerList)
    let lastDiv = lastDivList[index];
    let container = containerList[index];
    console.log('container', container)
    let containerHeight = (container as any).offsetHeight;
    let contentHeight = 0;
    for (let i = 0; i < container.children.length; i++) {
      contentHeight += (container.children[i] as any).offsetHeight;
    }

    if (!evt) return;
    let element = document.getElementById(evt);
    console.log(element)
    if (!element) return;
    let distanceToBottom = contentHeight - element.offsetTop;

    if (distanceToBottom < containerHeight) {
      (lastDiv as any).style.width = '200px';
      (lastDiv as any).style.height = `${containerHeight - distanceToBottom + 50
        }px`;
    }

    if (index > -1) {
      this.active[functionID] = evt;
      this.detectorRef.detectChanges();
    }
    element.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest',
    });

    console.log('qua')
    this.isClick = true;
    this.detectorRef.detectChanges();
    setTimeout(() => {
      this.isClick = false;
      return;
    }, 500);
  }

  onSectionChange(data: any, index: number = -1) {
    if (index > -1 && this.isClick == false) {
      this.active[index] = data;
      console.log(this.active)
      this.detectorRef.detectChanges();
    }
  }


  @ViewChild('navList') navList: ElementRef | undefined;
  showLeftButton: boolean = true;
  showRightButton: boolean = false;

  scroll(direction: string): void {
    const navListWidth = this.navList?.nativeElement.scrollWidth;
    const containerWidth = this.navList?.nativeElement.offsetWidth;
    const scrollPosition = this.navList?.nativeElement.scrollLeft;

    if (direction === 'left') {
      this.navList?.nativeElement.scrollTo({ left: scrollPosition - containerWidth, behavior: 'smooth' });
    } else {
      this.navList?.nativeElement.scrollTo({ left: scrollPosition + containerWidth, behavior: 'smooth' });
    }
  }


  listField: any = [
    {
      id: 'Employeeinfo',
      name: 'Nhân viên',
      field: 'FullName',
      width: 200,
      textAlign: 'Left',
      type: 'text',
    },
    {
      id: 'StartWorkingDate',
      name: 'Tình trạng',
      field: 'StartWorkingDate',
      width: 100,
      textAlign: 'Left',
      type: 'combobox',
    },
    {
      id: 'Hotline',
      name: 'Liên hệ',
      field: 'Phone',
      width: 100,
      textAlign: 'Left',
      type: 'datetime',
    },
  ];

  cardDataFake = [
    { title: 'Công việc làm', content: '15', subContent: '/24', color: '#17BB45', icon: 'icon-bar_chart', typeIcon: '' },
    { title: 'Tăng ca', content: '15', subContent: '/24', color: '#FFA800', icon: 'icon-bar_chart', typeIcon: '' },
    { title: 'Tăng ca', content: '8', subContent: ' giờ', color: '#F64E60', icon: 'icon-trending_up', typeIcon: 'icon-small' },
    { title: 'Tăng ca', content: '180', subContent: ' phút', color: '#6C757D', icon: 'icon-trending_down', typeIcon: 'icon-small' }
  ];

  registerApprove(event: any) {
    let options = new SidebarModel();

    options.Width = '800px';
    // this.callfunc.openSide(DialogReviewLeaveApproveComponent, [], options);
    this.callfunc.openSide(DialogRegisterApproveComponent);

  }

  reviewRegisterApprove(event: any) {
    let options = new SidebarModel();

    options.Width = 'Auto';
    this.callfunc.openSide(DialogReviewLeaveApproveComponent, [], options);

  }

  waitingRegisterApprove(event: any) {
    let options = new SidebarModel();

    options.Width = 'Auto';
    this.callfunc.openSide(DialogWaitingLeavingApproveComponent, [], options);
  }

  openMyReamSide() {
    let options = new SidebarModel();

    options.Width = 'Auto';
    this.callfunc.openSide(PopupMyteamReponsiveComponent, [], options);
  }

  dialog?: DialogRef;


  openMenuSideBar() {
    let options = new SidebarModel();

    // options.Width = 'Auto';
    // options.Position = 'Left'
    // this.callfunc.openSide(PopupMenusidebarReponsiveComponent, [], options);

    // let options = new SidebarModel();


    options.Width = 'Auto';
    options.Position = "Left";
    var obj = {
      currentTab: this.crrFuncTabNum
    };


    this.dialog = this.callfunc.openSide(PopupMenusidebarReponsiveComponent, obj, options);


    this.dialog.componentRef.instance.tabChanged.subscribe((newTab: number) => {
      console.log(newTab)
      this.crrFuncTabNum = newTab;
      this.dialog?.close(true);
    });
  }


  //Fake will delete very soon
  onSelectEmployee(event: any) {
    this.navigateEmp02(event);
  }

  onBackToMyInfo(event: any) {
    this.navigateEmp03(event);
  }

  navigateEmp02(event: any) {
    // if (isNextPage == true) {
    //   let newPageNum = Number(this.pageNum) + 1;
    //   this.pageNum = newPageNum;
    // }
    // if (this.crrIndex > -1) {
    // this.LoadedEInfo = false;
    // this.infoPersonal = null;
    let urlView = `/hr1/employeeprofile/${this.funcID}`;
    this.codxService.replaceNavigate(
      urlView,
      {
        employeeID: this.myEmployeeID,
        employeeID2: event,

        // page: this.pageNum.toString(),
        // totalPage: this.maxPageNum,
        // totalCount: this.totalCount,
        // from: this.fromView
      }
      // ,
      // {
      //   data: this.listEmp,
      //   request: this.request,
      //   totalPage: this.maxPageNum,
      //   totalCount: this.totalCount,
      //   from: this.fromView,
      // }
    );
    this.loadDataWhenChangeEmp();
    this.refreshGridViews();
    // }
  }

  navigateEmp03(event: any) {
    // if (isNextPage == true) {
    //   let newPageNum = Number(this.pageNum) + 1;
    //   this.pageNum = newPageNum;
    // }
    // if (this.crrIndex > -1) {
    // this.LoadedEInfo = false;
    // this.infoPersonal = null;
    let urlView = `/hr1/employeeprofile/${this.funcID}`;
    this.codxService.replaceNavigate(
      urlView,
      {
        employeeID: this.myEmployeeID,


        // page: this.pageNum.toString(),
        // totalPage: this.maxPageNum,
        // totalCount: this.totalCount,
        // from: this.fromView
      }
      // ,
      // {
      //   data: this.listEmp,
      //   request: this.request,
      //   totalPage: this.maxPageNum,
      //   totalCount: this.totalCount,
      //   from: this.fromView,
      // }
    );
    this.loadDataWhenChangeEmp();
    this.refreshGridViews();

    // }
  }

  //Fake - delete later
  lstAwardData: any[] = [


    {
      functionID: 1,
      customName: "Dashboard",
      largeIcon: "icon-columns_gap" // Fake icon class
    },
    {
      functionID: 2,
      customName: "Thông tin cá nhân",
      largeIcon: "icon-assignment_ind" // Fake icon class
    },
    {
      functionID: 3,
      customName: "Quá trình làm việc",
      largeIcon: "icon-timeline" // Fake icon class
    },
    {
      functionID: 4,
      customName: "Khen thưởng kỷ luật",
      largeIcon: "icon-elevator" // Fake icon class
    },
    {
      functionID: 5,
      customName: "Thông tin phúc lợi",
      largeIcon: "icon-redeem" // Fake icon class
    },

    {
      functionID: 6,
      customName: "Thông tin pháp lý",
      largeIcon: "icon-gavel" // Fake icon class
    },
    {
      functionID: 7,
      customName: "Thông tin kiến thức",
      largeIcon: "icon-school" // Fake icon class
    }

  ];



}
