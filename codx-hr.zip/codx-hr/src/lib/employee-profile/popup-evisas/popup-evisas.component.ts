import { FormGroup } from '@angular/forms';
import { CodxHrService } from 'projects/codx-hr/src/public-api';
import { Injector, ChangeDetectorRef } from '@angular/core';
import { Component, OnInit, Optional, ViewChild } from '@angular/core';
import {
  CodxFormComponent,
  CodxListviewComponent,
  CRUDService,
  DialogData,
  DialogRef,
  FormModel,
  NotificationsService,
  UIComponent,
} from 'codx-core';
import { CodxShareService } from 'projects/codx-share/src/public-api';

@Component({
  selector: 'lib-popup-evisas',
  templateUrl: './popup-evisas.component.html',
  styleUrls: ['./popup-evisas.component.css'],
})
export class PopupEVisasComponent extends UIComponent implements OnInit {
  formModel: FormModel;
  // formGroup: FormGroup;
  dialog: DialogRef;
  lstVisas: any;
  visaObj;
  actionType;
  headerText: '';
  fieldHeaderTexts;
  idField = 'RecID';
  disabledInput = false;
  indexSelected;
  employId;
  // isAfterRender = false;
  @ViewChild('form') form: CodxFormComponent;
  // @ViewChild('listView') listView: CodxListviewComponent;

  constructor(
    private injector: Injector,
    private notify: NotificationsService,
    private cr: ChangeDetectorRef,
    private hrService: CodxHrService,
    private codxShareService: CodxShareService,
    @Optional() dialog?: DialogRef,
    @Optional() data?: DialogData
  ) {
    super(injector);
    this.dialog = dialog;
    console.log('dialog nhan vao', this.dialog);
    
    this.headerText = data?.data?.headerText;
    this.funcID = data?.data?.funcID;
    this.actionType = data?.data?.actionType;
    if(this.actionType == 'view'){
      this.disabledInput = true;
    }
    this.formModel = dialog.formModel;
    this.employId = data?.data?.employeeId;
    this.visaObj = JSON.parse(JSON.stringify(data?.data?.visaObj));
  }

  ngAfterViewInit() {}

  initForm() {
    if (this.actionType == 'add') {
      this.hrService
        .getDataDefault(
          this.formModel.funcID,
          this.formModel.entityName,
          this.idField
        )
        .subscribe((res: any) => {
          if (res) {
            this.visaObj = res?.data;
            this.visaObj.employeeID = this.employId;
            //xét null cho field dateTime required
            this.visaObj.effectedDate = null;
            this.visaObj.expiredDate = null;

            // this.formModel.currentData = this.visaObj;
            // this.form.formGroup.patchValue(this.visaObj);
            this.cr.detectChanges();
            // this.isAfterRender = true;
          }
        });
    } else {
      if (this.actionType === 'edit' || this.actionType === 'copy' || this.actionType === 'view') {
        if (this.actionType == 'copy') {
          if (this.visaObj.effectedDate == '0001-01-01T00:00:00') {
            this.visaObj.effectedDate = null;
          }
          if (this.visaObj.expiredDate == '0001-01-01T00:00:00') {
            this.visaObj.expiredDate = null;
          }
        }
        // this.form.formGroup.patchValue(this.visaObj);
        // this.formModel.currentData = this.visaObj;
        this.cr.detectChanges();
        // this.isAfterRender = true;
      }
    }
    // this.formModel.currentData = this.visaObj;
    // this.form.formGroup.patchValue(this.visaObj);
    // this.cr.detectChanges();
    // this.isAfterRender = true;
  }

  onInit(): void {
    // if (!this.form.formGroup)
    //   this.hrService.getFormModel(this.funcID).then((formModel) => {
    //     if (formModel) {
    //       this.formModel = formModel;
    //       this.hrService
    //         .getFormGroup(this.formModel.formName, this.formModel.gridViewName, this.formModel)
    //         .then((fg) => {
    //           if (fg) {
    //             this.form.formGroup = fg;
    //             this.initForm();
    //           }
    //         });
    //     }
    //   });
    // else
    //   this.hrService
    //     .getFormGroup(this.formModel.formName, this.formModel.gridViewName , this.formModel)
    //     .then((fg) => {
    //       if (fg) {
    //         this.form.formGroup = fg;
    //         this.initForm();
    //       }
    //     });
        this.initForm();
        this.hrService.getHeaderText(this.funcID).then((res) => {
          this.fieldHeaderTexts = res;
        })
  }

  onSaveForm() {
    if (this.form.formGroup.invalid) {
      this.hrService.notifyInvalid(this.form.formGroup, this.formModel);
      
      this.form.validation(false)
      return;
    }

    let ddd = new Date();
    if(this.visaObj.issuedDate > ddd.toISOString()){
      this.notify.notifyCode('HR014',0, this.fieldHeaderTexts['IssuedDate']);
      return;
    }

            //Xu li validate thong tin CMND nhan vien
            if(this.visaObj.expiredDate && this.visaObj.effectedDate){
              if (this.visaObj.expiredDate < this.visaObj.effectedDate) {
                this.hrService.notifyInvalidFromTo(
                  'ExpiredDate',
                  'EffectedDate',
                  this.formModel
                  )
                  return;
                }
            }

    if (this.actionType === 'add' || this.actionType === 'copy') {
      this.hrService.AddEmployeeVisaInfo(this.visaObj).subscribe((p) => {
        if (p != null) {
          this.visaObj.recID = p.recID;
          this.notify.notifyCode('SYS006');
          this.dialog && this.dialog.close(p);
        } else this.notify.notifyCode('SYS023');
      });
    } else {
      this.hrService
        .updateEmployeeVisaInfo(this.form.data)
        .subscribe((p) => {
          if (p != null) {
            this.notify.notifyCode('SYS007');
            this.dialog && this.dialog.close(p);
          } else this.notify.notifyCode('SYS021');
        });
    }
  }

  click(data) {
    this.visaObj = data;
    // this.formModel.currentData = JSON.parse(JSON.stringify(this.visaObj));
    this.form.data = JSON.parse(JSON.stringify(this.visaObj));
    this.indexSelected = this.lstVisas.findIndex(
      (p) => p.recID == this.visaObj.recID
    );
    this.actionType = 'edit';
    this.form.formGroup?.patchValue(this.visaObj);
    this.cr.detectChanges();
  }
}
