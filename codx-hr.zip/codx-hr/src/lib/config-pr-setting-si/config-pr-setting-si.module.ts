import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CoreModule } from '@core/core.module';
import { CodxCoreModule } from 'codx-core';
import { RouterModule, Routes } from '@angular/router';
import { LayoutComponent } from '../_layout/layout.component';
import { ConfigPrSettingSiComponent } from './config-pr-setting-si.component';
import { FormConfigComponent } from './components/form-config/form-config.component';

const routes: Routes = [
  {
    path:'',
    component: LayoutComponent,
    children:[
      {
        path:'configprsettingsi/:funcID',
        component: ConfigPrSettingSiComponent,
      },
      {
        path: '**',
        redirectTo: 'error/404',
      },
    ]
  }
];


const T_Component = [
  ConfigPrSettingSiComponent
];
const T_Modules = [
  FormConfigComponent
]



@NgModule({
  imports: [
    CommonModule,
    CoreModule,
    CodxCoreModule,
    RouterModule.forChild(routes),
    ...T_Modules
  ],
  declarations: [T_Component],
})
export class ConfigPrSettingSiModule { }
