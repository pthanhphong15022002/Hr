import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CoreModule } from '@core/core.module';
import { CodxCoreModule, FormModel } from 'codx-core';

@Component({
  selector: 'form-config',
  templateUrl: './form-config.component.html',
  styleUrls: ['./form-config.component.scss'],
  standalone:true,
  imports:[CommonModule,CoreModule,CodxCoreModule]
})
export class FormConfigComponent {
  @Input() formModel: FormModel;
  @Input() formGroup: FormGroup;
  @Input() grvSetup:any;
  @Input() type:string;
  @Input() name:string;
  @Input() default:any;
  @Input() field:string;
  @Input() value:any;
  @Input() vllName:string;
  ChangeValue(evt){
    console.log(evt,'aaaa');
    
  }
}
