import { Component, Injector, OnInit } from '@angular/core';
import { FormModel, UIComponent } from 'codx-core';
import { CodxHrService } from '../codx-hr.service';
import { ActivatedRoute } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'lib-config-pr-setting-si',
  templateUrl: './config-pr-setting-si.component.html',
  styleUrls: ['./config-pr-setting-si.component.scss']
})
export class ConfigPrSettingSiComponent extends UIComponent implements OnInit{
  formModel: FormModel;
  formGroup: FormGroup;
  grvSetup:any;
  listField:Array<any> = []
  constructor(
    private injector:Injector,
    private hrService:CodxHrService,
    private activatedRoute:ActivatedRoute
  ){
    super(injector)
  }

  onInit(): void {
    this.funcID = this.activatedRoute.snapshot.params['funcID'];
    this.getFormModel();
  }



  GetGvSetup() {
    this.cache
        .gridViewSetup('ConfigPR', this.formModel?.gridViewName)
        .subscribe((res) => {
          if(res){
            this.grvSetup = res;
            this.listField = Object.keys(this.grvSetup)
          }
          console.log(this.grvSetup,'grvSetup');
        });
  }

  getFromGroup = async()=>{
    this.formGroup = await this.hrService.getFormGroup('ConfigPR',this.formModel?.gridViewName,this.formModel)
    console.log(this.formGroup,'formGroup');
  }

  getFormModel = async () => {
    debugger
    this.formModel = await  this.hrService.getFormModel(this.funcID)
    console.log(this.formModel,'formModel');
    this.GetGvSetup();
    this.getFromGroup();

  }
  

}
