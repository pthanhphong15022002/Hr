import { Component } from '@angular/core';

@Component({
  selector: 'lib-newemployee-list',
  templateUrl: './newemployee-list.component.html',
  styleUrls: ['./newemployee-list.component.css']
})
export class NewemployeeListComponent {

}
