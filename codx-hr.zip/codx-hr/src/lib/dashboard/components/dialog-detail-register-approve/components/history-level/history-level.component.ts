import { Component } from '@angular/core';

@Component({
  selector: 'lib-history-level',
  templateUrl: './history-level.component.html',
  styleUrls: ['./history-level.component.scss'],
  standalone:true
})
export class HistoryLevelComponent {

}
