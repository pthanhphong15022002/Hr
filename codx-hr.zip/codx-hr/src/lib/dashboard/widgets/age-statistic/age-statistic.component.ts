import { Component } from '@angular/core';

@Component({
  selector: 'lib-age-statistic',
  templateUrl: './age-statistic.component.html',
  styleUrls: ['./age-statistic.component.scss']
})
export class AgeStatisticComponent {

}
