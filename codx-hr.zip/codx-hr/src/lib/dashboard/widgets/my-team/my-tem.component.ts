import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { TabComponent } from '@syncfusion/ej2-angular-navigations';
import { CRUDService, CodxListviewComponent } from 'codx-core';

@Component({
  selector: 'my-team',
  templateUrl: './my-tem.component.html',
  styleUrls: ['./my-tem.component.scss'],
})
export class MyTemComponent {
  selectedTabs = 0; // 0: quản lý trực tiếp ; 1:Quản lý gián tiếp; 3:Team của tôi;
  dtService: CRUDService;

  @Input() crrEmpID;
  @Input() activeEmpID;
  @Input() formModel;
  @Input() mainContent_Id = 'maincontent';
  @Output() handleReviewInfoEmployee = new EventEmitter();
  @Output() handleGetFullInfoEmployee = new EventEmitter();
@ViewChild('lstView1') lstView1:CodxListviewComponent;
@ViewChild('tab') tab:TabComponent;
  /* status : 1 - active, 2 - off, 3- busy */
  // @Input() dataMyTeam = [
  //   {
  //     id: '1',
  //     name: 'Huỳnh Phước Hòa',
  //     job: 'Phát triển phần mềm',
  //     YOW: '15 năm 9 tháng 0 ngày',
  //     status: '1',
  //   },
  //   {
  //     id: '1',
  //     name: 'Huỳnh Phước Hòa',
  //     job: 'Phát triển phần mềm',
  //     YOW: '15 năm 9 tháng 0 ngày',
  //     status: '1',
  //   },
  //   {
  //     id: '1',
  //     name: 'Huỳnh Phước Hòa',
  //     job: 'Phát triển phần mềm',
  //     YOW: '15 năm 9 tháng 0 ngày',
  //     status: '1',
  //   },
  //   {
  //     id: '1',
  //     name: 'Huỳnh Phước Hòa',
  //     job: 'Phát triển phần mềm',
  //     YOW: '15 năm 9 tháng 0 ngày',
  //     status: '1',
  //   },
  //   {
  //     id: '1',
  //     name: 'Huỳnh Phước Hòa',
  //     job: 'Phát triển phần mềm',
  //     YOW: '15 năm 9 tháng 0 ngày',
  //     status: '1',
  //   },
  //   {
  //     id: '1',
  //     name: 'Huỳnh Phước Hòa',
  //     job: 'Phát triển phần mềm',
  //     YOW: '15 năm 9 tháng 0 ngày',
  //     status: '1',
  //   },
  // ];

  getInfoEmployee(employeeID = '2308070001'){
    console.log(employeeID)
    this.handleReviewInfoEmployee.emit(employeeID);
  }

  getFullInfoEmployee(employeeID){
    this.handleGetFullInfoEmployee.emit(employeeID);
  }

  tabCreated(e){
    this.tab.select(0);
  }

  tabSelected(){
    (this.lstView1?.dataService as CRUDService).idField = "employeeID";
  }
}
