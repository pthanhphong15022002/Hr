import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { ChangeDetectorRef, Component, EventEmitter, Injector, Input, Output, ViewChild } from '@angular/core';
import { TabComponent } from '@syncfusion/ej2-angular-navigations';
import { CRUDService, CodxListviewComponent } from 'codx-core';

@Component({
  selector: 'my-team',
  templateUrl: './my-tem.component.html',
  styleUrls: ['./my-tem.component.scss'],
})
export class MyTemComponent {
  selectedTabs = 0; // 0: quản lý trực tiếp ; 1:Quản lý gián tiếp; 3:Team của tôi;
  dtService: CRUDService;
  searchText: string = '';
  isSearch: any = [null, null, null];
  isTab: number = 1;
  @Input() crrEmpID;
  @Input() activeEmpID;
  @Input() orgUnitID = '';
  @Input() formModel;
  @Input() mainContent_Id = 'maincontent';
  @Output() handleReviewInfoEmployee = new EventEmitter();
  @Output() handleGetFullInfoEmployee = new EventEmitter();
  @ViewChild('lstView1') lstView1: CodxListviewComponent;
  @ViewChild('tab') tab: TabComponent;
  currentTab: string = 'Quản lý trực tiếp';

  @ViewChild('tab') public tabObj: TabComponent;
  @ViewChild('LineManagerListView') public lineManagerListView: CodxListviewComponent;
  @ViewChild('IndirectManagerListView') public indirectManagerListView: CodxListviewComponent;
  @ViewChild('MyGroupListView') public myGroupListView: CodxListviewComponent;
  currentListView: any = 1;
  constructor(
    private injector: Injector,
    private dt: ChangeDetectorRef,
  ) {

  }

  getInfoEmployee(employeeID = '2308070001') {
    console.log('test ở MY-TEAM', employeeID['data'].employeeID)
    this.handleReviewInfoEmployee.emit(employeeID['data'].employeeID);
  }

  getFullInfoEmployee(employeeID) {
    this.handleGetFullInfoEmployee.emit(employeeID);
  }

  tabCreated(e) {
    this.tab.select(0);
  }

  tabSelected(event: any) {
    const tabText = event.selectedItem.innerText.trim();
    this.currentTab = tabText;
    console.log('Tab đang được chọn:', this.currentTab);


    switch (this.currentTab) {
      case 'Quản lý trực tiếp':
        this.currentListView = this.lineManagerListView;
        this.isSearch = [true, false, false];
        this.isTab = 1;
        break;
      case 'Quản lý gián tiếp':
        this.currentListView = this.indirectManagerListView;
        this.isSearch = [false, true, false];
        this.isTab = 2;
        break;
      case 'Nhóm của tôi':
        this.currentListView = this.myGroupListView;
        this.isSearch = [false, false, true];
        this.isTab = 3;
        break;
    }

    console.log('Current ListView:', this.currentListView);
  }

  onSearch(evt: any) {
    console.log(evt)
    this.searchText = evt;

    const ins = setInterval(() => {
      {
        clearInterval(ins);
        let dataValuesInput = `${this.crrEmpID};${this.searchText}`;
        let dataValuesOrgInput = `${this.orgUnitID};${this.searchText}`
        console.log(this.isTab)
        switch (this.isTab) {
          case 1:
            this.lineManagerListView.dataService.setPredicates(['LineManager=@0 and (EmployeeName.Contains(@1) or PositionID.Contains(@1) or EmployeeID.Contains(@1))'], [`${dataValuesInput}`]);
            break;
          case 2:
            this.indirectManagerListView.dataService.setPredicates(['IndirectManager=@0 and (EmployeeName.Contains(@1) or PositionID.Contains(@1) or EmployeeID.Contains(@1))'], [`${dataValuesInput}`]);
            break;
          case 3:
            this.myGroupListView.dataService.setPredicates(['orgUnitID=@0 and (EmployeeName.Contains(@1) or PositionID.Contains(@1) or EmployeeID.Contains(@1))'], [`${dataValuesOrgInput}`]);
            break;
        }

     

        this.dt.detectChanges();



      }
    }, 2);


  }



}
