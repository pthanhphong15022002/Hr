export class FiscalPeriods{
    periodID: any;
    periodName: any;
    periodName2: any;
    periodType: any;
    fiscalYear: any;
    startDate: any;
    endDate: any;
    periodControl: any;
    moduleControl: any;
    createdOn: any;
    createdBy: any;
    modifiedOn: any;
    modifiedBy: any;
}