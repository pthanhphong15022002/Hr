export class VATCodes{
    vatid: any;
    vatName: any;
    VATName2: any;
    taxableObject: any;
    vatPct: any;
    taxDirection: any;
    formula: any;
    invoiceType: any;
    taxGroup: any;
    stop: any;
    owner: any;
    buid: any;
    createdOn: any;
    createdBy: any;
    modifiedOn: any;
    modifiedBy: any;
}