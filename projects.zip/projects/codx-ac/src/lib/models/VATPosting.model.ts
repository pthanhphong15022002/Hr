export class VATPosting {
      recID: any;
      vatid: any;
      buid: any;
      currencyID: any;
      objectType: any;
      objectID: any;
      postType: any;
      vatAcctID: any;
      postOffset: any;
      offsetAcctID: any;
      diM1: any;
      diM2: any;
      diM3: any;
      createdOn: any;
      createdBy: any;
      modifiedOn: any;
      modifiedBy: any;
}