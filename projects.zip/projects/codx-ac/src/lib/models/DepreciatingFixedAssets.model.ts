export class DepreciatingFixedAssets {
    assetGroupID: any;
    assetID: any;
    autoCreated: any;
    buid: any;
    completed: any;
    createdBy: any;
    createdOn: any;
    deprModelID: any;
    errorLog: any;
    fromDate: any;
    memo: any;
    memo2: any;
    modifiedBy: any;
    modifiedOn: any;
    owner: any;
    paras: any;
    periodID: any;
    recID: any;
    runDate: any;
    runMode: any;
    runType: any;
    status: any;
    toDate: any;
}