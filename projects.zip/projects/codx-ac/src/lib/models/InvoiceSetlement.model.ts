export class InvoiceSetlement{
    recID: any;
    runType: any;
    accountID: any;
    runDate: any;
    runMode: any;
    itemGroupID: any;
    periodID: any;
    fromDate: any;
    toDate: any;
    memo: any;
    memo2: any;
    status: any;
    paras: any;
    completed: any;
    errorLog: any;
    autoCreated: any;
    owner: any;
    buid: any;
    createdOn: any;
    createdBy: any;
    modifiedOn: any;
    modifiedBy: any;
    currencyID: any;
    objectID: any;
    voucherNo: any;
}