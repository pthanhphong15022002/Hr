export class CalculatingCostOfProduct{
    recID: any;
    runType: any;
    costingGroupID: any;
    runDate: any;
    runMode: any;
    periodID: any;
    fromDate: any;
    toDate: any;
    memo: any;
    memo2: any;
    status: any;
    paras: any;
    completed: any;
    errorLog: any;
    autoCreated: any;
    owner: any;
    buid: any;
    createdOn: any;
    createdBy: any;
    modifiedOn: any;
    modifiedBy: any;
    postLG: any;
}