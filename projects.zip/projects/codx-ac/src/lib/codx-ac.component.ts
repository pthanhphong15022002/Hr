import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-codx-ac',
  template: `
    <p>
      codx-ac works!
    </p>
  `,
  styles: [
  ]
})
export class CodxAcComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
