export class tmpformChooseRole {
  userID: string;
  userGroups: string;
  customName: string;
  largeIcon: string;
  smallIcon: string;
  functionID: string;
  module: string;
  moduleSales: string;
  roleNames: string;
  roleID: string;
  recRoleName: string;
  ischeck: boolean;
  recDelete: string;
  recUpdate: string;
  color: string;
  isPortal: boolean;
  startDate: Date;
  endDate: Date;
}
