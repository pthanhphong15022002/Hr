export class tmpTNMD {
  isError = true;
  module: string;
  moduleSales: string;
  roleID: string;
  lstUserIDs: string[];
  moduleName: string;
  startDate?: Date;
  endDate?: Date;
  orderModuleRecID;
}
