export class ContentTmp {
  header: string;
  subHeader: string;
  objectType: string;
  functionID: string;
  userID: string;
  userName: string;
  positionName: string;
}
