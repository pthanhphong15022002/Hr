export class tmpformRoles {
    UserID: string;
    UserName: string;
    PositionName: string;
    Email: string;
    RoleName: string;
    CustomName: string;
    LargeIcon: string;
    BUName: string;
    Mobile: string;
    EmployeeID: string;
    BUID: string;
}