import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-codx-ad',
  template: `
    <p>
      codx-ad works!
    </p>
  `,
  styles: [
  ]
})
export class CodxAdComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
